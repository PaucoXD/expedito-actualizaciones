﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Instala "Expedito" en esta PC: acceso directo en el Escritorio + revisión del equipo.
# Se ejecuta con doble clic en Instalar.cmd (no necesita permisos de administrador).
$app = $PSScriptRoot
Write-Host "Instalando Expedito desde:`n  $app`n"

# 1) si la app está en OneDrive: que sus archivos queden siempre en esta PC. Solo lo que usa la app
#    (no los respaldos de versiones\ ni la cola), así tarda segundos y no descarga de más.
$od = @($env:OneDriveCommercial, $env:OneDrive) | Where-Object { $_ -and $app.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }
if ($od) {
  Write-Host '1/3 Dejando los archivos de la app disponibles sin conexión...'
  attrib +P "$app" 2>$null | Out-Null
  foreach ($x in Get-ChildItem -LiteralPath $app -Force | Where-Object { $_.Name -notin 'versiones', 'cola', 'licencia-pcs' }) {
    if ($x.PSIsContainer) { attrib +P "$($x.FullName)" /S /D 2>$null | Out-Null } else { attrib +P "$($x.FullName)" 2>$null | Out-Null } }
} else { Write-Host '1/3 La app no está en OneDrive: no hace falta dejarla sin conexión.' }
Write-Host '2/3 Desbloqueando archivos...'
Get-ChildItem -LiteralPath $app -Recurse -File | Where-Object { $_.FullName -notlike "$app\versiones\*" } | Unblock-File -ErrorAction SilentlyContinue

# acceso directo
$desk = [Environment]::GetFolderPath('Desktop'); $lnk = Join-Path $desk 'Expedito.lnk'
$viejo = Join-Path $desk ('Expedientes ' + 'CASA.lnk'); if ((Test-Path -LiteralPath $viejo) -and ((New-Object -ComObject WScript.Shell).CreateShortcut($viejo).Arguments -like "*$app\*")) { Remove-Item -LiteralPath $viejo -Force }   # nombre anterior, solo si es de esta app
$sh = New-Object -ComObject WScript.Shell; $l = $sh.CreateShortcut($lnk)
$l.TargetPath = "$env:WINDIR\System32\wscript.exe"   # abre sin ventana de consola
$l.Arguments = "`"$app\abrir.vbs`""
$l.WorkingDirectory = $app; $l.WindowStyle = 1; $l.Description = 'Expedito'
$ico = Join-Path $app 'app.ico'; $l.IconLocation = if (Test-Path -LiteralPath $ico) { "$ico,0" } else { "$env:WINDIR\System32\shell32.dll,165" }
$l.Save()
Write-Host "Acceso directo creado: $lnk`n"

# revisión del equipo
Write-Host '3/3 Revisando el equipo...'
. "$app\casa.ps1"
Write-Host 'Revisión del equipo:'
foreach ($x in Test-CasaEquipo) {
  $c = switch ($x.Estado) { 'OK' { 'Green' } 'FALTA' { 'Red' } default { 'Yellow' } }
  Write-Host ("  [{0,-5}] {1}: {2}" -f $x.Estado, $x.Que, $x.Detalle) -ForegroundColor $c
}
Write-Host "`nListo. Abre 'Expedito' desde el Escritorio. Lo que salga en rojo hay que resolverlo antes de usarla."
