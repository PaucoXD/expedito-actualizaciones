﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Herramientas para armar expedientes de CASA para cualquier cliente. Empresa (patente, aduana, prefijo), rutas por PC
# y el mapa de CASA (IDs de menú y posiciones de botones) se configuran en la pestaña Configuración (config.json).
# Uso:  . "<carpeta de la app>\casa.ps1"   y luego llamar las funciones. La app puede vivir en OneDrive y usarse en varias PCs:
# las rutas se detectan solas en cada equipo (o se fijan en config.json -> equipos.<NOMBRE-PC>).

$Global:CasaHome       = $PSScriptRoot
$Global:CasaConfigPath = "$PSScriptRoot\config.json"
$Global:CasaEquipo     = $env:COMPUTERNAME
$Global:CasaRecintos   = @{ '243'='FEDEX 243'; '158'='OMA 158'; '260'='OMA 260' }
# Conceptos SI/NO de la FAYC -> control de la hoja "Table 1"
$Global:CasaFaycSiNo = [ordered]@{ 'Anticipo'='Drop Down 18'; 'R1'='Drop Down 21'; 'Tiempo extra'='Drop Down 22'; 'Multa'='Drop Down 24'; 'Flete'='Drop Down 25'
  'Estadías'='Drop Down 8'; 'Demoras'='Drop Down 9'; 'Almacenaje'='Drop Down 10'; 'Manejo'='Drop Down 11'; 'Sencillo'='Drop Down 13'; 'Full'='Drop Down 15'; 'Carga suelta'='Drop Down 16' }

# ---------- configuración compartida (config.json junto a la app) ----------
# recintos, cr (CR -> recinto), clientes (nombre de facturación), elaboro (lista de la plantilla), equipos (por PC: elaboro y rutas).
function ConvertTo-CasaHash($o) { $h = @{}; if ($o) { foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value } }; $h }
function Read-CasaConfigFile { if (Test-Path -LiteralPath $CasaConfigPath) { try { Get-Content -LiteralPath $CasaConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $null } } }
function Get-CasaConfig {
  $c = @{ recintos = @(); cr = @{}; clientes = @{}; elaboro = @(); equipos = @{}; empresa = @{}; mapa = @{} }
  $j = Read-CasaConfigFile
  # Recintos, CR y gastos de A&C: solo de arranque en su instalación (sin cliente.json) mientras su config.json no los tenga.
  # Las demás agencias empiezan en blanco y los dan de alta en Configuración → Recintos y gastos.
  if (-not $CasaCliente) {
    if (-not ($j -and $j.recintos)) { $c.recintos = @('FEDEX 243', 'OMA 158', 'OMA 260') }
    if (-not ($j -and $j.cr)) { foreach ($k in $CasaRecintos.Keys) { $c.cr[$k] = $CasaRecintos[$k] } }
    if (-not ($j -and $j.clientes)) { $c.clientes['FLUIDMASTER WATER'] = @{ gastos = 'FLUIDMASTER' } }
  }
  if ($j) {
    if ($j.recintos) { $c.recintos = @(@($j.recintos) | Where-Object { $_ } | Select-Object -Unique) }
    foreach ($p in (ConvertTo-CasaHash $j.cr).GetEnumerator()) { $c.cr[$p.Key] = $p.Value }
    foreach ($p in (ConvertTo-CasaHash $j.clientes).GetEnumerator()) { $c.clientes[$p.Key] = @{ gastos = $p.Value.gastos } }
    if ($j.elaboro) { $c.elaboro = @($j.elaboro) }
    foreach ($p in (ConvertTo-CasaHash $j.equipos).GetEnumerator()) { $c.equipos[$p.Key] = ConvertTo-CasaHash $p.Value }
    $c.empresa = ConvertTo-CasaHash $j.empresa; $c.mapa = ConvertTo-CasaHash $j.mapa
  }
  $c
}
# Guarda mezclando con lo que haya en disco (otra PC pudo agregar algo mientras tanto). Solo borra lo que se pide en
# -Borrar @{ recintos = @(...); cr = @(claves); clientes = @(nombres) } (panel Recintos y gastos de Configuración).
function Save-CasaConfig($c, [hashtable]$Borrar = @{}) {
  $d = Get-CasaConfig
  $d.recintos = @(@($d.recintos) + @($c.recintos) | Where-Object { $_ } | Select-Object -Unique)
  foreach ($k in $c.cr.Keys) { $d.cr[$k] = $c.cr[$k] }
  foreach ($k in $c.clientes.Keys) { $d.clientes[$k] = $c.clientes[$k] }
  if ($Borrar.recintos) { $d.recintos = @($d.recintos | Where-Object { $Borrar.recintos -notcontains $_ }) }
  foreach ($k in @($Borrar.cr)) { if ($k) { $d.cr.Remove("$k") } }
  foreach ($k in @($Borrar.clientes)) { if ($k) { $d.clientes.Remove("$k") } }
  if ($c.elaboro) { $d.elaboro = @($c.elaboro) }
  foreach ($k in $c.equipos.Keys) { if (-not $d.equipos[$k]) { $d.equipos[$k] = @{} }; foreach ($x in $c.equipos[$k].Keys) { $d.equipos[$k][$x] = $c.equipos[$k][$x] } }
  foreach ($k in 'empresa', 'mapa') { if ($c[$k]) { foreach ($x in $c[$k].Keys) { $d[$k][$x] = $c[$k][$x] } } }
  $d | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $CasaConfigPath -Encoding UTF8
}
function Get-CasaEquipoCfg { $e = (Get-CasaConfig).equipos[$CasaEquipo]; if ($e) { $e } else { @{} } }

# ---------- empresa y mapa de CASA (valores de fábrica = A&C, patente 1664, aduana 520; se cambian en Configuración) ----------
$Global:CasaEmpresaFab = [ordered]@{ nombre = 'A&C Global Logistics'; patente = '1664'; aduana = '520'; ciudad = 'MONTERREY'; prefijo = 'AYC26-'; carpeta = '1664 EXPEDIENTES'; tablero = '' }
# Menús: POSICIÓN "menú/elemento" en el menú principal (cierre: NUNCA se manda; solo sirve para bloquearlo).
# Vucem: POSICIÓN (empieza en 0) en el menú del botón Vucem del Catálogo; sus números cambian entre PCs. Posiciones "x,y": dentro del control que usa cada paso.
$Global:CasaMapaFab = [ordered]@{ catalogo = '4/0'; impresion = '4/3'; simplificada = '4/5'; cierre = '4/1'; vucemRespCovePos = 3; vucemManifPos = 11
  coveRenglon = '40,27'; coveAlto = 18; coveTodos = '32,352'; coveImpFlecha = '54,26'; copias = '26,410'; copiasConfig = '82,27'; copiasImprimir = '22,27'
  simpOpciones = '26,150'; exportar = '196,25'; acuseVU = '20,26'; acuseVUFlecha = '70,26' }
# Instalación para otra empresa: el paquete trae cliente.json (lo crea el Generador) con sus datos iniciales.
$Global:CasaCliente = if (Test-Path -LiteralPath "$PSScriptRoot\cliente.json") { try { Get-Content -LiteralPath "$PSScriptRoot\cliente.json" -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $null } }
function Get-CasaEmpresa { $e = [ordered]@{}; $c = (Get-CasaConfig).empresa; $i = if ($CasaCliente) { $CasaCliente.empresa } else { $null }
  foreach ($k in $CasaEmpresaFab.Keys) { $e[$k] = if ("$($c[$k])".Trim()) { "$($c[$k])".Trim() } elseif ($i -and "$($i.$k)".Trim()) { "$($i.$k)".Trim() } else { $CasaEmpresaFab[$k] } }; $e }

# Mapa de CASA: primero el de ESTA PC (equipos.<PC>.mapa, para una PC con otra escala o versión), luego el general
# de la empresa (mapa) y al final los valores de fábrica.
function Get-CasaMapaPc { $e = (Get-CasaConfig).equipos[$CasaEquipo]; if ($e -and $e.mapa) { ConvertTo-CasaHash $e.mapa } else { @{} } }
function Get-CasaMapa {
  $m = [ordered]@{}; $c = (Get-CasaConfig).mapa; $p = Get-CasaMapaPc
  foreach ($k in $CasaMapaFab.Keys) { $m[$k] = if ($null -ne $p[$k] -and "$($p[$k])" -ne '') { $p[$k] } elseif ($null -ne $c[$k] -and "$($c[$k])" -ne '') { $c[$k] } else { $CasaMapaFab[$k] } }; $m
}
function Get-CasaMapaOrigen { if ((Get-CasaMapaPc).Count) { 'esta PC' } elseif ((Get-CasaConfig).mapa.Count) { 'general' } else { 'fábrica' } }
$Global:CasaEmpresa = Get-CasaEmpresa
$Global:CasaMapa = Get-CasaMapa
$Global:CasaPat = $CasaEmpresa.patente
# Referencia del expediente: prefijo + 4 últimos dígitos del pedimento (p. ej. AYC26-8031)
# Tablero de pendientes (Firebase, empresas/<id>): el de la config; A&C (patente 1664, sin cliente.json) usa sus rutas de siempre ('ayc').
function Get-CasaTablero { $t = "$($CasaEmpresa.tablero)".Trim().ToLower(); if ($t) { $t } elseif (-not $CasaCliente -and $CasaEmpresa.patente -eq '1664') { 'ayc' } else { "p$($CasaEmpresa.patente)" } }
function Get-CasaRef([string]$Pedimento) { $CasaEmpresa.prefijo + $Pedimento.Substring($Pedimento.Length - 4) }

# ---------- licencia ----------
# Licencia por número de PCs, firmada por el dueño de la app con su llave privada (que NUNCA está aquí; vive en el
# Generador de licencias). Aquí solo va la llave pública para comprobar la firma. Sin licencia válida la app se bloquea.
# Todas las empresas necesitan licencia, también A&C Global Logistics (patente 1664), donde se hizo la app.
$Global:CasaLicPub = @{ n = '8whSELEe5RiuWnTn3NZzasomOIY6SvyzOfzyj3nPBJFMY6ioeHPf2G+60Py/Yks11HNGvJFGxHV3Z30yBfEoAzppVHCM2qqU8zrL1w2wmr6gutdH+xPEmFWofdqVjM8/TeSmIz3Y3HCo6eTDnkAFdSlZwmY8JTZFzFOFvAnMSBHRe/zjeHKtUBW9+vyFGGC4qUVsRXaPtyHvXtmDH2Sz0v6vPM4FyD8Lu1zW2Og0deA+eVebLxvTVbYzwp68N0RfGYbYe4J2NdCKhaXzf7X5/smSnxsvYqlZ6D2V4X8b1A17dmckq2xHnzhvhLPxmRGYdZGyR2NGPT5lCXAuBs3IjLpmGDXdBj+JYnHFv0zlEO4W1tsn96EBtzdWAk99Dpzlmjno2EFpLeAAO3Gl4fPemszUBpuS3ZXSHGlUJatzn1l/sGdBIuWnDJKO4L3x8uG2P/7NofEodAZ6eq25IVaADyjp13/7txCPHaXR0Wm/Huru1TlQR3rWMZAz4w1ble0p'; e = 'AQAB'; huella = 'C496FEF659C121BB' }   # llave pública del Generador (creada 2026-10-20)
$Global:CasaLicArch = "$PSScriptRoot\licencia.lic"
$Global:CasaLicDirPcs = "$PSScriptRoot\licencia-pcs"
# Módulos que se venden por separado (pestañas). Licencias sin "modulos" (las primeras, v1) traen todos.
$Global:CasaModulos = [ordered]@{ expediente = 'Expediente'; lote = 'Varios pedimentos'; glosa = 'Glosa'; pendientes = 'Pendientes' }
function Get-CasaLicTexto($l) { $t = "EXPCASA-LIC|v1|$($l.id)|$($l.empresa)|$($l.patente)|$($l.pcs)|$($l.vence)|$($l.emitida)"; if ("$($l.modulos)") { $t.Replace('|v1|', '|v2|') + "|$($l.modulos)" } else { $t } }
function Test-CasaLicFirma($l) {
  if (-not $CasaLicPub.n -or -not $l.firma) { return $false }
  $rsa = New-Object Security.Cryptography.RSACng; $pa = New-Object Security.Cryptography.RSAParameters
  try {
    $pa.Modulus = [Convert]::FromBase64String($CasaLicPub.n); $pa.Exponent = [Convert]::FromBase64String($CasaLicPub.e); $rsa.ImportParameters($pa)
    $rsa.VerifyData([Text.Encoding]::UTF8.GetBytes((Get-CasaLicTexto $l)), [Convert]::FromBase64String($l.firma), [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
  } catch { $false } finally { $rsa.Dispose() }
}
# ---------- actualizaciones por internet (instalaciones de otras agencias: con cliente.json) ----------
# El dueño publica desde el Generador un ZIP y manifest.json FIRMADO con la misma llave de las licencias. Aquí solo se
# acepta si la firma es válida y el SHA-256 del ZIP coincide: nadie puede colar una versión falsa. A&C se actualiza por OneDrive.
$Global:CasaUpdBase = 'https://raw.githubusercontent.com/PaucoXD/expedito-actualizaciones/main'
function Get-CasaUpdBase { if ($CasaCliente -and "$($CasaCliente.actualizaciones)") { "$($CasaCliente.actualizaciones)".TrimEnd('/') } else { $CasaUpdBase } }
function Get-CasaUpdTexto($m) { "EXPEDITO-UPD|v1|$($m.version)|$($m.archivo)|$($m.sha256)|$($m.tamano)" }
function Test-CasaUpdFirma($m) {
  if (-not $CasaLicPub.n -or -not $m.firma) { return $false }
  $rsa = New-Object Security.Cryptography.RSACng; $pa = New-Object Security.Cryptography.RSAParameters
  try { $pa.Modulus = [Convert]::FromBase64String($CasaLicPub.n); $pa.Exponent = [Convert]::FromBase64String($CasaLicPub.e); $rsa.ImportParameters($pa)
    $rsa.VerifyData([Text.Encoding]::UTF8.GetBytes((Get-CasaUpdTexto $m)), [Convert]::FromBase64String($m.firma), [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
  } catch { $false } finally { $rsa.Dispose() }
}
# Devuelve el manifiesto si hay una versión más nueva y bien firmada; $null si no (o si no hay internet).
function Get-CasaActualizacion([string]$Actual) {
  [Net.ServicePointManager]::SecurityProtocol = 'Tls12'
  # como texto y luego JSON: GitHub lo sirve como text/plain y PS 5.1 no lo convierte solo (ni si trae BOM)
  try { $w = Invoke-WebRequest -UseBasicParsing -Uri "$(Get-CasaUpdBase)/manifest.json?t=$([DateTime]::UtcNow.Ticks)" -TimeoutSec 10
    $m = ("$($w.Content)" -replace '^(﻿|ï»¿)', '') | ConvertFrom-Json } catch { return $null }
  if (-not $m -or -not $m.version -or $m.archivo -notmatch '^[\w.-]+\.zip$' -or -not (Test-CasaUpdFirma $m)) { return $null }
  try { if ([version]$m.version -le [version]$Actual) { return $null } } catch { return $null }
  $m
}
# Descarga y comprueba el ZIP, y deja corriendo un ayudante que espera a que Expedito se cierre (los .dll están en uso),
# copia los archivos nuevos sobre la carpeta de la app (sin tocar licencia, cliente.json ni config.json) y lo vuelve a abrir.
function Install-CasaActualizacion($m, [int]$EsperarPid) {
  if (-not (Test-CasaUpdFirma $m)) { throw 'La actualización no tiene una firma válida' }
  $tmp = Join-Path $env:TEMP "expedito_upd_$($m.version)"; if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
  New-Item -ItemType Directory -Force "$tmp\archivos" | Out-Null; $zip = "$tmp\$($m.archivo)"
  [Net.ServicePointManager]::SecurityProtocol = 'Tls12'
  Invoke-WebRequest -UseBasicParsing -Uri "$(Get-CasaUpdBase)/$($m.archivo)?t=$([DateTime]::UtcNow.Ticks)" -OutFile $zip -TimeoutSec 120
  if ((Get-Item -LiteralPath $zip).Length -ne [long]$m.tamano -or (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ne "$($m.sha256)".ToUpper()) { throw 'El archivo descargado no coincide con la actualización firmada (se descartó)' }
  Unblock-File -LiteralPath $zip; Expand-Archive -LiteralPath $zip -DestinationPath "$tmp\archivos" -Force
  if (-not (Test-Path -LiteralPath "$tmp\archivos\expediente-app.ps1")) { throw 'La actualización no trae la app' }
  $app = $CasaHome; $log = "$env:TEMP\expedito_actualizacion.log"
  $ayu = @"
`$ErrorActionPreference = 'Stop'
function L(`$t) { Add-Content -LiteralPath '$log' -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), `$t) -Encoding UTF8 }
try {
  L 'Esperando a que se cierre Expedito ($EsperarPid)…'
  for (`$i = 0; `$i -lt 120 -and (Get-Process -Id $EsperarPid -ErrorAction SilentlyContinue); `$i++) { Start-Sleep -Milliseconds 500 }
  Start-Sleep -Seconds 1
  `$orig = '$tmp\archivos'; `$n = 0
  foreach (`$f in Get-ChildItem -LiteralPath `$orig -Recurse -File) {
    `$rel = `$f.FullName.Substring(`$orig.Length + 1); if (`$rel -match '^(cliente\.json|licencia\.lic|config\.json|licencia-pcs\\|cola\\|plantillas\\)') { continue }
    `$dst = Join-Path '$app' `$rel; `$d = Split-Path `$dst; if (-not (Test-Path -LiteralPath `$d)) { New-Item -ItemType Directory -Force `$d | Out-Null }
    for (`$k = 0; `$k -lt 10; `$k++) { try { Copy-Item -LiteralPath `$f.FullName -Destination `$dst -Force; break } catch { Start-Sleep -Milliseconds 700 } }
    Unblock-File -LiteralPath `$dst -ErrorAction SilentlyContinue; `$n++
  }
  L "Actualizado a v$($m.version): `$n archivo(s)"
} catch { L "ERROR: `$(`$_.Exception.Message)" }
Start-Process -FilePath "`$env:WINDIR\System32\wscript.exe" -ArgumentList '"$app\abrir.vbs"'
"@
  [IO.File]::WriteAllText("$tmp\actualizar.ps1", $ayu, (New-Object Text.UTF8Encoding $true))
  [IO.File]::WriteAllText("$tmp\actualizar.vbs", "CreateObject(""WScript.Shell"").Run ""powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """"$tmp\actualizar.ps1"""""", 0, False", (New-Object Text.ASCIIEncoding))
  # a través del Explorador (como doble clic): lanzar powershell directo desde la app que se va a cerrar fallaba (0xc0000142)
  Start-Process -FilePath explorer.exe -ArgumentList "`"$tmp\actualizar.vbs`""
}

# PCs que usan la licencia: licencia-pcs\<PC>.json (alta = primer día, visto = último día). Cuentan las vistas en los últimos 45 días.
function Get-CasaLicPcs {
  @(Get-ChildItem -LiteralPath $CasaLicDirPcs -Filter *.json -File -ErrorAction SilentlyContinue | ForEach-Object { $o = Read-CasaJson $_.FullName; if ($o -and $o.pc) { [pscustomobject]@{ Pc = "$($o.pc)"; Alta = [datetime]$o.alta; Visto = [datetime]$o.visto; Usuario = "$($o.usuario)" } } } | Sort-Object Alta)
}
function Get-CasaLicencia([switch]$Registrar, [string]$Archivo = $CasaLicArch) {
  $r = [pscustomobject]@{ Ok = $false; Exenta = $false; Motivo = ''; Empresa = ''; Patente = ''; Pcs = 0; Vence = $null; Dias = 0; Id = ''; Usadas = 0; Activas = @(); Modulos = @($CasaModulos.Keys) }
  # Ya no hay patentes exentas (antes la 1664 de A&C): cualquiera podía poner 1664 y usarla gratis. A&C usa su licencia firmada.
  $l = Read-CasaJson $Archivo
  if (-not $l) { $r.Motivo = 'No hay licencia. Carga el archivo .lic en Configuración → Licencia.'; return $r }
  $r.Empresa = "$($l.empresa)"; $r.Patente = "$($l.patente)"; $r.Pcs = [int]$l.pcs; $r.Id = "$($l.id)"
  if (-not (Test-CasaLicFirma $l)) { $r.Motivo = 'La licencia no es válida (fue modificada o no la emitió el dueño de la app).'; return $r }
  if ("$($l.modulos)") { $r.Modulos = @("$($l.modulos)".Split(',') | Where-Object { $CasaModulos.Contains($_) }) }
  if ($l.patente -ne $CasaEmpresa.patente) { $r.Motivo = "La licencia es para la patente $($l.patente) y la app está configurada con la patente $($CasaEmpresa.patente)."; return $r }
  $r.Vence = [datetime]::ParseExact("$($l.vence)", 'yyyy-MM-dd', $null); $hoy = (Get-Date).Date; $r.Dias = [int]($r.Vence - $hoy).TotalDays
  $todas = Get-CasaLicPcs; $mia = $todas | Where-Object Pc -eq $CasaEquipo | Select-Object -First 1
  if ($mia -and $hoy -lt $mia.Visto.AddDays(-2)) { $r.Motivo = "La fecha de esta PC está atrasada ($($hoy.ToString('d MMM yyyy'))). Corrígela en Windows."; return $r }
  if ($hoy -gt $r.Vence) { $r.Motivo = "La licencia venció el $($r.Vence.ToString('d MMM yyyy')). Pide la renovación."; return $r }
  $act = @($todas | Where-Object { $_.Visto -ge $hoy.AddDays(-45) }); $r.Activas = $act; $r.Usadas = $act.Count
  $lugar = if ($mia) { [array]::IndexOf(@($act | ForEach-Object Pc), $CasaEquipo) } else { -1 }
  if (($lugar -lt 0 -and $act.Count -ge $r.Pcs) -or $lugar -ge $r.Pcs) { $r.Motivo = "Ya se usan las $($r.Pcs) PC(s) de la licencia ($((@($act | ForEach-Object Pc)) -join ', ')). Libera una en Configuración → Licencia o pide más PCs."; return $r }
  if ($Registrar) {
    if (-not (Test-Path -LiteralPath $CasaLicDirPcs)) { New-Item -ItemType Directory -Force $CasaLicDirPcs | Out-Null }
    $alta = if ($mia) { $mia.Alta.ToString('yyyy-MM-dd') } else { $hoy.ToString('yyyy-MM-dd') }
    Write-CasaJson "$CasaLicDirPcs\$CasaEquipo.json" ([ordered]@{ pc = $CasaEquipo; alta = $alta; visto = $hoy.ToString('yyyy-MM-dd'); usuario = $env:USERNAME })
    if (-not $mia) { $r.Usadas++ }
  }
  $r.Ok = $true; $r.Motivo = "Licencia de $($r.Empresa) · $($r.Usadas) de $($r.Pcs) PC(s) · vence $($r.Vence.ToString('d MMM yyyy'))"
  if ($r.Modulos.Count -lt $CasaModulos.Count) { $r.Motivo += " · módulos: $(($r.Modulos | ForEach-Object { $CasaModulos[$_] }) -join ', ')" }; $r
}

# ---------- cola del remoto (opcional) ----------
# Una PC marcada como "remoto" trabaja los pedimentos que mandan las demás. Todo va por la carpeta cola\ junto a la app (OneDrive):
#   pendientes\<id>.json  lo crea quien manda        trabajando\, hechos\  los mueve el remoto
#   estado\<ped>.json     avance que escribe el remoto  remoto.json  señal de vida del remoto
$Global:CasaCola = "$PSScriptRoot\cola"
function Get-CasaColaDir([string]$sub) { $d = Join-Path $CasaCola $sub; if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force $d | Out-Null }; $d }
function Read-CasaJson([string]$f) { if (Test-Path -LiteralPath $f) { try { Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $null } } }
# se escribe a un temporal y se renombra, para que OneDrive nunca suba un archivo a medias
function Write-CasaJson([string]$f, $o) {
  $t = "$f.$PID.tmp"; ($o | ConvertTo-Json -Depth 4 -Compress) | Set-Content -LiteralPath $t -Encoding UTF8
  try { Move-Item -LiteralPath $t -Destination $f -Force -ErrorAction Stop } catch { Remove-Item -LiteralPath $t -Force -ErrorAction SilentlyContinue }
}
function Send-CasaCola([string[]]$Pedimentos, [bool]$Casa) {
  $d = Get-CasaColaDir 'pendientes'; $i = 0
  foreach ($p in $Pedimentos) {
    $id = "$(Get-Date -Format 'yyyyMMdd-HHmmss')-$('{0:d2}' -f $i)_$($p)_$CasaEquipo.json"; $i++
    Write-CasaJson "$d\$id" ([ordered]@{ id = $id; ped = $p; casa = $Casa; de = $CasaEquipo; fecha = (Get-Date -Format s) })
    [pscustomobject]@{ Ped = $p; Id = $id }
  }
}
function Get-CasaRemoto { $r = Read-CasaJson "$CasaCola\remoto.json"; if ($r) { $r | Add-Member -NotePropertyName Hace -NotePropertyValue ((Get-Date).ToUniversalTime() - [datetime]::Parse($r.utc).ToUniversalTime()).TotalSeconds -PassThru } }

# ---------- rutas de este equipo ----------
function Find-CasaRoot {
  $e = Get-CasaEquipoCfg; if ($e.raiz -and (Test-Path -LiteralPath $e.raiz)) { return $e.raiz }
  $car = $CasaEmpresa.carpeta
  $hermana = Join-Path (Split-Path $CasaHome) $car; if (Test-Path -LiteralPath $hermana) { return $hermana }   # app junto a la carpeta de expedientes
  $ods = @($env:OneDriveCommercial, $env:OneDrive) + @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'OneDrive - *' -ErrorAction SilentlyContinue | ForEach-Object FullName)
  foreach ($od in ($ods | Where-Object { $_ } | Select-Object -Unique)) {
    $p = Join-Path $od $car; if (Test-Path -LiteralPath $p) { return $p }
    foreach ($b in @(Get-ChildItem -LiteralPath $od -Directory -ErrorAction SilentlyContinue)) { $p = Join-Path $b.FullName $car; if (Test-Path -LiteralPath $p) { return $p } } }
  $null
}
function Find-CasaWinDir {
  $e = Get-CasaEquipoCfg; if ($e.casa -and (Test-Path -LiteralPath $e.casa)) { return $e.casa }
  $p = Get-Process csaaiwin -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p -and $p.Path) { return (Split-Path $p.Path) }
  'C:\CASAWIN\CSAAIWIN'
}
function Find-CasaTransmit {
  $e = Get-CasaEquipoCfg; if ($e.transmit -and (Test-Path -LiteralPath $e.transmit)) { return $e.transmit }
  $pa = "$($CasaEmpresa.patente)-$($CasaEmpresa.aduana)"
  foreach ($p in "X:\TRANSMIT\$pa", "\\server24\CASAWIN\TRANSMIT\$pa", (Join-Path (Find-CasaWinDir) "TRANSMIT\$pa"), (Join-Path (Split-Path (Find-CasaWinDir)) "TRANSMIT\$pa")) { if (Test-Path -LiteralPath $p) { return $p } }
  "X:\TRANSMIT\$pa"
}
function Find-CasaVucem { $e = Get-CasaEquipoCfg; if ($e.vucem -and (Test-Path -LiteralPath $e.vucem)) { return $e.vucem }; Join-Path (Find-CasaWinDir) 'Almacen VUCEM' }
function Find-CasaPlantilla {
  $e = Get-CasaEquipoCfg; if ($e.plantilla -and (Test-Path -LiteralPath $e.plantilla)) { return $e.plantilla }
  $t = Get-ChildItem -LiteralPath "$CasaHome\plantillas" -Filter 'FAYC-0122*.xlsx' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($t) { return $t.FullName }
  $d = Get-ChildItem -LiteralPath ([Environment]::GetFolderPath('Desktop')) -Filter 'FAYC-0122*.xlsx' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($d) { $d.FullName }
}
$Global:CasaRoot      = Find-CasaRoot                     # raíz de TODOS los clientes
$Global:CasaVucem     = Find-CasaVucem
$Global:CasaTransmit  = Find-CasaTransmit
$Global:CasaPlantilla = Find-CasaPlantilla

if (-not ('CasaWin' -as [type])) {
Add-Type @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class CasaWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc p, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc p, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, string l);
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
  public static string Text(IntPtr h){ var s=new StringBuilder(512); GetWindowText(h,s,512); return s.ToString(); }
  public static string Cls(IntPtr h){ var s=new StringBuilder(256); GetClassName(h,s,256); return s.ToString(); }
  public static List<IntPtr> Tops(){ var r=new List<IntPtr>(); EnumWindows((h,l)=>{ if(IsWindowVisible(h)) r.Add(h); return true; }, IntPtr.Zero); return r; }
  public static List<IntPtr> Kids(IntPtr p){ var r=new List<IntPtr>(); EnumChildWindows(p,(h,l)=>{ r.Add(h); return true; }, IntPtr.Zero); return r; }
}
"@
}

# Títulos de ventanas visibles (para saber en qué paso está CASA sin capturas).
function Get-CasaVentanas { [CasaWin]::Tops() | ForEach-Object { [CasaWin]::Text($_) } | Where-Object { $_ } }

# Espera un diálogo de guardar/exportar de CASA, escribe la ruta y pulsa Guardar.
# No sobrescribe: si el archivo ya existe, cancela y avisa.
function Save-CasaDialogo {
  param([Parameter(Mandatory)][string]$Ruta, [int]$Timeout = 60)
  $titulos = 'Guardar impresión como','Exportar a:','Guardar como'
  $dlg = $null
  for ($i = 0; $i -lt $Timeout -and -not $dlg; $i++) {
    $dlg = [CasaWin]::Tops() | Where-Object { $titulos -contains [CasaWin]::Text($_) } | Select-Object -First 1
    if (-not $dlg) { Start-Sleep 1 }
  }
  if (-not $dlg) { return "ERROR: no apareció la ventana de guardar en $Timeout s" }
  Start-Sleep -Milliseconds 1500   # la ventana termina de cargar su carpeta
  $kids = [CasaWin]::Kids($dlg)
  $edit = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' -and [CasaWin]::Cls([CasaWin]::GetParent($_)) -eq 'ComboBox' } | Select-Object -First 1
  if (-not $edit) { $edit = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' } | Select-Object -First 1 }
  $btnOk  = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Guardar' } | Select-Object -First 1
  $btnCan = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Cancelar' } | Select-Object -First 1
  if (-not $edit -or -not $btnOk) { return "ERROR: no encontré el campo o el botón Guardar" }
  if (Test-Path -LiteralPath $Ruta) {
    if ($btnCan) { [void][CasaWin]::SendMessage($btnCan, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) }
    return "YA EXISTE (cancelado): $(Split-Path $Ruta -Leaf)"
  }
  [void][CasaWin]::SendMessage($edit, 0x000C, [IntPtr]::Zero, $Ruta)        # WM_SETTEXT
  $leido = [CasaWin]::Text($edit)
  if ($leido -ne $Ruta) { return "ERROR: el campo quedó con '$leido'" }
  [void][CasaWin]::SendMessage($btnOk, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) # BM_CLICK
  for ($i = 0; $i -lt 30; $i++) { if (Test-Path -LiteralPath $Ruta) { return "OK: $(Split-Path $Ruta -Leaf)" }; Start-Sleep 1 }
  return "ERROR: no se creó $(Split-Path $Ruta -Leaf)"
}

# Guarda varios diálogos seguidos (p. ej. las 4 copias T_/IMP_/AA_/S_).
function Save-CasaVarios { param([string[]]$Rutas) foreach ($r in $Rutas) { Save-CasaDialogo -Ruta $r } }

# Carpetas de expediente con ese pedimento en TODA la raíz de clientes (hasta 4 niveles; sin las que están dentro de otra).
function Get-CasaCarpetas { param([string]$Pedimento)
  $c = @(Get-ChildItem -LiteralPath $CasaRoot -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "(^|\D)$Pedimento(\D|$)" } | ForEach-Object FullName)
  $c | Where-Object { $p = $_; -not ($c | Where-Object { $_ -ne $p -and $p.StartsWith($_ + '\') }) }
}
# La carpeta del pedimento si es única; si hay varias, error (indicar -Dir).
function Get-CasaCarpeta { param([string]$Pedimento)
  $c = @(Get-CasaCarpetas $Pedimento)
  if ($c.Count -gt 1) { throw "Hay $($c.Count) carpetas con $Pedimento`: $($c -join ' | '). Indica cuál con -Dir." }
  $c | Select-Object -First 1
}
# Cliente = primera carpeta debajo de la raíz.
function Get-CasaCliente { param([string]$Dir) if ($Dir -and $Dir.StartsWith($CasaRoot + '\')) { $Dir.Substring($CasaRoot.Length + 1).Split('\')[0] } }

# Tipo de operación del pedimento según el archivo de validación M (registro 501, 5.º campo): 1 = impo, 2 = expo, 0 = no se sabe.
function Get-CasaOp { param([string]$Pedimento, [string]$Dir)
  $ms = @(); if ($Dir) { $ms += Get-ChildItem -LiteralPath $Dir -File | Where-Object Name -match "^M$CasaPat\d+\.\d{3}`$" }
  foreach ($m in $ms) {
    $ls = Get-Content -LiteralPath $m.FullName -TotalCount 8
    # 501 = pedimento normal (operación en el campo 5); 601 = consolidado (p. ej. RT; operación en el campo 6)
    $l = $ls | Where-Object { $_ -match "^501\|\d+\|$Pedimento\|" } | Select-Object -First 1; if ($l) { return [int](($l -split '\|')[4]) }
    $l = $ls | Where-Object { $_ -match "^601\|\d+\|$Pedimento\|" } | Select-Object -First 1; if ($l -and ($l -split '\|')[5] -match '^[12]$') { return [int](($l -split '\|')[5]) }
  }
  # sin archivo M: por la 2.ª copia del pagado que ya esté guardada
  if ($Dir) { $n = (Get-ChildItem -LiteralPath $Dir -File).Name; if ($n -match '^EXP_.*\.pdf$') { return 2 }; if ($n -match '^IMP_.*\.pdf$') { return 1 } }
  0
}
# Prefijo de la 2.ª copia del pagado: IMP_ en impo, EXP_ en expo.
function Get-CasaPrefijos { param([int]$Op) @('T_', $(if ($Op -eq 2) { 'EXP_' } else { 'IMP_' }), 'AA_', 'S_') }

# Revisión inicial: qué falta, copia XML de VUCEM, COVE, CR y candidatos de validación/pago.
# -SoloRevisar: solo dice qué falta (no copia XML ni busca en TRANSMIT; es rápido).
function Start-CasaExpediente {
  param([Parameter(Mandatory)][string]$Pedimento, [string]$Dir, [switch]$SoloRevisar)
  $ref = Get-CasaRef $Pedimento
  $dir = if ($Dir) { $Dir } else { Get-CasaCarpeta $Pedimento }
  if (-not $dir) { return "ERROR: no hay carpeta con $Pedimento" }
  $n = Get-ChildItem -LiteralPath $dir -File | ForEach-Object Name
  $op = Get-CasaOp $Pedimento $dir; $c2 = (Get-CasaPrefijos $op)[1]
  $chk = [ordered]@{ 'T_'='^T_'; $c2="^$c2"; 'AA_'='^AA_'; 'S_'='^S_'; 'SIMP_'='^SIMP_'; 'COVE'='^COVE.*\.pdf$'; 'AcuseCOVE'='^Reporte_ACUSE_COVE'; 'AMV_'='^AMV_'; 'MV_'='^MV_'; 'XML'='_COVE\.xml$'; 'Validacion'="^[Mk]$CasaPat\d+\.\d{3}`$"; 'Pago'="^(E|a|ke)$CasaPat\d+\.\d{3}`$"; 'FAYC'='^FAYC-0122.*\.pdf$'; 'ZIP'='^EXPEDIENTE_.*\.zip$' }
  if ($op -eq 2) { $chk.Remove('AMV_'); $chk.Remove('MV_') }   # expo: no lleva manifestación
  $falt = @($chk.Keys | Where-Object { -not ($n -match $chk[$_]) })
  $copiados = 0
  if ($SoloRevisar) { return [pscustomobject]@{ Referencia = $ref; Carpeta = Split-Path $dir -Leaf; Op = $op; Faltan = $falt -join ', ' } }
  Get-ChildItem -LiteralPath $CasaVucem -Filter "*$ref*" | ForEach-Object { if (-not (Test-Path -LiteralPath "$dir\$($_.Name)")) { Copy-Item -LiteralPath $_.FullName -Destination $dir; $copiados++ } }
  $coves = Get-ChildItem -LiteralPath $CasaVucem -Filter "*$ref*COVEConsultaResult.xml" | Select-String 'COVE[0-9A-Z]{9}' -AllMatches | ForEach-Object { $_.Matches.Value } | Where-Object { $_ -ne 'CoveServicioR' } | Select-Object -Unique
  $xs = Get-ChildItem -LiteralPath $CasaVucem -Filter "*$ref*" | Sort-Object LastWriteTime; $desde = if ($xs) { $xs[0].LastWriteTime.Date.AddDays(-3) } else { (Get-Date).AddDays(-60) }; $hasta = $desde.AddDays(40); $cand = Get-ChildItem -LiteralPath $CasaTransmit -File | Where-Object { $_.Name -match "^(M|k|E|a|ke)$CasaPat\d+\.\d{3}`$" -and $_.LastWriteTime -ge $desde -and $_.LastWriteTime -le $hasta } |
          Select-String -Pattern $Pedimento -List | ForEach-Object { Get-Item $_.Path } | Sort-Object LastWriteTime
  [pscustomobject]@{
    Referencia = $ref; Carpeta = Split-Path $dir -Leaf; Op = $op
    Faltan     = $falt -join ', '
    XMLcopiados = $copiados
    COVE       = $coves -join ', '
    Transmit   = ($cand | ForEach-Object { "$($_.Name) $($_.LastWriteTime.ToString('dd/MM HH:mm'))" }) -join ' | '
    Candidatos = @($cand)
  }
}

# Copia archivos de X:\TRANSMIT (y el .err si es del mismo día que la validación) y devuelve el CR.
function Copy-CasaTransmit {
  param([Parameter(Mandatory)][string]$Pedimento, [Parameter(Mandatory)][string[]]$Archivos, [string]$Dir)
  $dir = if ($Dir) { $Dir } else { Get-CasaCarpeta $Pedimento }
  foreach ($a in $Archivos) {
    $s = Join-Path $CasaTransmit $a
    if (-not (Test-Path -LiteralPath $s)) { "NO EXISTE: $a"; continue }
    if (Test-Path -LiteralPath "$dir\$a") { "YA ESTABA: $a"; continue }
    Copy-Item -LiteralPath $s -Destination $dir; "copiado: $a"
  }
  $m = $Archivos | Where-Object { $_ -match "^M$CasaPat(\d+)\.(\d{3})`$" } | Select-Object -First 1
  if ($m -match "^M$CasaPat(\d+)\.(\d{3})`$") {
    $err = Join-Path $CasaTransmit "m$CasaPat$($Matches[1]).err"; $k = Join-Path $CasaTransmit ("k$CasaPat$($Matches[1]).$($Matches[2])")
    if ((Test-Path $err) -and (Test-Path $k) -and [math]::Abs(((Get-Item $err).LastWriteTime - (Get-Item $k).LastWriteTime).TotalMinutes) -lt 5 -and -not (Test-Path "$dir\m$CasaPat$($Matches[1]).err")) {
      Copy-Item -LiteralPath $err -Destination $dir; "copiado: m$CasaPat$($Matches[1]).err" }
    $cr = Get-Content -LiteralPath (Join-Path $CasaTransmit $m) | Where-Object { $_ -match "^507\|$Pedimento\|CR\|" } | ForEach-Object { ($_ -split '\|')[3] }
    "CR: " + $(if ($cr) { "$cr -> $(if ((Get-CasaConfig).cr[$cr]) { (Get-CasaConfig).cr[$cr] } else { 'sin recinto (dalo de alta en Configuración → Recintos y gastos)' })" } else { 'no viene (preguntar recinto)' })
  }
}

# Genera la FAYC-0122 en PDF a partir de una copia de la plantilla (la plantilla nunca se modifica).
# -GastosTerceros: "Gastos a terceros facturar a". -Si: conceptos en SI (llaves de $CasaFaycSiNo); los demás quedan en NO.
function New-CasaFayc {
  param([Parameter(Mandatory)][string]$Pedimento, [Parameter(Mandatory)][datetime]$FechaPago,
        [Parameter(Mandatory)][string]$Recinto, [int]$Remesas = 0, [ValidateSet('NO','SI')][string]$Rojo = 'NO',
        [string]$GastosTerceros = '', [string[]]$Si = @(), [string]$Dir, [string]$Elaboro)
  if (-not $Elaboro) { $Elaboro = (Get-CasaEquipoCfg).elaboro }; if (-not $Elaboro) { throw 'Falta quién elaboró la FAYC' }
  if (-not $CasaPlantilla) { throw "No encontré la plantilla FAYC-0122 (ponla en $CasaHome\plantillas)" }
  $ref = Get-CasaRef $Pedimento
  $dir = if ($Dir) { $Dir } else { Get-CasaCarpeta $Pedimento }
  $out = "$dir\FAYC-0122 SELLO INSTRUCCIONES DE FACTURACIÓN EDITABLE 2026.pdf"
  if (Test-Path -LiteralPath $out) { return "FAYC YA EXISTE" }
  foreach ($x in $Si) { if (-not $CasaFaycSiNo.Contains($x)) { throw "Concepto desconocido: $x" } }
  $es = [Globalization.CultureInfo]'es-MX'
  $f1 = $FechaPago.ToString("d 'de' MMMM 'de' yyyy", $es); $f2 = (Get-Date).ToString("d 'de' MMMM 'de' yyyy", $es)
  $tmp = Join-Path $env:TEMP "fayc_$Pedimento.xlsx"
  $in = [IO.File]::Open($CasaPlantilla, 'Open', 'Read', 'ReadWrite'); $o = [IO.File]::Create($tmp); $in.CopyTo($o); $in.Close(); $o.Close()
  $xl = New-Object -ComObject Excel.Application; $xl.Visible = $false; $xl.DisplayAlerts = $false
  try {
    $wb = $xl.Workbooks.Open($tmp); $ws = $wb.Worksheets.Item("Table 1")
    $set = { param($n, $t) $cf = $ws.Shapes.Item($n).ControlFormat; $i = $null
             for ($k = 1; $k -le $cf.ListCount; $k++) { if ("$($cf.List($k))".Trim() -eq $t) { $i = $k; break } }
             if (-not $i) { throw "No encontré '$t' en $n" }; $cf.ListIndex = $i }
    $ws.Range("C3").Value2 = $ref; $ws.Range("C5").Value2 = $Pedimento; $ws.Range("F11").Value2 = $Recinto; $ws.Range("B16").Value2 = $GastosTerceros
    foreach ($k in $CasaFaycSiNo.Keys) { & $set $CasaFaycSiNo[$k] $(if ($Si -contains $k) { 'SI' } else { 'NO' }) }
    & $set 'Drop Down 20' $Rojo; & $set 'Drop Down 26' "$Remesas"; & $set 'Drop Down 28' $CasaEmpresa.ciudad; & $set 'Drop Down 27' $CasaEmpresa.patente
    & $set 'Drop Down 4' $Elaboro; & $set 'Drop Down 23' $f1; & $set 'Drop Down 6' $f2
    $tpdf = Join-Path $env:TEMP "fayc_$Pedimento.pdf"; if (Test-Path -LiteralPath $tpdf) { Remove-Item -LiteralPath $tpdf }
    $wb.ExportAsFixedFormat(0, $tpdf, 0, $true, $false, [Type]::Missing, [Type]::Missing, $false); $wb.Close($false)   # ruta corta: Excel no acepta rutas largas
  } catch { throw } finally { $xl.Quit(); [Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null; Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue }
  if (-not (Test-Path -LiteralPath $tpdf)) { throw 'Excel no generó el PDF de la FAYC' }
  Move-Item -LiteralPath $tpdf -Destination $out
  "FAYC OK: $ref | pago $f1 | $Recinto | gastos a terceros: $GastosTerceros | remesas $Remesas | rojo $Rojo | elaboró $Elaboro | en SI: " + $(if ($Si) { $Si -join ', ' } else { 'ninguno' })
}

# Crea EXPEDIENTE_<ref>.zip sin la FAYC ni las carpetas contables.
function New-CasaZip {
  param([Parameter(Mandatory)][string]$Pedimento, [string]$Dir)
  Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
  $ref = Get-CasaRef $Pedimento
  $dir = if ($Dir) { $Dir } else { Get-CasaCarpeta $Pedimento }; $zip = "$dir\EXPEDIENTE_$ref.zip"
  if (Test-Path -LiteralPath $zip) { return "ZIP YA EXISTE" }
  $files = Get-ChildItem -LiteralPath $dir -Recurse -File | Where-Object { $_.FullName -notmatch '\\EXP(EDIENTE)? CONTABLE\\' -and $_.Name -notlike 'FAYC-0122*' -and $_.Name -notlike 'GLOSA_*' -and $_.Name -notlike 'EXPEDIENTE_*.zip' }
  $tz = Join-Path $env:TEMP "EXPEDIENTE_$ref.zip"; if (Test-Path $tz) { Remove-Item $tz }
  $z = [IO.Compression.ZipFile]::Open($tz, 'Create')
  foreach ($f in $files) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z, $f.FullName, $f.FullName.Substring($dir.Length + 1).Replace('\', '/')) }
  $z.Dispose(); Move-Item -LiteralPath $tz -Destination $zip
  "ZIP OK: $($files.Count) archivos, $([math]::Round((Get-Item -LiteralPath $zip).Length / 1MB, 1)) MB"
}

# ---------- "Elaboró" de la FAYC ----------
# Lista de la plantilla (Hoja1!B5:B13); se lee una vez con Excel y queda guardada en config.json.
function Get-CasaElaboroLista([switch]$Releer) {
  $c = Get-CasaConfig
  if ($c.elaboro.Count -and -not $Releer) { return $c.elaboro }
  if (-not $CasaPlantilla) { return @() }
  $tmp = Join-Path $env:TEMP 'fayc_lista.xlsx'
  $in = [IO.File]::Open($CasaPlantilla, 'Open', 'Read', 'ReadWrite'); $o = [IO.File]::Create($tmp); $in.CopyTo($o); $in.Close(); $o.Close()
  $xl = New-Object -ComObject Excel.Application; $xl.Visible = $false; $xl.DisplayAlerts = $false
  try { $wb = $xl.Workbooks.Open($tmp, 0, $true); $cf = $wb.Worksheets.Item('Table 1').Shapes.Item('Drop Down 4').ControlFormat
        $l = @(for ($k = 1; $k -le $cf.ListCount; $k++) { "$($cf.List($k))".Trim() }) | Where-Object { $_ } | Select-Object -Unique; $wb.Close($false) }
  finally { $xl.Quit(); [Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null; Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue }
  $c.elaboro = @($l); Save-CasaConfig $c; $c.elaboro
}

# ---------- revisión del equipo ----------
# Devuelve renglones @{ Estado = OK | FALTA | AVISO; Que; Detalle } para saber si esta PC puede usar la app.
# ---------- nivel de permisos (administrador) ----------
# Windows no deja que un programa normal mande mensajes/clics a uno abierto "como administrador".
# Si CASA está como administrador y Expedito no, CASA automático no funciona (los clics se pierden).
if (-not ('CasaElev' -as [type])) {
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class CasaElev {
 [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a, bool i, int pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr p, uint a, out IntPtr t);
 [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr t, int c, out int v, int n, out int r);
 // 1 = como administrador, 0 = normal, -1 = no se pudo leer (casi siempre: es de administrador y yo no)
 public static int De(int pid) {
  IntPtr p = OpenProcess(0x1000, false, pid); if (p == IntPtr.Zero) return -1;
  try { IntPtr t; if (!OpenProcessToken(p, 0x0008, out t)) return -1;
   try { int v, r; if (!GetTokenInformation(t, 20, out v, 4, out r)) return -1; return v != 0 ? 1 : 0; } finally { CloseHandle(t); } } finally { CloseHandle(p); }
 }
}
"@
}
function Get-CasaNivel {
  $c = Get-Process csaaiwin -ErrorAction SilentlyContinue | Select-Object -First 1
  $yo = [CasaElev]::De($PID) -eq 1
  $casa = if ($c) { [CasaElev]::De($c.Id) } else { $null }
  [pscustomobject]@{ Yo = $yo; Casa = $casa; Problema = ($null -ne $casa -and $casa -ne 0 -and -not $yo) }
}
function Test-CasaEquipo {
  $r = New-Object System.Collections.ArrayList
  function Add-R($e, $q, $d) { [void]$r.Add([pscustomobject]@{ Estado = $e; Que = $q; Detalle = $d }) }
  Add-R 'OK' 'Equipo' "$CasaEquipo ($env:USERNAME), PowerShell $($PSVersionTable.PSVersion)"
  if ($CasaRoot) { Add-R 'OK' 'Carpeta de expedientes' "$CasaRoot ($(@(Get-ChildItem -LiteralPath $CasaRoot -Directory).Count) clientes)" }
  else { Add-R 'FALTA' 'Carpeta de expedientes' "No encontré la carpeta '$($CasaEmpresa.carpeta)' en OneDrive. Sincronízala o ponla en Configuración → Rutas." }
  if ($CasaPlantilla) { Add-R $(if ($CasaPlantilla.StartsWith($CasaHome)) { 'OK' } else { 'AVISO' }) 'Plantilla FAYC' $CasaPlantilla }
  else { Add-R 'FALTA' 'Plantilla FAYC' "Pon la plantilla FAYC-0122 en $CasaHome\plantillas" }
  $exe = Join-Path (Find-CasaWinDir) 'CSAAIWIN.exe'
  if (Test-Path -LiteralPath $exe) { Add-R 'OK' 'CASA instalado' $exe } else { Add-R 'FALTA' 'CASA instalado' "No está $exe" }
  $main = [CasaWin]::Tops() | Where-Object { [CasaWin]::Cls($_) -eq 'TFmMain_Menu' } | Select-Object -First 1
  if ($main) { Add-R 'OK' 'CASA abierto' 'Con sesión iniciada' } else { Add-R 'AVISO' 'CASA abierto' 'Ábrelo e inicia sesión antes de "CASA automático"' }
  $nv = Get-CasaNivel
  if ($nv.Problema) { Add-R 'FALTA' 'Permisos de CASA' 'CASA está abierto como ADMINISTRADOR y Expedito no: CASA automático no podrá dar los clics. Abre CASA normal (sin "Ejecutar como administrador") o abre Expedito también como administrador.' }
  elseif ($null -ne $nv.Casa) { Add-R 'OK' 'Permisos de CASA' $(if ($nv.Yo) { 'Expedito como administrador (puede manejar CASA)' } else { 'CASA y Expedito con el mismo nivel' }) }
  if ($nv.Yo) { Add-R 'AVISO' 'Expedito como administrador' 'Abierto como administrador puede no ver las unidades de red (p. ej. X:). Si TRANSMIT sale en rojo, ábrelo normal.' }
  if (Test-Path -LiteralPath $CasaVucem) { Add-R 'OK' 'Almacen VUCEM' $CasaVucem } else { Add-R 'FALTA' 'Almacen VUCEM' "No existe $CasaVucem" }
  if (Test-Path -LiteralPath $CasaTransmit) { Add-R 'OK' 'TRANSMIT (validación/pago)' $CasaTransmit } else { Add-R 'FALTA' 'TRANSMIT (validación/pago)' 'Conecta la unidad de CASA (p. ej. X:) o pon la ruta en Configuración → Rutas' }
  if ([type]::GetTypeFromProgID('Excel.Application')) { Add-R 'OK' 'Excel' 'Instalado' } else { Add-R 'FALTA' 'Excel' 'Se necesita para la FAYC' }
  if (Get-CimInstance Win32_Printer -Filter "Name='Microsoft Print to PDF'" -ErrorAction SilentlyContinue) { Add-R 'OK' 'Impresora PDF' 'Microsoft Print to PDF' }
  else { Add-R 'FALTA' 'Impresora PDF' 'Activa "Microsoft Print to PDF" (Características de Windows)' }
  try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if ($eng) { Add-R 'OK' 'Lector de texto (OCR)' "Idioma $($eng.RecognizerLanguage.DisplayName)" } else { Add-R 'FALTA' 'Lector de texto (OCR)' 'Agrega el idioma Español en Configuración > Hora e idioma' }
  } catch { Add-R 'FALTA' 'Lector de texto (OCR)' $_.Exception.Message }
  $el = (Get-CasaEquipoCfg).elaboro
  if ($el) { Add-R 'OK' 'Elaboró (esta PC)' $el } else { Add-R 'AVISO' 'Elaboró (esta PC)' 'Elígelo en el panel FAYC; se recuerda por equipo' }
  if (-not (Test-Path -LiteralPath $CasaConfigPath)) { Add-R 'AVISO' 'config.json' 'Se crea al guardar la primera FAYC' }
  Add-R 'AVISO' 'Primera vez en esta PC' 'Prueba un expediente completo: si la escala de pantalla es distinta, la app se detiene antes de guardar algo mal'
  $r
}

# ---------- Preparar (lo usa la app para uno o varios pedimentos) ----------
# Copia los XML de VUCEM y la validación (último M con su k) y el pago (último E con a/ke) de TRANSMIT.
# Devuelve fecha de pago, CR, operación (1 impo / 2 expo) y remesas.
function Invoke-CasaPreparar {
  param([Parameter(Mandatory)][string]$Pedimento, [Parameter(Mandatory)][string]$Dir, [scriptblock]$Log = { param($m) Write-Host $m }, [string]$Etiqueta)
  $info = Start-CasaExpediente -Pedimento $Pedimento -Dir $Dir
  & $Log "Carpeta: $(if ($Etiqueta) { $Etiqueta } else { $info.Carpeta }) | XML copiados: $($info.XMLcopiados) | COVE (VUCEM): $($info.COVE)"
  $c = $info.Candidatos
  $mm = $c | Where-Object { $_.Name -match "^M$CasaPat(\d+)\.(\d{3})`$" -and (Test-Path (Join-Path $CasaTransmit ("k$CasaPat" + $Matches[1] + '.' + $Matches[2]))) } | Sort-Object LastWriteTime | Select-Object -Last 1
  $e = $c | Where-Object { $_.Name -match "^E$CasaPat\d+\.\d{3}`$" } | Sort-Object LastWriteTime | Select-Object -Last 1
  $arch = @(); $fecha = $null; $cr = $null
  if ($mm) { $arch += $mm.Name, ('k' + $mm.Name.Substring(1)) } else { & $Log '⚠ No encontré validación M/k: revisa Monitor de Procesos' }
  if ($e) { $arch += $e.Name, ('a' + $e.Name.Substring(1)), ('ke' + $e.Name.Substring(1)); $fecha = $e.LastWriteTime } else { & $Log '⚠ No encontré pago E: revisa Monitor de Procesos' }
  if ($arch) { foreach ($l in (Copy-CasaTransmit -Pedimento $Pedimento -Archivos $arch -Dir $Dir)) { if ($l -match '^CR: (\d+)') { $cr = $Matches[1] } elseif ($l -notmatch '^CR:') { & $Log $l } } }
  [pscustomobject]@{ Fecha = $fecha; CR = $cr; Op = (Get-CasaOp $Pedimento $Dir); Remesas = @(Get-ChildItem -LiteralPath $Dir -Directory | Where-Object Name -match '^REM-').Count; Ok = $true }
}
