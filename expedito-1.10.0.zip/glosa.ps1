﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Glosa de pedimentos ANTES DE PAGAR a partir de los PDF (aéreos: pedimento contra factura y guía).
# Regla del usuario (2026-10-19): por ahora sin tolerancias, CUALQUIER diferencia se marca.
# Uso:  . "<app>\casa.ps1"; . "<app>\glosa.ps1"; Invoke-CasaGlosa -Pedimento 6108012 [-Dir ..] [-PdfPedimento ..] [-PdfFactura ..] [-PdfGuia ..]

# ---------- lectura de PDF (PdfPig, en lib\pdfpig) ----------
# El buscador de librerías va en C# (uno solo por proceso). Uno en PowerShell queda ligado al hilo que lo
# registró y, cuando ese hilo termina, rompe cualquier carga posterior (pasó con System.IO.Compression del ZIP).
if (-not ('PigResolver' -as [type])) {
Add-Type @"
using System; using System.IO; using System.Reflection; using System.Collections.Generic;
public static class PigResolver {
  static string dir; static bool on; static readonly object k = new object();
  public static void Init(string d) {
    lock (k) { dir = d; if (on) return; on = true; AppDomain.CurrentDomain.AssemblyResolve += Resolver; }
  }
  static Assembly Resolver(object s, ResolveEventArgs e) {
    try {
      if (dir == null) return null;
      string n = new AssemblyName(e.Name).Name;
      string p = Path.Combine(dir, n + ".dll");
      if (!File.Exists(p)) return null;            // solo librerías de lib\pdfpig; lo demás (System.IO.Compression, etc.) no se toca
      foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies()) {
        try { if (a.GetName().Name == n && string.Equals(a.Location, p, StringComparison.OrdinalIgnoreCase)) return a; } catch { }
      }
      return Assembly.LoadFrom(p);
    } catch { return null; }
  }
}
"@
}
function Import-PdfPig {
  if ('UglyToad.PdfPig.PdfDocument' -as [type]) { return }
  $lib = Join-Path $PSScriptRoot 'lib\pdfpig'
  if (-not (Test-Path -LiteralPath "$lib\UglyToad.PdfPig.dll")) { throw "Falta la librería para leer PDF en $lib" }
  [PigResolver]::Init($lib)
  foreach ($n in 'System.Runtime.CompilerServices.Unsafe', 'System.Buffers', 'System.Numerics.Vectors', 'System.Memory', 'Microsoft.Bcl.HashCode', 'UglyToad.PdfPig.Core', 'UglyToad.PdfPig.Tokens', 'UglyToad.PdfPig.Tokenization', 'UglyToad.PdfPig.Fonts', 'UglyToad.PdfPig') {
    [void][Reflection.Assembly]::LoadFrom("$lib\$n.dll") }
}
# Palabras en negrita salen con letras dobles ("RREEFF::"): se dejan sencillas.
function Repair-Doble([string]$w) {
  if ($w.Length -lt 4 -or $w.Length % 2 -or $w -notmatch '[A-Za-zÁÉÍÓÚÑáéíóúñ]') { return $w }   # nunca números: "3399" no es "39"
  for ($i = 0; $i -lt $w.Length; $i += 2) { if ($w[$i] -ne $w[$i + 1]) { return $w } }
  -join (0..($w.Length / 2 - 1) | ForEach-Object { $w[$_ * 2] })
}
# OCR de Windows para PDF escaneados (sin texto): renderiza cada página y la lee.
function Get-PdfLineasOcr([string]$Pdf) {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $null = [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime]
  $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
  $asT = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  $asA = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
  $W = { param($op, [Type]$t) $k = $asT.MakeGenericMethod($t).Invoke($null, @($op)); $k.Wait(); $k.Result }
  $f = & $W ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Pdf)) ([Windows.Storage.StorageFile])
  $doc = & $W ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($f)) ([Windows.Data.Pdf.PdfDocument])
  $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages(); if (-not $eng) { return @() }
  $out = New-Object System.Collections.Generic.List[string]
  for ($i = 0; $i -lt $doc.PageCount; $i++) {
    $pg = $doc.GetPage($i); $op = New-Object Windows.Data.Pdf.PdfPageRenderOptions; $op.DestinationWidth = 2200
    $ras = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream; $k = $asA.Invoke($null, @($pg.RenderToStreamAsync($ras, $op))); $k.Wait()
    $dec = & $W ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $sb = & $W ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $res = & $W ($eng.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult])
    foreach ($ln in $res.Lines) { $out.Add($ln.Text) }
  }
  $out
}
# Renglones de texto del PDF (todas las páginas), en orden de lectura. Si no trae texto (escaneado), usa OCR.
function Get-PdfLineas([string]$Pdf, [switch]$SinOcr) {
  $l = @(Get-PdfLineasTexto $Pdf)
  if (-not $SinOcr -and ($l -join '').Length -lt 30) { $script:UltimoOcr = $true; return @(Get-PdfLineasOcr $Pdf) }
  $script:UltimoOcr = $false; $l
}
function Get-PdfLineasTexto([string]$Pdf) {
  Import-PdfPig
  $tmp = Join-Path $env:TEMP ("glosa_" + [IO.Path]::GetRandomFileName() + '.pdf')
  Copy-Item -LiteralPath $Pdf -Destination $tmp   # copia: no bloquear el archivo de OneDrive
  $doc = [UglyToad.PdfPig.PdfDocument]::Open($tmp)
  try {
    $out = New-Object System.Collections.Generic.List[string]
    for ($p = 1; $p -le $doc.NumberOfPages; $p++) {
      $words = @($doc.GetPage($p).GetWords())
      # renglones: palabras a menos de 2.5 pt de altura entre sí (agrupar por franjas fijas partía números en el borde)
      $ren = $null; $yRen = $null
      foreach ($w in ($words | Sort-Object { - $_.BoundingBox.Bottom })) {
        $yb = $w.BoundingBox.Bottom
        if ($null -eq $ren -or [Math]::Abs($yRen - $yb) -gt 2.5) { if ($ren) { $out.Add((($ren | Sort-Object { $_.BoundingBox.Left } | ForEach-Object { Repair-Doble $_.Text }) -join ' ')) }; $ren = New-Object System.Collections.ArrayList; $yRen = $yb }
        [void]$ren.Add($w)
      }
      if ($ren) { $out.Add((($ren | Sort-Object { $_.BoundingBox.Left } | ForEach-Object { Repair-Doble $_.Text }) -join ' ')) }
    }
    $out
  } finally { $doc.Dispose(); Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue }
}
function ConvertTo-Num($s) { if ($null -eq $s -or "$s" -eq '') { return $null }; $t = "$s" -replace '[\$,\s]', ''; $d = 0.0; if ([decimal]::TryParse($t, [Globalization.NumberStyles]::Number, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { $d } else { $null } }
# Todos los números con decimales o enteros grandes que aparecen en un texto (para buscar un valor del pedimento).
function Get-Numeros([string]$t) {
  $t2 = $t -replace '\$\s+(\d)\s+(\d{1,3}\.\d{2})\b', '$$$1$2'   # "$ 3 30.78" -> "$330.78"
  [regex]::Matches($t2, '(?<![\w.])\d{1,3}(?:,\d{3})*(?:\.\d+)?(?![\w])|(?<![\w.])\d+(?:\.\d+)?(?![\w])') | ForEach-Object { ConvertTo-Num $_.Value } | Where-Object { $null -ne $_ }
}
# Variantes de una fecha dd/MM/yyyy como suelen aparecer en facturas y guías.
function Get-FechaVariantes([string]$f) {
  $d = [datetime]::ParseExact($f, 'dd/MM/yyyy', $null)
  $es = [Globalization.CultureInfo]'es-MX'; $en = [Globalization.CultureInfo]'en-US'
  @($d.ToString('dd/MM/yyyy'), $d.ToString('d/M/yyyy'), $d.ToString('dd-MM-yyyy'), $d.ToString('yyyy-MM-dd'), $d.ToString('MM/dd/yyyy'), $d.ToString('M/d/yyyy'), $d.ToString('dd.MM.yyyy'),
    $d.ToString('dd-MMM-yy', $en), $d.ToString('d-MMM-yy', $en), $d.ToString('dd-MMM-yyyy', $en), $d.ToString('MMM d, yyyy', $en), $d.ToString('MMMM d, yyyy', $en), $d.ToString('dd MMM yyyy', $en),
    $d.ToString('dd-MMM-yy', $es).Replace('.', ''), $d.ToString('d \de MMMM \de yyyy', $es)) | ForEach-Object { $_.ToUpper() } | Select-Object -Unique
}

# ---------- pedimento (formato de CASA: proforma o pagado) ----------
function Read-PedimentoPdf([string]$Pdf) {
  [string[]]$L = @(Get-PdfLineas $Pdf -SinOcr); $T = $L -join "`n"
  $m = { param($rx) if ($T -match $rx) { $Matches[1].Trim() } else { $null } }
  $p = [ordered]@{ Archivo = Split-Path $Pdf -Leaf; Lineas = $L }
  $p.Pedimento = & $m 'NUM\. PEDIMENTO:\s*(\d{2} \d{2} \d{4} \d{7})'
  $p.Borrador = $T -match 'BORRADOR SIN VALIDEZ|PROFORMA'
  $p.Oper = & $m 'T\. ?OPER:? (\w+)'; $p.Clave = & $m 'CVE\. PEDIMENTO: (\w+)'
  $p.TC = ConvertTo-Num (& $m 'TIPO CAMBIO: ([\d.]+)'); $p.Peso = ConvertTo-Num (& $m 'PESO BRUTO: ([\d.,]+)')
  $p.ValorUSD = ConvertTo-Num (& $m 'VALOR DOLARES: ([\d.,]+)'); $p.ValorAduana = ConvertTo-Num (& $m 'VALOR ADUANA: ([\d.,]+)')
  $p.PrecioPagado = ConvertTo-Num (& $m 'PRECIO PAGADO/VALOR COMERCIAL: ([\d.,]+)')
  $p.RFC = & $m 'RFC: ([A-Z&Ñ]{3,4}\d{6}[A-Z0-9]{3})'
  $p.Entrada = & $m 'ENTRADA (\d\d/\d\d/\d{4})'; $p.Pago = & $m '\bPAGO (\d\d/\d\d/\d{4})'
  # incrementables: renglón de números después del encabezado
  $i = [Array]::FindIndex($L, [Predicate[string]]{ param($x) $x -match 'SEGUROS FLETES EMBALAJES' })
  $p.Increm = if ($i -ge 0 -and $L[$i + 1] -match '^[\d,.\s]+$') { $n = @($L[$i + 1].Trim() -split '\s+' | ForEach-Object { ConvertTo-Num $_ }); [ordered]@{ ValSeguros = $n[0]; Seguros = $n[1]; Fletes = $n[2]; Embalajes = $n[3]; Otros = $n[4] } } else { $null }
  # cuadro de liquidación
  $p.Liq = [ordered]@{}; $p.LiqFP = @{}; $p.Tasas = @{}
  $i = [Array]::FindIndex($L, [Predicate[string]]{ param($x) $x -match 'CUADRO DE LIQUIDACION' })
  if ($i -ge 0) { for ($k = $i + 1; $k -lt [Math]::Min($L.Count, $i + 12); $k++) { if ($L[$k] -match 'DEP.SITO REFERENCIADO|LINEA DE CAPTURA') { break }
      foreach ($x in [regex]::Matches($L[$k], '\b([A-Z][A-Z/]{1,9}) (\d{1,2}) ([\d,]+)\b')) { $p.Liq[$x.Groups[1].Value] = ConvertTo-Num $x.Groups[3].Value; $p.LiqFP[$x.Groups[1].Value] = [int]$x.Groups[2].Value } } }
  foreach ($x in $L) { if ($x -match '^\d{1,2} (DTA|PRV|IVA/PRV|IGI|IGE|IEPS|CC) (\d) ([\d.]+)$') { $p.Tasas[$Matches[1]] = [pscustomobject]@{ Tipo = [int]$Matches[2]; Tasa = ConvertTo-Num $Matches[3] } } }
  $p.Efectivo = ConvertTo-Num (& $m 'EFECTIVO ([\d,]+)'); $p.Total = ConvertTo-Num (& $m '\bTOTAL ([\d,]+)')
  # proveedor y facturas
  $i = [Array]::FindIndex($L, [Predicate[string]]{ param($x) $x -match 'VINCULACION$' })
  $p.Proveedor = if ($i -ge 0) { $L[$i + 1] } else { $null }
  $p.ProveedorId = if ($p.Proveedor) { ($p.Proveedor -split ' ')[0] } else { $null }
  $p.Facturas = @(foreach ($x in $L) { if ($x -match '^(\S+) (\d\d/\d\d/\d{4}) ([A-Z]{3}) ([A-Z]{3}) ([\d,]+\.\d+) ([\d.]+) ([\d,]+\.\d+)$') {
        [pscustomobject]@{ Num = $Matches[1]; Fecha = $Matches[2]; Incoterm = $Matches[3]; Moneda = $Matches[4]; ValorMon = ConvertTo-Num $Matches[5]; Factor = ConvertTo-Num $Matches[6]; ValorUSD = ConvertTo-Num $Matches[7] } } })
  $i = [Array]::FindIndex($L, [Predicate[string]]{ param($x) $x -match 'No\.Factura-Partida' })
  $fo = @(if ($i -ge 0) { for ($k = $i; $k -lt $L.Count; $k++) { if ($L[$k] -match '^([A-Z0-9][A-Z0-9./]*(?:-[A-Z0-9]+)*?)-(\d{1,3}) \S') { $Matches[1] } } })
  $p.FacturasObs = @($fo | Select-Object -Unique)
  # guías (master M / house H)
  $g = & $m 'NO\. \(GUIA/ORDEN EMBARQUE\)/ID: (.+)'
  $p.Guias = @(if ($g) { foreach ($x in [regex]::Matches($g, '(\S+) ([MH])\b')) { [pscustomobject]@{ Num = $x.Groups[1].Value; Tipo = $x.Groups[2].Value } } })
  # identificadores
  $p.Identificadores = @(); $enBloque = $false; $visto = $false; $obs = $false
  foreach ($x in $L) {
    if ($x -match '^CLAVE/COMPL\. IDENTIFICADOR') { $enBloque = $true; $visto = $true; continue }
    if ($x -match '^OBSERVACIONES$') { $obs = $true }
    # el bloque puede seguir en la página siguiente, después del encabezado del anexo (CURP:)
    if ($visto -and -not $obs -and $x -match '^CURP:') { $enBloque = $true; continue }
    if ($x -match 'OBSERVACIONES|AGENTE ADUANAL|^PARTIDAS|NOMBRE O RAZ|^ANEXO|^NUM\. PEDIMENTO|PEDIMENTO REF') { $enBloque = $false }
    if ($enBloque -and $x.Length -lt 60 -and $x -match '^([A-Z][A-Z0-9]) ([A-Z0-9][\w./-]*(?: [\w./-]+){0,3})$' -and $x -notmatch 'ARTICULO|LEY') {
      $p.Identificadores += [pscustomobject]@{ Clave = $Matches[1]; Compl = $Matches[2].Trim() } } }
  # pedimentos relacionados que cita (virtuales: la contraparte)
  $p.Relacionados = @([regex]::Matches($T, '\b(\d{2} \d{2} \d{4} \d{7})\b') | ForEach-Object { $_.Groups[1].Value } | Where-Object { $_ -ne $p.Pedimento } | Select-Object -Unique)
  # partidas
  $p.Partidas = @()
  for ($k = 0; $k -lt $L.Count; $k++) {
    if ($L[$k] -match '^(\d{3}) (\d{8}) (\d{2}) (\d) (?:(\d) )?(\d+) ([\d.,]+) (\d+) ([\d.,]+) ([A-Z]{3}) ([A-Z]{3})') {   # el método de valoración puede venir vacío
      $pt = [ordered]@{ Sec = $Matches[1]; Fraccion = $Matches[2]; Nico = $Matches[3]; UMC = $Matches[6]; CantUMC = ConvertTo-Num $Matches[7]; UMT = $Matches[8]; CantUMT = ConvertTo-Num $Matches[9]; PaisVC = $Matches[10]; PaisOD = $Matches[11]; Contrib = [ordered]@{} }
      if ($L[$k] -match ' (IGI|IVA|DTA|IEPS|CC) ([\d.]+) (\d) (\d{1,2}) (\d+)$') { $pt.Contrib[$Matches[1]] = ConvertTo-Num $Matches[5] }
      for ($j = $k + 1; $j -lt [Math]::Min($L.Count, $k + 8); $j++) {
        if ($L[$j] -match '^(IGI|IVA|DTA|IEPS|CC) ([\d.]+) (\d) (\d{1,2}) (\d+)$') { $pt.Contrib[$Matches[1]] = ConvertTo-Num $Matches[5] }
        elseif ($L[$j] -match '^(\d+) (\d+) ([\d.]+)$') { $pt.ValorAduana = ConvertTo-Num $Matches[1]; $pt.PrecioPagado = ConvertTo-Num $Matches[2]; $pt.PrecioUnit = ConvertTo-Num $Matches[3]; break }
        elseif ($L[$j] -match '^([\d,]+\.\d{2}) (\d+) ([\d.]+)(?: (\d+))?$') { $pt.ValorUSD = ConvertTo-Num $Matches[1]; $pt.PrecioPagado = ConvertTo-Num $Matches[2]; $pt.PrecioUnit = ConvertTo-Num $Matches[3]; $pt.ValorAgregado = ConvertTo-Num $Matches[4]; break }
        elseif (-not $pt.Descripcion -and $L[$j] -match '[A-Z]{3}' -and $L[$j] -notmatch '^\d') { $pt.Descripcion = $L[$j] } }
      $p.Partidas += [pscustomobject]$pt
    }
  }
  [pscustomobject]$p
}

# ---------- revisiones ----------
function New-Rev($sec, $que, $ped, $doc, [bool]$ok, $nota, [switch]$Aviso) { [pscustomobject]@{ Seccion = $sec; Concepto = $que; Pedimento = "$ped"; Documento = "$doc"; Ok = $ok; Aviso = [bool]$Aviso; Nota = "$nota" } }
# Diferencia de redondeo (CASA calcula con valores sin redondear que el PDF no muestra): se marca en amarillo.
function New-RevRedondeo($sec, $que, $ped, $doc, $d, $lim, [string]$unidad) {
  if ($d -eq 0) { New-Rev $sec $que $ped $doc $true '' }
  elseif ([Math]::Abs($d) -le $lim) { New-Rev $sec $que $ped $doc $true "diferencia de $d $unidad por redondeo de CASA" -Aviso }
  else { New-Rev $sec $que $ped $doc $false "diferencia $d $unidad" }
}
function Test-Igual($a, $b) { $x = ConvertTo-Num $a; $y = ConvertTo-Num $b; if ($null -ne $x -and $null -ne $y) { $x -eq $y } else { "$a".Trim() -eq "$b".Trim() } }
function Format-Num($n, [int]$dec = 2) { if ($null -eq $n) { '—' } else { ([decimal]$n).ToString("N$dec", [Globalization.CultureInfo]'en-US') } }

# El propio pedimento: que sus cálculos cuadren.
function Test-GlosaPedimento($p) {
  $r = @(); $s = 'Pedimento (cálculos)'
  $inc = 0; if ($p.Increm) { foreach ($v in $p.Increm.Values) { if ($v) { $inc += $v } } }
  $np = [Math]::Max(1, $p.Partidas.Count)   # CASA redondea cada partida: el total puede variar 1 peso / 1 centavo por partida
  $fusd = ($p.Facturas | Measure-Object ValorUSD -Sum).Sum
  if ($null -ne $p.PrecioPagado -and $null -ne $p.ValorAduana) { $c = $p.PrecioPagado + $inc; $d = $p.ValorAduana - $c
    $r += New-RevRedondeo $s 'Valor aduana = precio pagado + incrementables' (Format-Num $p.ValorAduana 0) "$(Format-Num $p.PrecioPagado 0) + $(Format-Num $inc 0) = $(Format-Num $c 0)" $d $np 'pesos' }
  if ($p.TC -and $fusd -and $null -ne $p.ValorUSD) {
    $incUsd = 0; if ($p.Increm) { foreach ($v in $p.Increm.Values) { if ($v) { $incUsd += [Math]::Round($v / $p.TC, 2) } } }
    $c = $fusd + $incUsd; $d = [Math]::Round($p.ValorUSD - $c, 2)
    $r += New-RevRedondeo $s 'Valor dólares = facturas USD + incrementables / TC' (Format-Num $p.ValorUSD) "$(Format-Num $fusd) + $(Format-Num $incUsd) = $(Format-Num $c)" $d (0.05 * $np) 'USD' }
  if ($p.TC -and $fusd -and $null -ne $p.PrecioPagado) { $c = [Math]::Round($fusd * $p.TC, 0, [MidpointRounding]::AwayFromZero); $r += New-RevRedondeo $s 'Precio pagado = facturas USD × tipo de cambio' (Format-Num $p.PrecioPagado 0) "$(Format-Num $fusd) × $($p.TC) = $(Format-Num $c 0)" ($p.PrecioPagado - $c) $np 'pesos' }
  $sumVA = ($p.Partidas | Measure-Object ValorAduana -Sum).Sum
  if ($p.Partidas.Count -and $null -ne $p.ValorAduana) { $r += New-Rev $s 'Suma valor aduana de partidas' (Format-Num $p.ValorAduana 0) (Format-Num $sumVA 0) ($sumVA -eq $p.ValorAduana) "$($p.Partidas.Count) partida(s)" }
  $igi = 0; $ivaP = 0; foreach ($pt in $p.Partidas) { if ($pt.Contrib['IGI']) { $igi += $pt.Contrib['IGI'] }; if ($pt.Contrib['IVA']) { $ivaP += $pt.Contrib['IVA'] } }
  if ($p.Liq.Contains('IVA')) {
    $r += New-Rev $s 'IVA de partidas = IVA del cuadro de liquidación' (Format-Num $p.Liq['IVA'] 0) (Format-Num $ivaP 0) ($ivaP -eq $p.Liq['IVA']) ''
    $dta = if ($p.Liq.Contains('DTA')) { $p.Liq['DTA'] } else { 0 }
    foreach ($k in 'IGI/IGE', 'IGI') { if ($p.Liq.Contains($k)) { $igi = $p.Liq[$k]; break } }
    $c = [Math]::Round(0.16 * ($p.ValorAduana + $dta + $igi), 0, [MidpointRounding]::AwayFromZero)
    $fpIva = if ($p.LiqFP.Contains('IVA')) { $p.LiqFP['IVA'] } else { 0 }
    if ($c -ne $p.Liq['IVA']) {
      # temporales (p. ej. AF): CASA toma en la base el DTA al 8 al millar aunque se pague una tasa menor
      $dta8 = [Math]::Round($p.ValorAduana * 0.008, 0, [MidpointRounding]::AwayFromZero); $c8 = [Math]::Round(0.16 * ($p.ValorAduana + $dta8 + $igi), 0, [MidpointRounding]::AwayFromZero)
      if ($c8 -eq $p.Liq['IVA']) { $r += New-Rev $s 'IVA = 16 % × (valor aduana + DTA + IGI)' (Format-Num $p.Liq['IVA'] 0) "16 % × ($(Format-Num $p.ValorAduana 0) + DTA 8 al millar $(Format-Num $dta8 0) + $(Format-Num $igi 0)) = $(Format-Num $c8 0)" $true "base con DTA al 8 al millar (el DTA pagado es $(Format-Num $dta 0))$(if ($fpIva) { "; forma de pago $fpIva" })" }
      else { $r += New-Rev $s 'IVA = 16 % × (valor aduana + DTA + IGI)' (Format-Num $p.Liq['IVA'] 0) "16 % × ($(Format-Num $p.ValorAduana 0) + $(Format-Num $dta 0) + $(Format-Num $igi 0)) = $(Format-Num $c 0)" $false "diferencia $(Format-Num ($p.Liq['IVA'] - $c) 0)$(if ($fpIva) { "; forma de pago $fpIva" })" }
    } else { $r += New-Rev $s 'IVA = 16 % × (valor aduana + DTA + IGI)' (Format-Num $p.Liq['IVA'] 0) "16 % × ($(Format-Num $p.ValorAduana 0) + $(Format-Num $dta 0) + $(Format-Num $igi 0)) = $(Format-Num $c 0)" $true $(if ($fpIva) { "forma de pago $fpIva" }) }
  }
  if ($p.Liq.Contains('PRV') -and $p.Liq.Contains('IVA/PRV')) { $c = [Math]::Round(0.16 * $p.Liq['PRV'], 0, [MidpointRounding]::AwayFromZero); $r += New-Rev $s 'IVA/PRV = 16 % × PRV' (Format-Num $p.Liq['IVA/PRV'] 0) "16 % × $(Format-Num $p.Liq['PRV'] 0) = $(Format-Num $c 0)" ($c -eq $p.Liq['IVA/PRV']) '' }
  if ($p.Tasas.Contains('DTA') -and $p.Liq.Contains('DTA') -and $null -ne $p.ValorAduana) {
    $t = $p.Tasas['DTA']
    if ($t.Tipo -eq 4) { $r += New-Rev $s 'DTA = cuota fija' (Format-Num $p.Liq['DTA'] 0) "cuota $(Format-Num $t.Tasa 0)" ($p.Liq['DTA'] -eq [Math]::Round($t.Tasa, 0)) '' }
    elseif ($t.Tipo -eq 7) { $c = [Math]::Round($p.ValorAduana * $t.Tasa / 1000, 0, [MidpointRounding]::AwayFromZero); $r += New-Rev $s "DTA = $($t.Tasa) al millar × valor aduana" (Format-Num $p.Liq['DTA'] 0) "$(Format-Num $p.ValorAduana 0) × $($t.Tasa) / 1000 = $(Format-Num $c 0)" ($c -eq $p.Liq['DTA']) '' }
  }
  if ($p.Liq.Count -and $null -ne $p.Total) { $c = 0; foreach ($v in $p.Liq.Values) { $c += $v }; $r += New-Rev $s 'Total = suma del cuadro de liquidación' (Format-Num $p.Total 0) "$(($p.Liq.Keys | ForEach-Object { "$_ $(Format-Num $p.Liq[$_] 0)" }) -join ' + ') = $(Format-Num $c 0)" ($c -eq $p.Total) '' }
  if ($null -ne $p.Efectivo) {
    $ef = 0; $otras = @(); foreach ($k in $p.Liq.Keys) { if (-not $p.LiqFP[$k]) { $ef += $p.Liq[$k] } else { $otras += "$k $(Format-Num $p.Liq[$k] 0) (F.P. $($p.LiqFP[$k]))" } }
    $r += New-Rev $s 'Efectivo = conceptos con forma de pago 0' (Format-Num $p.Efectivo 0) "$(Format-Num $ef 0)" ($ef -eq $p.Efectivo) $(if ($otras) { "con otra forma de pago: $($otras -join ', ')" }) }
  $r
}
# Busca en el texto de un documento cada dato del pedimento.
function Test-Aparece($sec, $que, $valor, [string]$texto, [object[]]$nums, [switch]$Numero, [string[]]$Variantes) {
  if ($null -eq $valor -or "$valor" -eq '') { return New-Rev $sec $que '—' '—' $false 'el pedimento no trae este dato' }
  $T = $texto.ToUpper()
  if ($Numero) { $v = ConvertTo-Num $valor; $ok = @($nums | Where-Object { $_ -eq $v }).Count -gt 0; return New-Rev $sec $que (Format-Num $v $(if ($v -eq [Math]::Floor($v)) { 0 } else { 2 })) $(if ($ok) { 'aparece' } else { 'NO aparece' }) $ok '' }
  $cands = if ($Variantes) { $Variantes } else { @("$valor".ToUpper()) }
  $hit = $cands | Where-Object { $T.Contains($_) -or $T.Replace(' ', '').Contains($_.Replace(' ', '')) } | Select-Object -First 1
  New-Rev $sec $que $valor $(if ($hit) { "aparece ($hit)" } else { 'NO aparece' }) ([bool]$hit) ''
}
function Test-GlosaFactura($p, [string[]]$lineas, [string]$archivo) {
  $s = "Factura ($archivo)"; $T = $lineas -join "`n"; $N = @(Get-Numeros $T); $r = @()
  if (-not $p.Facturas.Count) { return , (New-Rev $s 'Facturas del pedimento' '—' '—' $false 'no pude leer las facturas del pedimento') }
  foreach ($f in $p.Facturas) {
    if ($f.Num -match '^COVE') {
      $r += New-Rev $s 'Campo factura del pedimento' $f.Num 'trae el COVE (normal en CASA)' $true 'se revisan los números de factura de las observaciones de partida' -Aviso
      foreach ($fo in $p.FacturasObs) { $r += Test-Aparece $s "Número de factura (observaciones)" $fo $T $N }
    } else { $r += Test-Aparece $s "Número de factura" $f.Num $T $N }
    $r += Test-Aparece $s "Fecha de factura ($($f.Num))" $f.Fecha $T $N -Variantes (Get-FechaVariantes $f.Fecha)
    $r += Test-Aparece $s "Incoterm ($($f.Num))" $f.Incoterm $T $N
    $r += Test-Aparece $s "Valor en moneda de factura ($($f.Moneda))" $f.ValorMon $T $N -Numero
  }
  $r += Test-Aparece $s 'ID fiscal del proveedor' $p.ProveedorId $T $N
  if ($p.RFC) { $r += Test-Aparece $s 'RFC del importador' $p.RFC $T $N }
  $cant = ($p.Partidas | Measure-Object CantUMC -Sum).Sum
  if ($cant) { $r += Test-Aparece $s 'Cantidad total (UMC)' $cant $T $N -Numero }
  $r
}
function Test-GlosaGuia($p, [string[]]$lineas, [string]$archivo) {
  $s = "Guía ($archivo)"; $T = $lineas -join "`n"; $U = $T.ToUpper(); $N = @(Get-Numeros $T); $r = @()
  if (-not $lineas.Count) { return , (New-Rev $s 'Texto de la guía' '—' 'no pude leerla' $false 'PDF escaneado y el OCR no sacó texto') }
  if (-not $p.Guias.Count) { $r += New-Rev $s 'Guías del pedimento' '—' '—' $false 'el pedimento no trae guías' }
  foreach ($g in $p.Guias) {
    $tipo = if ($g.Tipo -eq 'M') { 'master' } else { 'house' }
    $r += Test-Aparece $s "Guía $tipo" $g.Num $T $N -Variantes @($g.Num, ($g.Num -replace '\D', ''), ($g.Num -replace '-', ' '))
  }
  if ($null -ne $p.Peso) {
    $pg = if ($U -match '(?:WEIGHT|PESO)[^\d]{0,20}([\d,.]+)\s*(?:KG|KGS)') { ConvertTo-Num $Matches[1] } elseif ($U -match '([\d,.]+)\s*(?:KG|KGS)\b') { ConvertTo-Num $Matches[1] } else { $null }
    if ($null -eq $pg -or $pg -ne $p.Peso) { if (@($N | Where-Object { $_ -eq $p.Peso }).Count) { $pg = $p.Peso } }
    $r += New-Rev $s 'Peso bruto (kg)' (Format-Num $p.Peso 3) $(if ($null -ne $pg) { Format-Num $pg 3 } else { 'NO aparece' }) ($null -ne $pg -and $pg -eq $p.Peso) ''
  }
  if ($p.Entrada) { $r += Test-Aparece $s 'Fecha de entrada' $p.Entrada $T $N -Variantes (Get-FechaVariantes $p.Entrada) }
  $fusd = ($p.Facturas | Measure-Object ValorUSD -Sum).Sum
  if ($fusd) { $x = Test-Aparece $s 'Valor declarado (USD)' $fusd $T $N -Numero
    if (-not $x.Ok -and $U -match 'CUSTOM(?:S)? VALUE\s*(?:USD\$?)?\s*([\d,]+\.\d{2})') { $x.Documento = "la guía dice $($Matches[1])" }
    $r += $x }
  if ($U -match 'FREIGHT VALUE\s*([\d,.]+)' -and $p.Increm) {
    $fl = ConvertTo-Num $Matches[1]; $c = [Math]::Round($fl * $p.TC, 0, [MidpointRounding]::AwayFromZero)
    $dfl = $p.Increm.Fletes - $c
    $r += New-Rev $s 'Fletes incrementables (MXN) vs flete de la guía × TC' (Format-Num $p.Increm.Fletes 0) "$(Format-Num $fl) USD × $($p.TC) = $(Format-Num $c 0)" ($c -eq $p.Increm.Fletes) $(if ($dfl) { "diferencia $(Format-Num $dfl 0): el flete entra al valor aduana, así que el IVA cambia ≈ $(Format-Num (0.16 * $dfl) 0)$(if ($p.Tasas['DTA'] -and $p.Tasas['DTA'].Tipo -eq 7) { " y el DTA ≈ $(Format-Num ($dfl * $p.Tasas['DTA'].Tasa / 1000) 0)" })" } else { '' })
  }
  if ($U -match 'PATENTE:?\s*(\d{4})') { $r += New-Rev $s 'Patente en la guía' $CasaEmpresa.patente $Matches[1] ($Matches[1] -eq $CasaEmpresa.patente) '' }
  $r
}

# ---------- glosa de virtuales: pedimento de importación contra el de exportación ----------
function Get-Ident($p, [string]$clave) { @($p.Identificadores | Where-Object Clave -eq $clave) }
function Test-GlosaVirtual($pi, $pe) {
  $r = @()
  $s = 'Relación entre pedimentos'
  $r += New-Rev $s 'Impo cita a la expo' $pi.Pedimento $(if ($pi.Relacionados -contains $pe.Pedimento) { "cita $($pe.Pedimento)" } else { "NO cita $($pe.Pedimento)$(if ($pi.Relacionados) { " (cita $($pi.Relacionados -join ', '))" })" }) ($pi.Relacionados -contains $pe.Pedimento) ''
  $r += New-Rev $s 'Expo cita a la impo' $pe.Pedimento $(if ($pe.Relacionados -contains $pi.Pedimento) { "cita $($pi.Pedimento)" } else { "NO cita $($pi.Pedimento)$(if ($pe.Relacionados) { " (cita $($pe.Relacionados -join ', '))" })" }) ($pe.Relacionados -contains $pi.Pedimento) ''
  $r += New-Rev $s 'Tipo de operación (impo / expo)' $pi.Oper $pe.Oper ($pi.Oper -eq 'IMP' -and $pe.Oper -eq 'EXP') 'debe ser IMP contra EXP'
  $r += New-Rev $s 'Clave de pedimento' $pi.Clave $pe.Clave ($pi.Clave -and $pi.Clave -eq $pe.Clave) ''
  $s = 'Partes (quién transfiere y quién recibe)'
  $v5e = Get-Ident $pe 'V5' | Select-Object -First 1; $v5i = Get-Ident $pi 'V5' | Select-Object -First 1
  $rfcEnExpo = if ($v5e) { ($v5e.Compl -split ' ')[0] } else { $null }
  $r += New-Rev $s 'RFC de quien importa (impo) = RFC declarado en la expo (V5)' $pi.RFC $(if ($rfcEnExpo) { $rfcEnExpo } else { 'la expo no trae V5 con RFC' }) ($rfcEnExpo -and $rfcEnExpo -eq $pi.RFC) ''
  $tI = $pi.Lineas -join ' '
  $r += New-Rev $s 'RFC de quien exporta (expo) aparece en la impo' $pe.RFC $(if ($pe.RFC -and $tI.Contains($pe.RFC)) { 'aparece en la impo' } else { 'NO aparece en la impo' }) ($pe.RFC -and $tI.Contains($pe.RFC)) ''
  $imE = (Get-Ident $pe 'IM' | Select-Object -First 1).Compl; $imI = if ($v5i) { ($v5i.Compl -split ' ')[0] } else { $null }
  $r += New-Rev $s 'IMMEX: IM de la expo = complemento V5 de la impo' "$imI" "$imE" ($imI -and $imI -eq $imE) ''
  $s = 'Encabezado'
  $r += New-Rev $s 'Peso bruto' (Format-Num $pi.Peso 3) (Format-Num $pe.Peso 3) ($pi.Peso -eq $pe.Peso) ''
  $r += New-Rev $s 'Tipo de cambio' $pi.TC $pe.TC ($pi.TC -eq $pe.TC) ''
  $r += New-Rev $s 'Valor dólares' (Format-Num $pi.ValorUSD) (Format-Num $pe.ValorUSD) ($pi.ValorUSD -eq $pe.ValorUSD) $(if ($pi.ValorUSD -ne $pe.ValorUSD -and $pe.ValorUSD) { "diferencia $(Format-Num ($pi.ValorUSD - $pe.ValorUSD)) ($(Format-Num (100 * ($pi.ValorUSD - $pe.ValorUSD) / $pe.ValorUSD) 1) %)" })
  $r += New-Rev $s 'Precio pagado / valor comercial (MXN)' (Format-Num $pi.PrecioPagado 0) (Format-Num $pe.PrecioPagado 0) ($pi.PrecioPagado -eq $pe.PrecioPagado) ''
  $r += New-Rev $s 'Fecha de pago' "$($pi.Pago)" "$($pe.Pago)" ($pi.Pago -eq $pe.Pago) ''
  $s = 'Facturas'
  $r += New-Rev $s 'Número de facturas' $pi.Facturas.Count $pe.Facturas.Count ($pi.Facturas.Count -eq $pe.Facturas.Count) ''
  for ($k = 0; $k -lt [Math]::Max($pi.Facturas.Count, $pe.Facturas.Count); $k++) {
    $a = $pi.Facturas[$k]; $b = $pe.Facturas[$k]; $n = $k + 1
    if ($a -and $b -and $a.Num -match '^COVE' -and $b.Num -match '^COVE') {
      # cada pedimento lleva su propio COVE: no se compara; se comparan las facturas de las observaciones de partida
      $r += New-Rev $s "COVE (factura $($k + 1))" $a.Num $b.Num $true 'cada pedimento tiene su propio COVE' -Aviso
      $fi = @($pi.FacturasObs | Sort-Object); $fe = @($pe.FacturasObs | Sort-Object)
      $r += New-Rev $s 'Facturas declaradas en las partidas' ($fi -join ', ') ($fe -join ', ') (($fi -join ',') -eq ($fe -join ',')) ''
    } elseif ($a -and $b) { $r += New-Rev $s "Número (factura $k)" $a.Num $b.Num ($a.Num -eq $b.Num) '' }
    foreach ($c in @(@('Fecha', 'Fecha'), @('Incoterm', 'Incoterm'), @('Moneda', 'Moneda'), @('ValorMon', 'Valor moneda factura'), @('ValorUSD', 'Valor USD'))) {
      $x = if ($a) { $a.($c[0]) } else { $null }; $y = if ($b) { $b.($c[0]) } else { $null }
      $r += New-Rev $s "$($c[1]) (factura $n)" $(if ($c[0] -like 'Valor*') { Format-Num $x } else { $x }) $(if ($c[0] -like 'Valor*') { Format-Num $y } else { $y }) ("$x" -eq "$y") '' }
  }
  $ni = ($pi.ProveedorId -replace '\W', ''); $ne = ($pe.ProveedorId -replace '\W', '')
  if ($pi.ProveedorId -eq $pe.ProveedorId) { $r += New-Rev $s 'ID fiscal del proveedor' $pi.ProveedorId $pe.ProveedorId $true '' }
  elseif ($ni -and $ni -eq $ne) { $r += New-Rev $s 'ID fiscal del proveedor' $pi.ProveedorId $pe.ProveedorId $true 'mismo ID con distinto formato' -Aviso }
  else { $r += New-Rev $s 'ID fiscal del proveedor' $pi.ProveedorId $pe.ProveedorId $false '' }
  $s = 'Partidas'
  $r += New-Rev $s 'Número de partidas' $pi.Partidas.Count $pe.Partidas.Count ($pi.Partidas.Count -eq $pe.Partidas.Count) ''
  $usadas = @{}
  foreach ($a in $pi.Partidas) {
    $mejor = $null; $pts = -1
    foreach ($c in $pe.Partidas) { if ($usadas[$c.Sec]) { continue }
      $sc = 0; if ($c.Fraccion -eq $a.Fraccion) { $sc += 4 }; if ($c.Nico -eq $a.Nico) { $sc += 1 }; if ($c.Descripcion -eq $a.Descripcion) { $sc += 3 }
      if ($c.CantUMC -eq $a.CantUMC) { $sc += 2 }; if ($c.CantUMT -eq $a.CantUMT) { $sc += 2 }; if ($c.Sec -eq $a.Sec) { $sc += 1 }
      if ($sc -gt $pts) { $pts = $sc; $mejor = $c } }
    $b = if ($pts -ge 5) { $mejor } else { $null }
    $t = "Partida $($a.Sec)$(if ($b -and $b.Sec -ne $a.Sec) { " (expo $($b.Sec))" })"
    if (-not $b) { $r += New-Rev $s "Partida $($a.Sec)" "$($a.Fraccion) $($a.Descripcion) ($(Format-Num $a.CantUMC 3))" 'NO está en la expo' $false ''; continue }
    $usadas[$b.Sec] = $true
    # P. O/D es origen en la impo y destino en la expo: no se comparan
    foreach ($c in @(@('Fraccion', 'fracción'), @('Nico', 'NICO'), @('Descripcion', 'descripción'), @('UMC', 'UMC'), @('CantUMC', 'cantidad UMC'), @('UMT', 'UMT'), @('CantUMT', 'cantidad UMT'), @('PaisVC', 'país vendedor/comprador'))) {
      $x = $a.($c[0]); $y = $b.($c[0]); $r += New-Rev $s "$t $($c[1])" $x $y (Test-Igual $x $y) '' }
    $usdI = if ($a.PrecioPagado -and $pi.TC) { [Math]::Round($a.PrecioPagado / $pi.TC, 2) } else { $null }
    if ($null -ne $b.ValorUSD) { $d = if ($null -ne $usdI) { [Math]::Round($usdI - $b.ValorUSD, 2) } else { $null }
      $r += New-Rev $s "$t valor USD (impo: precio pagado / TC)" (Format-Num $usdI) (Format-Num $b.ValorUSD) ($d -eq 0) $(if ($d) { "diferencia $(Format-Num $d)" }) }
  }
  foreach ($b in $pe.Partidas | Where-Object { -not $usadas[$_.Sec] }) { $r += New-Rev $s "Partida expo $($b.Sec)" 'NO está en la impo' "$($b.Fraccion) $($b.Descripcion) ($(Format-Num $b.CantUMC 3))" $false '' }
  $r
}
# PDF del pedimento en una carpeta: proforma primero.
function Find-PdfPedimento([string]$dir, [string]$num) {
  $f = @(Get-ChildItem -LiteralPath $dir -File -Filter *.pdf)
  $cands = foreach ($rx in '(^|[-_ ])PRF_', '^Referencia AYC', '^(IMP|EXP|T|AA)_', '^(IMPORTADOR|EXPORTADOR|AGENTE)[ _]') { $f | Where-Object { $_.Name -match $rx } | Sort-Object LastWriteTime -Descending }
  if (-not $num) { return ($cands | Select-Object -First 1).FullName }
  $ref4 = $num.Substring($num.Length - 4)
  foreach ($c in ($cands | Sort-Object { if ($_.Name -match $ref4) { 0 } else { 1 } })) { $l = @(Get-PdfLineasTexto $c.FullName) | Select-Object -First 4; if (($l -join ' ') -match "\d{2} \d{2} \d{4} $num") { return $c.FullName } }
  $null
}
# Glosa de un par virtual. Con solo uno de los dos PDF busca la contraparte que cita (en las carpetas de los clientes).
function Invoke-CasaGlosaVirtual {
  param([string]$PdfImpo, [string]$PdfExpo, [scriptblock]$Log = { param($m) Write-Host $m })
  if (-not $PdfImpo -and -not $PdfExpo) { throw 'Falta el PDF de la impo o de la expo' }
  $pa = Read-PedimentoPdf $(if ($PdfImpo) { $PdfImpo } else { $PdfExpo })
  if (-not $pa.Pedimento) { throw 'El PDF no parece un pedimento de CASA' }
  $otro = if ($PdfImpo -and $PdfExpo) { Read-PedimentoPdf $PdfExpo } else {
    if (-not $pa.Relacionados.Count) { throw "$($pa.Pedimento) no cita ninguna contraparte; elige el otro PDF" }
    $quiero = if ($pa.Oper -eq 'IMP') { 'EXP' } else { 'IMP' }; $hallado = $null; $vistos = @()
    foreach ($rel in $pa.Relacionados) {
      $num = ($rel -split ' ')[-1]
      foreach ($dd in @(Get-CasaCarpetas $num)) {
        $pdf = Find-PdfPedimento $dd $num; if (-not $pdf) { $vistos += "$num (sin PDF)"; continue }
        $c = Read-PedimentoPdf $pdf; $vistos += "$num $($c.Oper) $($c.Clave)"
        if ($c.Oper -eq $quiero -and $c.Clave -eq $pa.Clave) { if (-not $hallado -or $c.Relacionados -contains $pa.Pedimento) { $hallado = $c } }
      }
      if ($hallado -and $hallado.Relacionados -contains $pa.Pedimento) { break }
    }
    if (-not $hallado) { throw "No encontré la contraparte de $($pa.Pedimento) entre los que cita ($($vistos -join '; ')); elige el otro PDF" }
    & $Log "Contraparte encontrada: $($hallado.Pedimento) ($($hallado.Archivo))"; $hallado }
  $pi = if ($pa.Oper -eq 'IMP') { $pa } elseif ($otro.Oper -eq 'IMP') { $otro } else { $pa }
  $pe = if ($pi -eq $pa) { $otro } else { $pa }
  & $Log "Glosa virtual: impo $($pi.Pedimento) ($($pi.Archivo)) contra expo $($pe.Pedimento) ($($pe.Archivo))"
  $revs = @(Test-GlosaVirtual $pi $pe)
  $dif = @($revs | Where-Object { -not $_.Ok }); $nav = @($revs | Where-Object Aviso).Count
  foreach ($x in $dif) { & $Log "⚠ $($x.Concepto): impo $($x.Pedimento) | expo $($x.Documento) $($x.Nota)" }
  & $Log $(if ($dif.Count) { "⚠ Glosa virtual $($pi.Pedimento) / $($pe.Pedimento): $($dif.Count) diferencia(s) de $($revs.Count) revisiones" } else { "✔ Glosa virtual sin diferencias ($($revs.Count) revisiones)" })
  $pv = [pscustomobject]@{ Pedimento = "$($pi.Pedimento) / $($pe.Pedimento)"; Oper = 'Virtual impo contra expo'; Clave = $pi.Clave; Borrador = ($pi.Borrador -or $pe.Borrador) }
  [pscustomobject]@{ Hoja = $null; Revisiones = $revs.Count; Diferencias = $dif.Count; Redondeos = $nav; Pedimento = $pv; Impo = $pi; Expo = $pe; Revs = $revs
    Docs = [ordered]@{ 'Impo' = $pi.Archivo; 'Expo' = $pe.Archivo }; Columnas = @('Impo', 'Expo') }
}

# ---------- hoja de glosa (HTML -> PDF con Edge) ----------
function Export-HojaGlosa($p, $revs, $docs, [string]$salidaPdf, [string[]]$Columnas = @('Pedimento', 'Documento / cálculo')) {
  $enc = { param($x) [Net.WebUtility]::HtmlEncode("$x") }
  $dif = @($revs | Where-Object { -not $_.Ok }).Count; $av = @($revs | Where-Object Aviso).Count; $ok = @($revs | Where-Object { $_.Ok -and -not $_.Aviso }).Count
  $filas = foreach ($g in ($revs | Group-Object Seccion)) {
    "<tr class='sec'><td colspan='4'>$(& $enc $g.Name)</td></tr>"
    foreach ($x in $g.Group) { "<tr class='$(if (-not $x.Ok) { 'dif' } elseif ($x.Aviso) { 'av' } else { 'ok' })'><td>$(& $enc $x.Concepto)</td><td>$(& $enc $x.Pedimento)</td><td>$(& $enc $x.Documento)$(if ($x.Nota) { "<div class='nota'>$(& $enc $x.Nota)</div>" })</td><td class='res'>$(if (-not $x.Ok) { '✖ Diferencia' } elseif ($x.Aviso) { '≈ Redondeo' } else { '✔ Igual' })</td></tr>" }
  }
  $html = @"
<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Glosa $($p.Pedimento)</title><style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:11px;color:#1f2937;margin:24px}
h1{font-size:18px;color:#1e3a8a;margin:0 0 4px} .sub{color:#6b7280;margin-bottom:12px}
.res-box{display:inline-block;padding:6px 12px;border-radius:6px;font-weight:600;margin:4px 8px 12px 0}
.b-ok{background:#dcfce7;color:#166534}.b-dif{background:#fee2e2;color:#991b1b}
table{border-collapse:collapse;width:100%} th{background:#1e3a8a;color:#fff;text-align:left;padding:6px}
td{padding:5px 6px;border-bottom:1px solid #e5e7eb;vertical-align:top} tr.sec td{background:#eef2f7;font-weight:600;color:#1e3a8a}
tr.dif td{background:#fef2f2} tr.dif td.res{color:#b91c1c;font-weight:700} tr.ok td.res{color:#15803d;font-weight:600}
tr.av td{background:#fffbeb} tr.av td.res{color:#b45309;font-weight:600} .b-av{background:#fef3c7;color:#92400e}
.nota{color:#b45309;font-size:10px}.docs td{border:none;padding:1px 6px}.pie{margin-top:14px;color:#6b7280;font-size:10px}
</style></head><body>
<h1>Glosa antes de pago — $(& $enc $p.Pedimento)</h1>
<div class="sub">$(& $enc "$($p.Oper) · Clave $($p.Clave) · $(if ($p.Borrador) { 'Proforma (borrador sin validez)' } else { 'Pedimento' })") · Glosado $(Get-Date -Format 'dd/MM/yyyy HH:mm') en $env:COMPUTERNAME</div>
<span class="res-box b-dif">✖ $dif diferencia(s)</span><span class="res-box b-av">≈ $av redondeo(s)</span><span class="res-box b-ok">✔ $ok igual(es)</span>
<table class="docs">$(foreach ($k in $docs.Keys) { "<tr><td><b>$(& $enc $k):</b></td><td>$(& $enc $docs[$k])</td></tr>" })</table><br>
<table><tr><th style="width:34%">Concepto</th><th style="width:22%">$(& $enc $Columnas[0])</th><th>$(& $enc $Columnas[1])</th><th style="width:11%">Resultado</th></tr>
$($filas -join "`n")</table>
<div class="pie">Glosa automática: toda diferencia entre documentos se marca en rojo (sin tolerancias). En amarillo, diferencias de centavos o de 1 peso por partida en los cálculos de CASA (redondeo). Revisar cada renglón en rojo antes de pagar.</div>
</body></html>
"@
  $tmpHtml = Join-Path $env:TEMP ("glosa_" + [IO.Path]::GetRandomFileName() + '.html')
  [IO.File]::WriteAllText($tmpHtml, $html, (New-Object Text.UTF8Encoding $true))
  $edge = @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe', 'C:\Program Files\Microsoft\Edge\Application\msedge.exe') | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $edge) { $h = [IO.Path]::ChangeExtension($salidaPdf, '.html'); Move-Item -LiteralPath $tmpHtml -Destination $h -Force; return $h }
  $tmpPdf = Join-Path $env:TEMP ("glosa_" + [IO.Path]::GetRandomFileName() + '.pdf')
  $perfil = Join-Path $env:TEMP 'glosa_edge'
  $pr = Start-Process -FilePath $edge -ArgumentList @('--headless', '--disable-gpu', "--user-data-dir=`"$perfil`"", '--no-pdf-header-footer', "--print-to-pdf=`"$tmpPdf`"", "`"$tmpHtml`"") -PassThru -WindowStyle Hidden
  if (-not $pr.WaitForExit(60000)) { try { $pr.Kill() } catch {} }
  Remove-Item -LiteralPath $tmpHtml -ErrorAction SilentlyContinue
  if (-not (Test-Path -LiteralPath $tmpPdf)) { throw 'Edge no generó el PDF de la glosa' }
  Move-Item -LiteralPath $tmpPdf -Destination $salidaPdf -Force; $salidaPdf
}

# ---------- documentos del expediente ----------
function Find-DocsGlosa([string]$dir, [string]$ref) {
  $f = @(Get-ChildItem -LiteralPath $dir -File -Filter *.pdf)
  $ped = $f | Where-Object Name -match '(^|[-_ ])PRF_' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $ped) { $ped = $f | Where-Object { $_.Name -match '^(IMP|EXP|T|AA)_' } | Select-Object -First 1 }
  $gui = $f | Where-Object { $_.Name -like 'GR_*' -or $_.Name -match 'GUIA|AWB' } | Select-Object -First 1
  @{ Pedimento = $ped.FullName; Factura = $null; Guia = $gui.FullName }
}
# Factura: INV_*, luego un PDF con el número de factura en el nombre, luego FACTURA/INVOICE (nunca la FAYC ni la GLOSA).
function Find-FacturaGlosa([string]$dir, $p) {
  $f = @(Get-ChildItem -LiteralPath $dir -File -Filter *.pdf | Where-Object { $_.Name -notmatch '^(FAYC|GLOSA|PRF_|IMP_|EXP_|T_|AA_|S_|SIMP_|COVE|Reporte_|AMV_|MV_|GR_)' })
  $x = $f | Where-Object Name -like 'INV_*' | Select-Object -First 1
  if (-not $x) { foreach ($fa in $p.Facturas) { $x = $f | Where-Object { $_.Name -like "*$($fa.Num)*" } | Select-Object -First 1; if ($x) { break } } }
  if (-not $x) { $x = $f | Where-Object { $_.Name -match 'FACTURA|INVOICE|INV' } | Select-Object -First 1 }
  $x.FullName
}

# Glosa de un pedimento aéreo. NO forma parte del expediente: por omisión no escribe nada; con -Salida guarda la hoja PDF ahí.
# Se le pueden dar los PDF directo (-PdfPedimento/-PdfFactura/-PdfGuia) o buscarlos en la carpeta (-Dir o por pedimento).
function Invoke-CasaGlosa {
  param([string]$Pedimento, [string]$Dir, [string]$PdfPedimento, [string]$PdfFactura, [string]$PdfGuia, [string]$Salida, [scriptblock]$Log = { param($m) Write-Host $m })
  if (-not $Dir -and -not $PdfPedimento -and $Pedimento) { $Dir = Get-CasaCarpeta $Pedimento }
  $d = if ($Dir) { Find-DocsGlosa $Dir '' } else { @{ Pedimento = $null; Factura = $null; Guia = $null } }
  if ($PdfPedimento) { $d.Pedimento = $PdfPedimento }; if ($PdfFactura) { $d.Factura = $PdfFactura }; if ($PdfGuia) { $d.Guia = $PdfGuia }
  if (-not $d.Pedimento) { throw 'Falta el PDF del pedimento (proforma)' }
  $p = Read-PedimentoPdf $d.Pedimento
  if (-not $p.Pedimento) { throw "$(Split-Path $d.Pedimento -Leaf) no parece un pedimento de CASA (no encontré NUM. PEDIMENTO)" }
  if ($Pedimento -and $p.Pedimento -notmatch $Pedimento) { throw "El PDF $(Split-Path $d.Pedimento -Leaf) es del pedimento $($p.Pedimento), no de $Pedimento" }
  if (-not $d.Factura -and $Dir) { $d.Factura = Find-FacturaGlosa $Dir $p }
  & $Log "Glosa: pedimento $(Split-Path $d.Pedimento -Leaf) | factura $(if ($d.Factura) { Split-Path $d.Factura -Leaf } else { '—' }) | guía $(if ($d.Guia) { Split-Path $d.Guia -Leaf } else { '—' })"
  $revs = @(Test-GlosaPedimento $p)
  if ($d.Factura) { $lf = @(Get-PdfLineas $d.Factura); $revs += Test-GlosaFactura $p $lf ((Split-Path $d.Factura -Leaf) + $(if ($script:UltimoOcr) { ' — leída por OCR, revisar números' } else { '' })) } else { $revs += New-Rev 'Factura' 'PDF de la factura' '—' 'NO encontrado' $false 'pon INV_<ref>.pdf en la carpeta o elígelo' }
  if ($d.Guia) { $lg = @(Get-PdfLineas $d.Guia); $revs += Test-GlosaGuia $p $lg ((Split-Path $d.Guia -Leaf) + $(if ($script:UltimoOcr) { ' — leída por OCR, revisar números' } else { '' })) } else { $revs += New-Rev 'Guía' 'PDF de la guía' '—' 'NO encontrado' $false 'pon GR_<ref>.pdf en la carpeta o elígelo' }
  $docs = [ordered]@{ Pedimento = Split-Path $d.Pedimento -Leaf; Factura = $(if ($d.Factura) { Split-Path $d.Factura -Leaf } else { '—' }); 'Guía' = $(if ($d.Guia) { Split-Path $d.Guia -Leaf } else { '—' }) }
  $hoja = if ($Salida) { Export-HojaGlosa $p $revs $docs $Salida } else { $null }
  $dif = @($revs | Where-Object { -not $_.Ok })
  foreach ($x in $dif) { & $Log "⚠ $($x.Concepto): pedimento $($x.Pedimento) | $($x.Documento) $($x.Nota)" }
  $nav = @($revs | Where-Object Aviso).Count
  & $Log $(if ($dif.Count) { "⚠ Glosa $($p.Pedimento): $($dif.Count) diferencia(s) y $nav redondeo(s) de $($revs.Count) revisiones" } else { "✔ Glosa $($p.Pedimento) sin diferencias ($nav redondeo(s), $($revs.Count) revisiones)" })
  [pscustomobject]@{ Hoja = $hoja; Revisiones = $revs.Count; Diferencias = $dif.Count; Redondeos = $nav; Pedimento = $p; Revs = $revs; Docs = $docs }
}
