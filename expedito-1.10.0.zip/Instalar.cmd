@echo off
rem Expedito - (c) 2026 Paulo Castaneda. Todos los derechos reservados.
rem Instala el acceso directo de "Expedito" en esta PC y revisa que tenga todo lo necesario.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
