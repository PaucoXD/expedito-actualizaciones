' Expedito - (c) 2026 Paulo Castaneda. Todos los derechos reservados.
' Abre Expedito sin ventana de consola (el acceso directo del Escritorio apunta aqui).
Set sh = CreateObject("WScript.Shell")
d = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.Run "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & d & "\expediente-app.ps1""", 0, False
