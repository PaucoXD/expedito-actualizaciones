﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Genera app.ico (icono a color de "Expedito"). Solo se corre si se quiere rehacer el icono.
Add-Type -AssemblyName System.Drawing
function New-IconoBmp([int]$n) {
  $b = New-Object Drawing.Bitmap $n, $n; $g = [Drawing.Graphics]::FromImage($b)
  $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'; $g.Clear([Drawing.Color]::Transparent)
  $s = $n / 256.0
  function Rc([double]$x, [double]$y, [double]$w, [double]$h) { New-Object Drawing.RectangleF ([float]($x * $s)), ([float]($y * $s)), ([float]($w * $s)), ([float]($h * $s)) }
  function Redondo($r, [double]$rad) { $p = New-Object Drawing.Drawing2D.GraphicsPath; $d = [float]($rad * 2 * $s)
    $p.AddArc($r.X, $r.Y, $d, $d, 180, 90); $p.AddArc($r.Right - $d, $r.Y, $d, $d, 270, 90); $p.AddArc($r.Right - $d, $r.Bottom - $d, $d, $d, 0, 90); $p.AddArc($r.X, $r.Bottom - $d, $d, $d, 90, 90); $p.CloseFigure(); $p }
  # fondo: azul A&C con degradado a turquesa
  $fondo = Rc 8 8 240 240; $pf = Redondo $fondo 52
  $br = New-Object Drawing.Drawing2D.LinearGradientBrush $fondo, ([Drawing.Color]::FromArgb(255, 30, 64, 175)), ([Drawing.Color]::FromArgb(255, 13, 148, 136)), 45.0
  $g.FillPath($br, $pf)
  # carpeta amarilla
  $tab = Redondo (Rc 46 70 70 36) 10; $g.FillPath((New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 245, 179, 31))), $tab)
  $car = Redondo (Rc 46 88 164 112) 14; $g.FillPath((New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 252, 200, 64))), $car)
  # hoja blanca saliendo de la carpeta
  $hoja = Redondo (Rc 92 52 92 84) 8; $g.FillPath([Drawing.Brushes]::White, $hoja)
  $pen = New-Object Drawing.Pen ([Drawing.Color]::FromArgb(255, 148, 163, 184)), ([float](7 * $s)); $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
  foreach ($y in 74, 94) { $g.DrawLine($pen, [float](106 * $s), [float]($y * $s), [float](170 * $s), [float]($y * $s)) }
  # palomita verde (expediente completo)
  $g.FillEllipse((New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 22, 163, 74))), (Rc 150 146 82 82))
  $pv = New-Object Drawing.Pen ([Drawing.Color]::White), ([float](13 * $s)); $pv.StartCap = 'Round'; $pv.EndCap = 'Round'; $pv.LineJoin = 'Round'
  $g.DrawLines($pv, [Drawing.PointF[]]@((New-Object Drawing.PointF ([float](170 * $s)), ([float](188 * $s))), (New-Object Drawing.PointF ([float](186 * $s)), ([float](203 * $s))), (New-Object Drawing.PointF ([float](212 * $s)), ([float](172 * $s)))))
  $g.Dispose(); $b
}
# ICO con imágenes PNG de 16, 24, 32, 48, 64 y 256
$tam = 16, 24, 32, 48, 64, 256
$pngs = foreach ($n in $tam) { $bmp = New-IconoBmp $n; $ms = New-Object IO.MemoryStream; $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose(); , $ms.ToArray() }
$out = New-Object IO.MemoryStream; $w = New-Object IO.BinaryWriter $out
$w.Write([uint16]0); $w.Write([uint16]1); $w.Write([uint16]$tam.Count)
$off = 6 + 16 * $tam.Count
for ($i = 0; $i -lt $tam.Count; $i++) { $n = $tam[$i]; $w.Write([byte]($n % 256)); $w.Write([byte]($n % 256)); $w.Write([byte]0); $w.Write([byte]0); $w.Write([uint16]1); $w.Write([uint16]32); $w.Write([uint32]$pngs[$i].Length); $w.Write([uint32]$off); $off += $pngs[$i].Length }
foreach ($p in $pngs) { $w.Write($p) }
$w.Flush(); [IO.File]::WriteAllBytes("$PSScriptRoot\app.ico", $out.ToArray())
$big = New-IconoBmp 256; $big.Save("$PSScriptRoot\app.png"); $big.Dispose()
"app.ico creado"
