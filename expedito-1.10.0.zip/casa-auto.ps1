﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Automatización de clics de CASA (CSAAIWIN) por mensajes de Windows: sin mouse, sin teclado físico, sin capturas.
# Uso:  . "C:\Users\dell\Documents\casa-tools\casa-auto.ps1"
#       Invoke-CasaAuto -Pedimento 6108012 [-Dir <carpeta>] [-Grupos Pagado,Simp,Cove,MV] [-Log { param($m) Write-Host $m }]
# Los IDs de menú y las posiciones de botones salen del mapa de CASA ($CasaMapa, pestaña Configuración → Mapear CASA).
# De fábrica: menú Pedimentos (4.º de la barra, contando desde 0): 4/0 Catálogo, 4/3 Impresión, 4/5 Simplificada; 4/1 = Cierre: NUNCA.
. "$PSScriptRoot\casa.ps1"
Add-Type -AssemblyName System.Drawing

if (-not ('CA' -as [type])) {
Add-Type @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class CA {
 public delegate bool EP(IntPtr h, IntPtr l);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EP p, IntPtr l);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
 [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,IntPtr l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,StringBuilder l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,string l);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,int m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string t);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
 [DllImport("user32.dll")] public static extern int GetMenuItemCount(IntPtr m);
 [DllImport("user32.dll")] public static extern uint GetMenuItemID(IntPtr m,int p);
 [StructLayout(LayoutKind.Sequential)] public struct R { public int L,T,Rt,B; }
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out R r);
 public static string Get(IntPtr h){ var s=new StringBuilder(1024); SendMessage(h,0x0D,(IntPtr)1024,s); return s.ToString(); }
 public static List<IntPtr> ProcTops(uint pid, bool soloVisibles){ var r=new List<IntPtr>(); EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p); if(p==pid && (!soloVisibles || IsWindowVisible(h))) r.Add(h); return true; }, IntPtr.Zero); return r; }
}
"@
Add-Type @"
using System; using System.Drawing; using System.Drawing.Imaging; using System.Runtime.InteropServices;
public class CPix {
 [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint f);
 [StructLayout(LayoutKind.Sequential)] public struct RC { public int L,T,R,B; }
 [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RC r);
 public static Bitmap Snap(IntPtr h){ RC r; GetClientRect(h,out r); var b=new Bitmap(Math.Max(1,r.R),Math.Max(1,r.B)); using(var g=Graphics.FromImage(b)){ var dc=g.GetHdc(); PrintWindow(h,dc,1); g.ReleaseHdc(dc);} return b; }
 public static int[] Box(Bitmap b, Color c){ int x0=int.MaxValue,y0=int.MaxValue,x1=-1,y1=-1; int t=c.ToArgb();
   var d=b.LockBits(new Rectangle(0,0,b.Width,b.Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
   int[] px=new int[d.Width*d.Height]; Marshal.Copy(d.Scan0,px,0,px.Length); b.UnlockBits(d);
   for(int y=0;y<b.Height;y++) for(int x=0;x<b.Width;x++){ if(px[y*b.Width+x]==t){ if(x<x0)x0=x; if(y<y0)y0=y; if(x>x1)x1=x; if(y>y1)y1=y; } }
   return x1<0?null:new int[]{x0,y0,x1,y1}; }
 // Para OCR: dentro de x0..x1, el fondo resaltado pasa a blanco y el texto claro a negro.
 public static void Flatten(Bitmap b, Color hl, int x0, int x1){ int t=hl.ToArgb();
   for(int y=0;y<b.Height;y++) for(int x=Math.Max(0,x0);x<=Math.Min(b.Width-1,x1);x++){ Color c=b.GetPixel(x,y);
     if(c.ToArgb()==t) b.SetPixel(x,y,Color.White); else if(c.R>150&&c.G>150&&c.B>150) b.SetPixel(x,y,Color.Black); } }
 // Grupos de renglones resaltados: {y0,y1,x0,x1,ancho}. La celda que encontró la búsqueda es angosta;
 // un renglón marcado (seleccionado) se resalta completo.
 public static System.Collections.Generic.List<int[]> Bands(Bitmap b, Color c){ var res=new System.Collections.Generic.List<int[]>(); int t=c.ToArgb();
   var d=b.LockBits(new Rectangle(0,0,b.Width,b.Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
   int[] px=new int[d.Width*d.Height]; Marshal.Copy(d.Scan0,px,0,px.Length); b.UnlockBits(d);
   int[] cur=null;
   for(int y=0;y<b.Height;y++){ int x0=-1,x1=-1; for(int x=0;x<b.Width;x++){ if(px[y*b.Width+x]==t){ if(x0<0)x0=x; x1=x; } }
     if(x0>=0){ if(cur!=null && Math.Abs(cur[2]-x0)<4 && Math.Abs(cur[3]-x1)<4 && cur[1]==y-1){ cur[1]=y; } else { if(cur!=null) res.Add(cur); cur=new int[]{y,y,x0,x1}; } }
     else if(cur!=null){ res.Add(cur); cur=null; } }
   if(cur!=null) res.Add(cur); return res; }
}
"@ -ReferencedAssemblies System.Drawing
Add-Type @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class CTB {
 [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
 [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a,bool i,uint pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll")] static extern IntPtr VirtualAllocEx(IntPtr p,IntPtr a,int n,uint t,uint pr);
 [DllImport("kernel32.dll")] static extern bool VirtualFreeEx(IntPtr p,IntPtr a,int n,uint t);
 [DllImport("kernel32.dll")] static extern bool ReadProcessMemory(IntPtr p,IntPtr a,byte[] b,int n,out int r);
 // "texto|x|y" del centro de cada botón de un TToolBar de otro proceso (32 bits)
 public static List<string> Buttons(IntPtr tb){ var res=new List<string>(); uint pid; GetWindowThreadProcessId(tb,out pid);
  IntPtr hp=OpenProcess(0x438,false,pid); IntPtr mem=VirtualAllocEx(hp,IntPtr.Zero,1024,0x3000,4); int r;
  int n=SendMessage(tb,0x418,IntPtr.Zero,IntPtr.Zero).ToInt32();
  for(int i=0;i<n;i++){ var b=new byte[20]; SendMessage(tb,0x417,(IntPtr)i,mem); ReadProcessMemory(hp,mem,b,20,out r);
   int id=BitConverter.ToInt32(b,4); byte sty=b[9]; var rc=new byte[16]; SendMessage(tb,0x41D,(IntPtr)i,mem); ReadProcessMemory(hp,mem,rc,16,out r);
   int L=BitConverter.ToInt32(rc,0),T=BitConverter.ToInt32(rc,4),B=BitConverter.ToInt32(rc,12);
   string txt=""; if((sty&1)==0){ long len=SendMessage(tb,0x44B,(IntPtr)id,mem).ToInt64(); if(len>0&&len<200){ var t=new byte[(len+1)*2]; ReadProcessMemory(hp,mem,t,t.Length,out r); txt=Encoding.Unicode.GetString(t,0,(int)len*2);} }
   res.Add(txt.Replace("&","")+"|"+(L+31)+"|"+((T+B)/2)); }
  VirtualFreeEx(hp,mem,0,0x8000); CloseHandle(hp); return res; }
}
"@
}

if (-not ('CMapa' -as [type])) {
Add-Type @"
using System; using System.Text; using System.Threading; using System.Collections.Concurrent; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class CMapa {
 [StructLayout(LayoutKind.Sequential)] public struct PT { public int X, Y; }
 [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr h; public uint m; public IntPtr w, l; public uint t; public PT p; }
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
 [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
 [DllImport("user32.dll")] static extern bool PostThreadMessage(uint t, uint m, IntPtr w, IntPtr l);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern bool GetCursorPos(out PT p);
 [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(PT p);
 [DllImport("user32.dll")] static extern bool ScreenToClient(IntPtr h, ref PT p);
 [DllImport("user32.dll")] static extern int MenuItemFromPoint(IntPtr h, IntPtr m, PT p);
 [DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr m, int p);
 [DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr m);
 [DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr h);
 [DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr m, int p);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
 [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
 [DllImport("user32.dll")] static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
 static Thread th; static uint tid;
 public static ConcurrentQueue<string> Q = new ConcurrentQueue<string>();
 public static bool Activo { get { return th != null && th.IsAlive; } }
 public static void Iniciar() { if (Activo) return; string x; while (Q.TryDequeue(out x)) { } th = new Thread(Loop); th.IsBackground = true; th.Start(); }
 public static void Parar() { if (tid != 0) PostThreadMessage(tid, 0x12, IntPtr.Zero, IntPtr.Zero); }
 static void Loop() {
  tid = GetCurrentThreadId();
  if (!RegisterHotKey(IntPtr.Zero, 1, 0x4000, 0x77)) { Q.Enqueue("error|Otra aplicación está usando F8"); tid = 0; return; }
  MSG m; while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { if (m.m == 0x312) { try { Q.Enqueue(Leer()); } catch (Exception e) { Q.Enqueue("error|" + e.Message); } } }
  UnregisterHotKey(IntPtr.Zero, 1); tid = 0;
 }
 static string Cls(IntPtr h) { var s = new StringBuilder(256); GetClassName(h, s, 256); return s.ToString(); }
 // "menu|hmenu|id|pos|n|id0|pid"  o  "win|hwnd|x|y|clase|pid" (x,y dentro del control bajo el mouse)
 static string Leer() {
  PT p; GetCursorPos(out p); IntPtr w = WindowFromPoint(p); uint pid; GetWindowThreadProcessId(w, out pid); string c = Cls(w);
  if (c == "#32768") { IntPtr hm; SendMessageTimeout(w, 0x1E1, IntPtr.Zero, IntPtr.Zero, 2, 1000, out hm); int pos = MenuItemFromPoint(IntPtr.Zero, hm, p);
   if (pos < 0) return "nada|" + pid; return "menu|" + hm + "|" + GetMenuItemID(hm, pos) + "|" + pos + "|" + GetMenuItemCount(hm) + "|" + GetMenuItemID(hm, 0) + "|" + pid; }
  PT q = p; ScreenToClient(w, ref q); return "win|" + w + "|" + q.X + "|" + q.Y + "|" + c + "|" + pid;
 }
 // ¿el menú es del menú principal de la ventana (y no un menú emergente)?
 public static bool EsPrincipal(IntPtr main, IntPtr hm) { return Busca(GetMenu(main), hm, 0); }
 static bool Busca(IntPtr m, IntPtr hm, int d) { if (m == IntPtr.Zero || d > 4) return false; int n = GetMenuItemCount(m);
  for (int i = 0; i < n; i++) { IntPtr s = GetSubMenu(m, i); if (s == IntPtr.Zero) continue; if (s == hm || Busca(s, hm, d + 1)) return true; } return false; }
 // número de comando en la posición top/item del menú principal (-1 si no existe)
 public static int IdEn(IntPtr main, int top, int item) { IntPtr sm = GetSubMenu(GetMenu(main), top); if (sm == IntPtr.Zero || item < 0 || item >= GetMenuItemCount(sm) || GetSubMenu(sm, item) != IntPtr.Zero) return -1; return (int)GetMenuItemID(sm, item); }
 // lugar del submenú hm en la barra del menú principal (-1 si no es de primer nivel)
 public static int TopDe(IntPtr main, IntPtr hm) { IntPtr mb = GetMenu(main); int n = GetMenuItemCount(mb); for (int i = 0; i < n; i++) if (GetSubMenu(mb, i) == hm) return i; return -1; }
 // todos los comandos del menú principal
 public static List<uint> IdsPrincipal(IntPtr main) { var r = new List<uint>(); Junta(GetMenu(main), r, 0); return r; }
 static void Junta(IntPtr m, List<uint> r, int d) { if (m == IntPtr.Zero || d > 4) return; int n = GetMenuItemCount(m);
  for (int i = 0; i < n; i++) { IntPtr s = GetSubMenu(m, i); if (s != IntPtr.Zero) Junta(s, r, d + 1); else r.Add(GetMenuItemID(m, i)); } }
}
"@
}

# ---------- primitivas ----------
$script:CasaNoPopup = 'TFmMain_Menu','TApplication','Internet Explorer_Hidden'
function Get-CPid { $p = Get-Process csaaiwin -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { [uint32]$p.Id } else { 0 } }
function Get-CMain { $h = [CasaWin]::Tops() | Where-Object { [CasaWin]::Cls($_) -eq 'TFmMain_Menu' } | Select-Object -First 1; if ($h) { [IntPtr]$h } else { [IntPtr]::Zero } }
function Get-CChild([string]$cls) { $h = [CasaWin]::Kids((Get-CMain)) | Where-Object { [CasaWin]::Cls($_) -eq $cls } | Select-Object -First 1; if ($h) { [IntPtr]$h } else { [IntPtr]::Zero } }
function Find-CCtl([IntPtr]$parent, [string]$cls, [string]$text) { if ($parent -eq [IntPtr]::Zero) { return [IntPtr]::Zero }; $h = [CasaWin]::Kids($parent) | Where-Object { [CasaWin]::Cls($_) -eq $cls -and (-not $text -or [CA]::Get($_) -like $text) } | Select-Object -First 1; if ($h) { [IntPtr]$h } else { [IntPtr]::Zero } }
function Get-CPopups { [CA]::ProcTops((Get-CPid), $true) | Where-Object { $script:CasaNoPopup -notcontains [CasaWin]::Cls($_) } | ForEach-Object { [IntPtr]$_ } }
function Wait-CPopup([string]$cls, [int]$sec = 15) { for ($i = 0; $i -lt $sec * 4; $i++) { $w = Get-CPopups | Where-Object { [CasaWin]::Cls($_) -eq $cls } | Select-Object -First 1; if ($w) { Start-Sleep -Milliseconds 500; return [IntPtr]$w }; Start-Sleep -Milliseconds 250 }; [IntPtr]::Zero }
function Wait-CChild([string]$cls, [int]$sec = 15) { for ($i = 0; $i -lt $sec * 4; $i++) { $w = Get-CChild $cls; if ($w -ne [IntPtr]::Zero) { Start-Sleep -Milliseconds 800; return $w }; Start-Sleep -Milliseconds 250 }; [IntPtr]::Zero }
function Close-CHwnd([IntPtr]$h) { if ($h -ne [IntPtr]::Zero) { [void][CA]::PostMessage($h, 0x10, [IntPtr]::Zero, [IntPtr]::Zero); Start-Sleep -Milliseconds 800 } }
function Close-CWin([string]$cls) { foreach ($x in (Get-CPopups | Where-Object { [CasaWin]::Cls($_) -eq $cls })) { Close-CHwnd $x } }
function Send-CKey([IntPtr]$h, [int]$vk, [int]$n = 1) { for ($i = 0; $i -lt $n; $i++) { [void][CA]::PostMessage($h, 0x100, [IntPtr]$vk, [IntPtr]::Zero); [void][CA]::PostMessage($h, 0x101, [IntPtr]$vk, [IntPtr]0xC0000001) } }
# Las tablas de CASA (TDBGrid) ignoran el clic si no tienen el foco (p. ej. si el usuario dejó el foco en la búsqueda).
# Se les da el foco dentro de CASA sin traerlo al frente (AttachThreadInput + SetFocus).
if (-not ('CFoco' -as [type])) {
Add-Type @"
using System; using System.Runtime.InteropServices;
public class CFoco { [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr p);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool f);
 [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
 public static void Dar(IntPtr h){ uint t = GetWindowThreadProcessId(h, IntPtr.Zero); uint yo = GetCurrentThreadId(); if (AttachThreadInput(yo, t, true)) { SetFocus(h); AttachThreadInput(yo, t, false); } } }
"@
}
function Set-CFoco([IntPtr]$h) { [CFoco]::Dar($h); Start-Sleep -Milliseconds 100 }
function Send-CClick([IntPtr]$h, [int]$x, [int]$y, [switch]$Double) { if ([CasaWin]::Cls($h) -eq 'TDBGrid') { Set-CFoco $h }; $lp = [IntPtr](($y -shl 16) -bor $x); [void][CA]::PostMessage($h, 0x201, [IntPtr]1, $lp); [void][CA]::PostMessage($h, 0x202, [IntPtr]0, $lp); if ($Double) { [void][CA]::PostMessage($h, 0x203, [IntPtr]1, $lp); [void][CA]::PostMessage($h, 0x202, [IntPtr]0, $lp) } }
function Click-CBtn([IntPtr]$h) { [void][CA]::SendMessage($h, 0xF5, [IntPtr]::Zero, [IntPtr]::Zero); Start-Sleep -Milliseconds 300 }
function Get-CCheck([IntPtr]$h) { [CA]::SendMessage($h, 0xF0, [IntPtr]::Zero, [IntPtr]::Zero).ToInt32() -eq 1 }
function Set-CCheck([IntPtr]$h, [bool]$on = $true) { if ($h -eq [IntPtr]::Zero) { throw 'No encontré una casilla' }; if ((Get-CCheck $h) -ne $on) { Click-CBtn $h } }
# Menú principal por POSICIÓN ("menú/elemento", p. ej. 4/0 = Pedimentos → Catálogo): en cada PC se lee qué número de comando
# tiene esa posición. Solo se mandan Catálogo, Impresión y Simplificada, y nunca si coincide con Cierre.
function Get-CMenuId([string]$clave) {
  $v = "$($CasaMapa[$clave])" -split '/'; if ($v.Count -ne 2) { throw "Mapa de CASA: '$clave' debe ser menú/elemento (p. ej. 4/0)" }
  [CMapa]::IdEn((Get-CMain), [int]$v[0], [int]$v[1])
}
function Invoke-CMenu([string]$clave) {
  if ($clave -notin 'catalogo', 'impresion', 'simplificada') { throw "Comando de menú '$clave' bloqueado" }
  $id = Get-CMenuId $clave; $ci = Get-CMenuId 'cierre'
  if ($id -le 0) { throw "No encontré '$clave' en el menú de CASA (posición $($CasaMapa[$clave])). Revisa Configuración → Mapa de CASA" }
  if ($id -eq $ci) { throw "'$clave' apunta al mismo comando que Cierre: no lo mando. Revisa Configuración → Mapa de CASA" }
  [void][CA]::PostMessage((Get-CMain), 0x111, [IntPtr]$id, [IntPtr]::Zero)
}
# posición "x,y" del mapa
function Get-CXY([string]$k) { $v = "$($CasaMapa[$k])" -split ','; if ($v.Count -ne 2) { throw "Mapa de CASA: falta la posición '$k' (Configuración → Mapear CASA)" }; @([int]$v[0], [int]$v[1]) }
# Comandos de menús emergentes de Delphi: van a la ventana oculta PopupList (TPUtilWindow).
function Invoke-CPopup([int]$id) { [CA]::ProcTops((Get-CPid), $false) | Where-Object { [CasaWin]::Cls($_) -eq 'TPUtilWindow' } | ForEach-Object { [void][CA]::PostMessage($_, 0x111, [IntPtr]$id, [IntPtr]::Zero) } }
function Wait-CMenu([int]$ms = 4000) { for ($i = 0; $i -lt $ms / 100; $i++) { $pm = [CA]::FindWindow('#32768', $null); if ($pm -ne [IntPtr]::Zero -and [CA]::IsWindowVisible($pm)) { Start-Sleep -Milliseconds 200; return $pm }; Start-Sleep -Milliseconds 100 }; [IntPtr]::Zero }
function Get-CMenuIds([IntPtr]$pm) { $hm = [CA]::SendMessage($pm, 0x1E1, [IntPtr]::Zero, [IntPtr]::Zero); for ($i = 0; $i -lt [CA]::GetMenuItemCount($hm); $i++) { [int][CA]::GetMenuItemID($hm, $i) } }
function Close-CMenu { $pm = [CA]::FindWindow('#32768', $null); if ($pm -ne [IntPtr]::Zero) { Send-CKey $pm 0x1B; Start-Sleep -Milliseconds 400 } }
# Abre un menú (clic en botón) y devuelve los IDs de sus elementos; lo deja cerrado.
function Get-CDropIds([IntPtr]$h, [int]$x, [int]$y) { Send-CClick $h $x $y; $pm = Wait-CMenu; if ($pm -eq [IntPtr]::Zero) { return @() }; $ids = @(Get-CMenuIds $pm); Close-CMenu; $ids }
function Get-CButtons([IntPtr]$tb) { [CTB]::Buttons($tb) | ForEach-Object { $p = $_ -split '\|'; [pscustomobject]@{ Texto = $p[0]; X = [int]$p[1]; Y = [int]$p[2] } } }
function Find-CToolbar([IntPtr]$w, [string]$texto) { foreach ($t in ([CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TToolBar' })) { $b = Get-CButtons ([IntPtr]$t) | Where-Object Texto -eq $texto | Select-Object -First 1; if ($b) { return [pscustomobject]@{ H = [IntPtr]$t; X = $b.X; Y = $b.Y } } }; $null }
function Get-CSidePanel([IntPtr]$w) { $s = [CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TPanel' -and [CasaWin]::GetParent($_) -eq $w } | ForEach-Object { $r = New-Object CA+R; [void][CA]::GetWindowRect($_, [ref]$r); [pscustomobject]@{ H = [IntPtr]$_; W = $r.Rt - $r.L } } | Sort-Object W | Select-Object -First 1; $s.H }
function Get-COptPanel([IntPtr]$w) { $h = [CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TPanel' -and [CasaWin]::Cls([CasaWin]::GetParent($_)) -eq 'TFrm_optimp' } | Select-Object -First 1; [IntPtr]$h }

# Preguntas conocidas de CASA (Sí/No) y la respuesta que indicó el usuario.
$script:CasaRespuestas = [ordered]@{ '*informaci*n de COVE*ha cambiado*actualizar*' = 'No' }
# Contesta las preguntas conocidas que estén abiertas. Devuelve el texto contestado o $null.
function Resolve-CPreguntas([int]$sec = 2) {
  for ($i = 0; $i -lt [Math]::Max(1, $sec * 4); $i++) {
    foreach ($a in @(Get-CAvisos)) {
      $t = Get-CAvisoTexto $a
      foreach ($k in $script:CasaRespuestas.Keys) { if ($t -like $k) {
        $b = [CasaWin]::Kids($a) | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and ([CA]::Get($_) -replace '&', '') -eq $script:CasaRespuestas[$k] } | Select-Object -First 1
        if ($b) { Click-CBtn ([IntPtr]$b); Start-Sleep -Milliseconds 600; return "contesté '$($script:CasaRespuestas[$k])': $t" } } }
    }
    Start-Sleep -Milliseconds 250
  }
  $null
}
# Espera una ventana de CASA (popup o MDI) contestando mientras tanto las preguntas conocidas.
# Si se contestó una pregunta, espera a lo más 10 s más (CASA a veces ya no abre la ventana).
function Wait-CVentana([string]$cls, [switch]$Mdi, [int]$sec = 20, $log) {
  $fin = (Get-Date).AddSeconds($sec)
  while ((Get-Date) -lt $fin) {
    $preg = Resolve-CPreguntas 0; if ($preg) { if ($log) { & $log $preg }; $f2 = (Get-Date).AddSeconds(10); if ($f2 -lt $fin) { $fin = $f2 } }
    $w = if ($Mdi) { Get-CChild $cls } else { Get-CPopups | Where-Object { [CasaWin]::Cls($_) -eq $cls } | Select-Object -First 1 }
    if ($w -and [IntPtr]$w -ne [IntPtr]::Zero) { Start-Sleep -Milliseconds 800; return [IntPtr]$w }
    Start-Sleep -Milliseconds 250
  }
  [IntPtr]::Zero
}
# Avisos (#32770). Acepta solo los que coinciden con $permitidos; los demás se reportan.
function Get-CAvisos { Get-CPopups | Where-Object { [CasaWin]::Cls($_) -eq '#32770' -and [CasaWin]::Text($_) -notmatch 'Guardar|Exportar|Configurar' } }
function Get-CAvisoTexto([IntPtr]$a) { ([CasaWin]::Kids($a) | Where-Object { [CasaWin]::Cls($_) -eq 'Static' } | ForEach-Object { [CA]::Get($_) } | Where-Object { $_ }) -join ' ' -replace "`r?`n", ' ' }
function Resolve-CAvisos([string[]]$permitidos, [int]$sec = 3) {
  for ($i = 0; $i -lt $sec * 4; $i++) {
    $preg = Resolve-CPreguntas 0; if ($preg) { return $preg }
    $a = Get-CAvisos | Select-Object -First 1
    if ($a) {
      $t = Get-CAvisoTexto $a; $btns = [CasaWin]::Kids($a) | Where-Object { [CasaWin]::Cls($_) -eq 'Button' }
      $ok = $btns | Where-Object { [CA]::Get($_) -match '^&?Aceptar$|^&?OK$' } | Select-Object -First 1
      if (@($btns).Count -eq 1 -and $ok -and ($permitidos | Where-Object { $t -like $_ })) { Click-CBtn ([IntPtr]$ok); Start-Sleep -Milliseconds 600; return "aceptado: $t" }
      if (@($btns).Count -eq 1 -and $ok) { Click-CBtn ([IntPtr]$ok); throw "CASA avisó: $t" }
      throw "CASA pregunta algo que no conozco (lo dejé abierto): $t"
    }
    Start-Sleep -Milliseconds 250
  }
  $null
}

# Celda que encontró la búsqueda: banda resaltada angosta (< 250 px) de 10+ px de alto.
# Si no hay angosta y solo hay un renglón resaltado, es ese (la celda cae en un renglón ya marcado).
function Get-CFoundCell([IntPtr]$grid) {
  $b = [CPix]::Snap($grid); $bands = @([CPix]::Bands($b, [System.Drawing.SystemColors]::Highlight) | Where-Object { ($_[1] - $_[0]) -ge 9 }); $b.Dispose()
  $n = @($bands | Where-Object { ($_[3] - $_[2]) -lt 250 })
  $f = if ($n.Count -eq 1) { $n[0] } elseif ($n.Count -eq 0 -and $bands.Count -eq 1) { $bands[0] } else { $null }
  if (-not $f) { return $null }
  [pscustomobject]@{ X = [int](($f[2] + $f[3]) / 2); Y = [int](($f[0] + $f[1]) / 2); Y0 = $f[0]; Y1 = $f[1]; X0 = $f[2]; X1 = $f[3] }
}
# Clic (por mensaje) en la celda encontrada. Devuelve "x,y" o $null.
function Select-CRow([IntPtr]$grid, [switch]$Double) {
  $c = Get-CFoundCell $grid; if (-not $c) { return $null }
  Send-CClick $grid $c.X $c.Y -Double:$Double; "$($c.X),$($c.Y)"
}
# Pone el grid en la columna $col (0 = Referencia) y escribe el pedimento en el TEdit de búsqueda.
function Find-CPed([IntPtr]$grid, [IntPtr]$edit, [string]$ped, [int]$col) {
  Send-CKey $grid 0x24; Start-Sleep -Milliseconds 300; Send-CKey $grid 0x27 $col; Start-Sleep -Milliseconds 500
  [void][CA]::SendMessage($edit, 0x0C, [IntPtr]::Zero, ''); Start-Sleep -Milliseconds 200
  [void][CA]::SendMessage($edit, 0x0C, [IntPtr]::Zero, $ped); Start-Sleep -Milliseconds 1200
}

# ---------- OCR de Windows (para leer el renglón seleccionado) ----------
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$script:AsTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Wait-CAsync($op, [Type]$t) { $task = $script:AsTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(); $task.Result }
function Get-OcrText([System.Drawing.Bitmap]$bmp) {
  $big = New-Object System.Drawing.Bitmap ($bmp.Width * 3), ($bmp.Height * 3); $g = [System.Drawing.Graphics]::FromImage($big); $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($bmp, 0, 0, $big.Width, $big.Height); $g.Dispose()
  $ms = New-Object System.IO.MemoryStream; $big.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $big.Dispose()
  $ras = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
  $w = New-Object Windows.Storage.Streams.DataWriter($ras.GetOutputStreamAt(0)); $w.WriteBytes($ms.ToArray()); [void](Wait-CAsync ($w.StoreAsync()) ([uint32]))
  $dec = Wait-CAsync ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $sb = Wait-CAsync ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  (Wait-CAsync ($eng.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult])).Text
}
function Get-CRowText([IntPtr]$grid) {
  $c = Get-CFoundCell $grid; if (-not $c) { return '' }
  $b = [CPix]::Snap($grid); $y0 = [Math]::Max(0, $c.Y0 - 1)
  $crop = $b.Clone((New-Object System.Drawing.Rectangle 12, $y0, ([Math]::Min(900, $b.Width) - 12), ([Math]::Min($c.Y1 - $c.Y0 + 3, $b.Height - $y0))), [System.Drawing.Imaging.PixelFormat]::Format32bppArgb); $b.Dispose()
  [CPix]::Flatten($crop, [System.Drawing.SystemColors]::Highlight, $c.X0 - 12, $c.X1 - 12); Get-OcrText $crop
}

# ---------- diálogos de guardar ----------
function Wait-CSave([int]$sec = 30) {
  $tit = 'Guardar impresión como', 'Exportar a:', 'Guardar como'
  for ($i = 0; $i -lt $sec * 4; $i++) { $d = [CasaWin]::Tops() | Where-Object { $tit -contains [CasaWin]::Text($_) } | Select-Object -First 1; if ($d) { Start-Sleep -Milliseconds 800; return [IntPtr]$d }; Start-Sleep -Milliseconds 250 }
  [IntPtr]::Zero
}
# Llena el diálogo de guardar. -Ruta: archivo destino, o carpeta si se usa -Propuesto (nombre que trae CASA + .pdf).
# -Esperado: patrón que debe cumplir el nombre que propone CASA (así se comprueba que es el pedimento correcto).
function Save-CDialog([string]$Ruta, [string]$Esperado, [int]$sec = 40, [switch]$Propuesto) {
  $dlg = Wait-CSave $sec; if ($dlg -eq [IntPtr]::Zero) { throw "No apareció la ventana de guardar" }
  $k = [CasaWin]::Kids($dlg)
  $edit = $k | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' -and [CasaWin]::Cls([CasaWin]::GetParent($_)) -eq 'ComboBox' } | Select-Object -First 1
  if (-not $edit) { $edit = $k | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' } | Select-Object -First 1 }
  $ok = $k | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Guardar' } | Select-Object -First 1
  $can = $k | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Cancelar' } | Select-Object -First 1
  if (-not $edit -or -not $ok) { throw "No encontré el campo o el botón Guardar" }
  $prop = [CA]::Get([IntPtr]$edit)
  $cancel = { if ($can) { Click-CBtn ([IntPtr]$can) } }
  if ($Esperado -and $prop -notlike $Esperado) { & $cancel; throw "CASA propuso '$prop' (esperaba $Esperado); cancelé" }
  if ($Propuesto) { $leaf = Split-Path $prop -Leaf; if ($leaf -notmatch '\.pdf$') { $leaf += '.pdf' }; $Ruta = Join-Path $Ruta $leaf }
  if (Test-Path -LiteralPath $Ruta) { & $cancel; return "ya existía (cancelé): $(Split-Path $Ruta -Leaf)" }
  [void][CA]::SendMessage([IntPtr]$edit, 0x0C, [IntPtr]::Zero, $Ruta); Start-Sleep -Milliseconds 200
  if ([CA]::Get([IntPtr]$edit) -ne $Ruta) { & $cancel; throw "No pude escribir la ruta; cancelé" }
  Click-CBtn ([IntPtr]$ok)
  for ($i = 0; $i -lt 80; $i++) { if ((Test-Path -LiteralPath $Ruta) -and (Get-Item -LiteralPath $Ruta).Length -gt 0) { Start-Sleep -Milliseconds 700; return "guardado: $(Split-Path $Ruta -Leaf)" }; Start-Sleep -Milliseconds 500 }
  throw "No se creó $(Split-Path $Ruta -Leaf)"
}
# En "Opciones de Impresión": Exportar -> PDF (3.er elemento: Excel, Excel Sólo Datos, PDF, RTF[, TIFF]).
function Export-CPdf([IntPtr]$opc) {
  $p = Get-CXY 'exportar'; $ids = Get-CDropIds (Get-COptPanel $opc) $p[0] $p[1]
  if ($ids.Count -lt 4 -or $ids.Count -gt 5) { throw "El menú Exportar no es el esperado ($($ids.Count) opciones)" }
  Invoke-CPopup $ids[2]
}
# En "Configurar impresión": elige la impresora; devuelve $true si quedó.
function Set-CPrinter([IntPtr]$dlg, [string]$name = 'Microsoft Print to PDF') {
  $cb = [IntPtr]([CasaWin]::Kids($dlg) | Where-Object { [CasaWin]::Cls($_) -eq 'ComboBox' } | Select-Object -First 1)
  $i = [CA]::SendMessage($cb, 0x158, [IntPtr](-1), $name).ToInt32(); if ($i -lt 0) { return $false }
  [void][CA]::SendMessage($cb, 0x14E, [IntPtr]$i, [IntPtr]::Zero)
  [void][CA]::SendMessage($dlg, 0x111, [IntPtr]((1 -shl 16) -bor [CA]::GetDlgCtrlID($cb)), $cb); Start-Sleep -Milliseconds 800
  [CA]::Get($cb) -eq $name
}
function Get-CPrintDlg { $d = [CasaWin]::Tops() | Where-Object { [CasaWin]::Text($_) -eq 'Configurar impresión' } | Select-Object -First 1; if ($d) { [IntPtr]$d } else { [IntPtr]::Zero } }
function Wait-CPrintDlg([int]$sec = 10) { for ($i = 0; $i -lt $sec * 4; $i++) { $d = Get-CPrintDlg; if ($d -ne [IntPtr]::Zero) { Start-Sleep -Milliseconds 500; return $d }; Start-Sleep -Milliseconds 250 }; [IntPtr]::Zero }

# ---------- preparación ----------
function Assert-CasaLista {
  if (-not (Get-CPid)) { throw 'CASA no está abierto' }
  if ((Get-CasaNivel).Problema) { throw 'CASA está abierto como administrador y Expedito no: Windows bloquea los clics. Cierra CASA y ábrelo normal, o abre Expedito como administrador (clic derecho → Ejecutar como administrador).' }
  [void](Resolve-CPreguntas 0)
  $m = Get-CMain; if ($m -eq [IntPtr]::Zero) { throw 'No encontré la ventana principal de CASA (¿pantalla de login?)' }
  if ([CA]::IsIconic($m)) { [void][CA]::ShowWindow($m, 9); Start-Sleep 1 }
  $p = @(Get-CPopups); if ($p.Count) { throw ("CASA tiene una ventana abierta: " + (($p | ForEach-Object { [CasaWin]::Text($_) }) -join ', ') + ". Ciérrala y vuelve a intentar.") }
}
function Open-CCatalogo([string]$ped) {
  if ((Get-CChild 'TFm_BusPed') -eq [IntPtr]::Zero) { Invoke-CMenu 'catalogo' }
  $cat = Wait-CChild 'TFm_BusPed'; if ($cat -eq [IntPtr]::Zero) { throw 'No abrió el Catálogo' }
  [void][CA]::SendMessage((Find-CCtl (Get-CMain) 'MDIClient'), 0x222, $cat, [IntPtr]::Zero); Start-Sleep -Milliseconds 500   # WM_MDIACTIVATE
  $grid = Find-CCtl $cat 'TDBGrid'; Find-CPed $grid (Find-CCtl $cat 'TEdit') $ped 5
  $ocr = Get-CRowText $grid
  if ($ocr -notmatch [regex]::Escape($ped)) { throw "No encontré $ped en el Catálogo (pestañas 'Todos'?). Leí: $ocr" }
  Select-CSoloRenglon $grid $ped
  $op = if ($ocr -match '\s([12])\s+(?:[A-Z][A-Z0-9]\s+)?\d{2}/\d{2}/\d{4}') { [int]$Matches[1] } else { 0 }
  [pscustomobject]@{ Cat = $cat; Grid = $grid; Op = $op }
}
# En el Catálogo el clic es un interruptor: un renglón ya seleccionado se DESselecciona, y pueden quedar otros
# renglones seleccionados de antes (CASA toma el primero). Se da clic en otro renglón (limpia la selección)
# y luego en el del pedimento; al final debe haber UN solo renglón seleccionado y debe ser el del pedimento.
function Get-CRenglonesSel([IntPtr]$grid) {
  $b = [CPix]::Snap($grid); $w = $b.Width
  $r = @([CPix]::Bands($b, [System.Drawing.SystemColors]::Highlight) | Where-Object { ($_[1] - $_[0]) -ge 9 -and ($_[3] - $_[2]) -gt [Math]::Min(500, $w / 2) } | ForEach-Object { , $_ })
  $b.Dispose(); , $r
}
function Get-CBandaTexto([IntPtr]$grid, $band) {
  $b = [CPix]::Snap($grid); $y0 = [Math]::Max(0, $band[0] - 1)
  $crop = $b.Clone((New-Object System.Drawing.Rectangle 12, $y0, ([Math]::Min(900, $b.Width) - 12), ([Math]::Min($band[1] - $band[0] + 3, $b.Height - $y0))), [System.Drawing.Imaging.PixelFormat]::Format32bppArgb); $b.Dispose()
  [CPix]::Flatten($crop, [System.Drawing.SystemColors]::Highlight, 0, $crop.Width); Get-OcrText $crop
}
function Select-CSoloRenglon([IntPtr]$grid, [string]$ped) {
  $c = Get-CFoundCell $grid; if (-not $c) { throw 'No pude ubicar el renglón del pedimento' }
  $alto = [Math]::Max(16, $c.Y1 - $c.Y0 + 3)
  for ($intento = 1; $intento -le 3; $intento++) {
    $otroY = if ($c.Y - $alto -gt 30) { $c.Y - $alto } else { $c.Y + $alto }
    Send-CClick $grid $c.X $otroY; Start-Sleep -Milliseconds 600      # otro renglón: limpia lo que hubiera seleccionado
    Send-CClick $grid $c.X $c.Y; Start-Sleep -Milliseconds 800        # el del pedimento
    $sel = Get-CRenglonesSel $grid
    if ($sel.Count -eq 1 -and [Math]::Abs((($sel[0][0] + $sel[0][1]) / 2) - $c.Y) -le 5) {
      $t = Get-CBandaTexto $grid $sel[0]
      if ($t -match [regex]::Escape($ped)) { return }
      throw "El renglón seleccionado no es $ped (leí: $t)"
    }
  }
  throw "No pude dejar seleccionado solo el pedimento $ped en el Catálogo ($($sel.Count) renglones seleccionados)"
}
# Menú del botón Vucem del Catálogo: los números de comando cambian de una PC a otra (CASA los reparte al abrir),
# pero el ORDEN es el mismo. Se usa la posición: Respuesta COVE = 4.º elemento, Registrar Manifiesto = 12.º (en expo no aparece).
$script:VucemPosCove = [int]$CasaMapa.vucemRespCovePos; $script:VucemPosManif = [int]$CasaMapa.vucemManifPos
function Get-CVucemIds([IntPtr]$cat) {
  $vb = Find-CToolbar $cat 'Vucem'; if (-not $vb) { throw 'No encontré el botón Vucem' }
  $ids = @(Get-CDropIds $vb.H $vb.X $vb.Y)
  if ($ids.Count -le $script:VucemPosCove) { throw "El menú Vucem no es el esperado ($($ids.Count) elementos: $($ids -join ',')). Revisa Configuración → Mapa de CASA" }
  $ids
}

# ---------- flujos ----------
# Varias facturas = varios COVE: "Todos" abre UNA ventana de guardar pero CASA escribe todos los COVE<n>.pdf en esa carpeta;
# el acuse es por factura (renglón de "Fol. Fact."). Todo se guarda en una carpeta temporal y se copia solo lo que falta.
function Invoke-CasaCove([string]$ped, [string]$ref, [string]$dir, $log) {
  $c = Open-CCatalogo $ped; $vids = Get-CVucemIds $c.Cat
  Invoke-CPopup $vids[$script:VucemPosCove]                              # Respuesta COVE
  $r = Resolve-CAvisos @('*ya fue Pagado*ADDENDA*', '*Consolidado*') 6; if ($r) { & $log $r }
  $w = Wait-CVentana 'TFm_RegCOVE' -sec 20 -log $log; if ($w -eq [IntPtr]::Zero) { [void](Resolve-CAvisos @() 1); throw 'No abrió Registro COVE' }
  $tmp = Join-Path $env:TEMP "casa_cove_$ped"; if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }; [void](New-Item -ItemType Directory $tmp)
  try {
    # con varias facturas CASA tarda en llenar la ventana: esperar la referencia hasta 10 s
    for ($k = 0; $k -lt 40; $k++) {
      $eds = [CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TDBEdRes' }; $txt = @($eds | ForEach-Object { [CA]::Get($_) })
      if ($txt -contains $ref) { break }
      $otra = $txt | Where-Object { $_ -match '^[A-Z]{2,6}\d{0,4}-\d{4}$' } | Select-Object -First 1; if ($otra) { throw "Registro COVE abrió $otra, no $ref" }
      Start-Sleep -Milliseconds 250
    }
    if ($txt -notcontains $ref) { throw "Registro COVE no mostró la referencia $ref" }
    $covEd = [IntPtr]($eds | Where-Object { [CA]::Get($_) -match '^COVE[0-9A-Z]{9}$' } | Select-Object -First 1)
    if ($covEd -eq [IntPtr]::Zero) { throw 'Registro COVE sin número de COVE' }
    # grid "Fol. Fact." = el TDBGrid más alto; renglones de 18 px debajo del encabezado
    $fg = [CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TDBGrid' } | ForEach-Object { $r2 = New-Object CA+R; [void][CA]::GetWindowRect($_, [ref]$r2); [pscustomobject]@{ H = [IntPtr]$_; Alto = $r2.B - $r2.T } } | Sort-Object Alto -Descending | Select-Object -First 1
    $fg = $fg.H; $coves = New-Object System.Collections.ArrayList
    for ($i = 0; $i -lt 40; $i++) {
      $p = Get-CXY 'coveRenglon'; Send-CClick $fg $p[0] ($p[1] + [int]$CasaMapa.coveAlto * $i); Start-Sleep -Milliseconds 900
      $cv = [CA]::Get($covEd); if ($coves -contains $cv) { break }; [void]$coves.Add($cv)
    }
    & $log "Registro COVE de $ref`: $($coves.Count) factura(s): $($coves -join ', ')"
    $tb = Find-CCtl $w 'TToolBar'; $side = [IntPtr][CasaWin]::GetParent($tb)
    $faltaCove = @($coves | Where-Object { -not (Test-Path -LiteralPath "$dir\$_.pdf") })
    if ($faltaCove.Count) {
      $p = Get-CXY 'coveTodos'; Send-CClick $side $p[0] $p[1]     # botón "Todos" (debajo de Imprimir)
      & $log (Save-CDialog $tmp '*COVE*' 40 -Propuesto)
      for ($k = 0; $k -lt 40 -and @($coves | Where-Object { -not (Test-Path -LiteralPath "$tmp\$_.pdf") }).Count; $k++) { Start-Sleep -Milliseconds 500 }
      Start-Sleep 1
      foreach ($cv in $faltaCove) { if (Test-Path -LiteralPath "$tmp\$cv.pdf") { Copy-Item -LiteralPath "$tmp\$cv.pdf" -Destination $dir; & $log "copiado: $cv.pdf" } else { & $log "⚠ CASA no generó $cv.pdf" } }
    }
    for ($i = 0; $i -lt $coves.Count; $i++) {
      $cv = $coves[$i]; $leaf = "Reporte_ACUSE_COVE_$cv.pdf"; if (Test-Path -LiteralPath "$dir\$leaf") { continue }
      $p = Get-CXY 'coveRenglon'; Send-CClick $fg $p[0] ($p[1] + [int]$CasaMapa.coveAlto * $i); Start-Sleep -Milliseconds 900
      if ([CA]::Get($covEd) -ne $cv) { throw "No pude seleccionar la factura del $cv" }
      $p = Get-CXY 'coveImpFlecha'; $ids2 = Get-CDropIds $tb $p[0] $p[1]   # flechita de Imprimir: [0] Acuse COVE, [1] Acuse e_document
      if ($ids2.Count -ne 2) { throw 'Menú de Imprimir inesperado' }
      Invoke-CPopup $ids2[0]
      $opc = Wait-CPopup 'TFm_opcimpcta' 20; if ($opc -eq [IntPtr]::Zero) { throw 'No abrió Opciones de Impresión (acuse)' }
      Export-CPdf $opc; [void](Save-CDialog $tmp "*ACUSE_COVE_$cv*" 40 -Propuesto); Close-CWin 'TFm_opcimpcta'
      Copy-Item -LiteralPath "$tmp\$leaf" -Destination $dir; & $log "guardado: $leaf"
    }
  } finally {
    Close-CMenu; Close-CWin 'TFm_opcimpcta'; Close-CHwnd $w
    $preg = Resolve-CPreguntas 3; if ($preg) { & $log $preg }
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }
}
function Invoke-CasaMV([string]$ped, [string]$ref, [string]$dir, $log) {
  $c = Open-CCatalogo $ped
  if ($c.Op -eq 2) { & $log 'Es exportación (Op. 2): no lleva manifestación'; return }
  $ids = Get-CVucemIds $c.Cat
  if ($ids.Count -le $script:VucemPosManif) { & $log 'El menú Vucem no trae Registrar Manifiesto (expo): no lleva manifestación'; return }
  Invoke-CPopup $ids[$script:VucemPosManif]                                 # Registrar Manifiesto de valor Electrónico
  $script:ultPregunta = $null
  $logMv = $log
  $w = Wait-CVentana 'TFm_BMManValVU' -Mdi -sec 25 -log { param($m) $script:ultPregunta = $m; & $logMv $m }
  if ($w -eq [IntPtr]::Zero) {
    [void](Resolve-CAvisos @() 1)
    # indicado por el usuario: si tras contestar No CASA no abre la manifestación, se deja pendiente y él la revisa a mano
    if ($script:ultPregunta) { & $log '⚠ Manifestación pendiente: CASA no la abrió después de contestar No a "COVE''s cambiados". Revísala a mano.'; $script:mvPendiente = $true; return }
    throw 'No abrió la Manifestación de Valor'
  }
  try {
    $est = [CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TDBEdRes' } | ForEach-Object { [CA]::Get($_) } | Where-Object { $_ -match '^(ENVIADO|ELABORADA|CANCELADA|RECHAZADA)' } | Select-Object -First 1
    if ($est -ne 'ENVIADO A VUCEM') { & $log "Manifestación en estatus '$est': se omite AMV_/MV_"; return }
    $ac = Find-CToolbar $w 'Acuse VU'; if (-not $ac) { throw 'No encontré Acuse VU' }
    if (-not (Test-Path -LiteralPath "$dir\AMV_$ref.pdf")) {
      $p = Get-CXY 'acuseVU'; Send-CClick $ac.H $p[0] $p[1]
      $opc = Wait-CPopup 'TFm_opcimpcta' 20; if ($opc -eq [IntPtr]::Zero) { throw 'No abrió Opciones (Acuse VU)' }
      Export-CPdf $opc; & $log (Save-CDialog "$dir\AMV_$ref.pdf" '*Manifestaci*'); Close-CWin 'TFm_opcimpcta'
    }
    if (-not (Test-Path -LiteralPath "$dir\MV_$ref.pdf")) {
      $p = Get-CXY 'acuseVUFlecha'; $ids2 = Get-CDropIds $ac.H $p[0] $p[1]   # flechita: [0] Rep. M.E.
      if ($ids2.Count -ne 1) { throw 'Menú de Acuse VU inesperado' }
      Invoke-CPopup $ids2[0]
      $opc = Wait-CPopup 'TFm_opcimpcta' 30; if ($opc -eq [IntPtr]::Zero) { throw 'No abrió Opciones (Rep. M.E.)' }
      Export-CPdf $opc; & $log (Save-CDialog "$dir\MV_$ref.pdf" '*export*' 60); Close-CWin 'TFm_opcimpcta'
    }
  } finally { Close-CWin 'TFm_opcimpcta'; Close-CHwnd $w }
}
# Abre Impresión (74) o Simplificada (76) y pasa el pedimento a Selección.
function Open-CImpresion([string]$menu, [string]$ped, [string]$ref, [string[]]$casillas) {
  $old = Get-CChild 'TFm_SelPedIm'; if ($old -ne [IntPtr]::Zero) { Close-CHwnd $old; Start-Sleep 1 }
  Invoke-CMenu $menu; $w = Wait-CChild 'TFm_SelPedIm'; if ($w -eq [IntPtr]::Zero) { throw 'No abrió la ventana de impresión' }
  foreach ($c in $casillas) { Set-CCheck (Find-CCtl $w 'TCheckBox' $c) }
  Click-CBtn (Find-CCtl $w 'TRadioButton' 'Todos'); Start-Sleep 2
  $grid = Find-CCtl $w 'TDBGrid'; $lv = Find-CCtl $w 'TListView'
  Find-CPed $grid (Find-CCtl $w 'TEdit') $ped 1
  $ocr = Get-CRowText $grid; if ($ocr -notmatch [regex]::Escape($ped)) { throw "No encontré $ped en Impresión. Leí: $ocr" }
  [void](Select-CRow $grid -Double); Start-Sleep 2
  $n = [CA]::SendMessage($lv, 0x1004, [IntPtr]::Zero, [IntPtr]::Zero).ToInt32()
  if ($n -ne 1) { throw "Selección tiene $n pedimentos (debe ser 1)" }
  $w
}
function Invoke-CasaPagado([string]$ped, [string]$ref, [string]$dir, $log, [int]$op = 1) {
  $w = Open-CImpresion 'impresion' $ped $ref @('Leyenda de Copias Tradicional', 'Bloque de Facturas Tradicional', 'Bloque de Facturas Con COVE')
  try {
    $p = Get-CXY 'copias'; Send-CClick (Get-CSidePanel $w) $p[0] $p[1]   # botón Copias
    $cp = Wait-CPopup 'TFm_ImpVarCopias'; if ($cp -eq [IntPtr]::Zero) { throw 'No abrió Elija las Copias' }
    foreach ($t in 'Primera Copia*', 'Segunda Copia*', 'Tercera Copia*', 'Cuarta copia*') { Set-CCheck (Find-CCtl $cp 'TCheckBox' $t) $true }
    Set-CCheck (Find-CCtl $cp 'TCheckBox' 'Original*') $false
    if ([CA]::Get((Find-CCtl $cp 'TComboBox')) -ne 'Todas las Páginas') { throw 'El combo de páginas no dice Todas las Páginas' }
    $pan = Find-CCtl $cp 'TPanel'
    $pc = Get-CXY 'copiasConfig'; Send-CClick $pan $pc[0] $pc[1]; $pd = Wait-CPrintDlg; if ($pd -eq [IntPtr]::Zero) { throw 'No abrió Configurar impresión' }
    if (-not (Set-CPrinter $pd)) { Click-CBtn (Find-CCtl $pd 'Button' 'Cancelar'); throw 'No pude elegir Microsoft Print to PDF' }
    Click-CBtn (Find-CCtl $pd 'Button' 'Aceptar'); Start-Sleep 1
    # comprobación: reabrir y leer la impresora antes de imprimir (para no mandar a la RICOH)
    Send-CClick $pan $pc[0] $pc[1]; $pd = Wait-CPrintDlg; if ($pd -eq [IntPtr]::Zero) { throw 'No reabrió Configurar impresión' }
    $imp = [CA]::Get([IntPtr]([CasaWin]::Kids($pd) | Where-Object { [CasaWin]::Cls($_) -eq 'ComboBox' } | Select-Object -First 1))
    Click-CBtn (Find-CCtl $pd 'Button' 'Cancelar'); Start-Sleep 1
    if ($imp -ne 'Microsoft Print to PDF') { throw "La impresora quedó en '$imp'; no imprimí" }
    $p = Get-CXY 'copiasImprimir'; Send-CClick $pan $p[0] $p[1]   # Imprimir
    foreach ($p in (Get-CasaPrefijos $op)) { & $log (Save-CDialog "$dir\$p$ref.pdf" '' 60) }   # expo: EXP_ en lugar de IMP_
  } finally { Close-CWin 'TFm_ImpVarCopias'; Close-CHwnd (Get-CChild 'TFm_SelPedIm') }
}
function Invoke-CasaSimp([string]$ped, [string]$ref, [string]$dir, $log) {
  $w = Open-CImpresion 'simplificada' $ped $ref @('Leyenda de Copias Tradicional')
  try {
    $p = Get-CXY 'simpOpciones'; Send-CClick (Get-CSidePanel $w) $p[0] $p[1]   # botón Opciones
    $opc = Wait-CPopup 'TFm_CopImp'; if ($opc -eq [IntPtr]::Zero) { throw 'No abrió Opciones de Impresión' }
    $rb = Find-CCtl $opc 'TGroupButton' 'Segunda Copia*'; Click-CBtn $rb
    if (-not (Get-CCheck $rb)) { throw 'No quedó marcada la Segunda Copia' }
    Export-CPdf $opc; & $log (Save-CDialog "$dir\SIMP_$ref.pdf" "*Referencia $ref*" 40)
  } finally { Close-CWin 'TFm_CopImp'; Close-CHwnd (Get-CChild 'TFm_SelPedIm') }
}

# Qué grupos faltan en la carpeta.
function Get-CasaFaltantes([string]$dir, [string]$ref, [int]$op = 1) {
  $n = (Get-ChildItem -LiteralPath $dir -File).Name
  $g = @()
  if (Get-CasaPrefijos $op | Where-Object { -not (Test-Path -LiteralPath "$dir\$_$ref.pdf") }) { $g += 'Pagado' }
  if (-not (Test-Path -LiteralPath "$dir\SIMP_$ref.pdf")) { $g += 'Simp' }
  $cv = @($n | Where-Object { $_ -match '^(COVE[0-9A-Z]{9})\.pdf$' } | ForEach-Object { $_ -replace '\.pdf$' })
  $ac = @($n | Where-Object { $_ -match '^Reporte_ACUSE_COVE_(COVE[0-9A-Z]{9})\.pdf$' } | ForEach-Object { $_ -replace '^Reporte_ACUSE_COVE_|\.pdf$' })
  if (-not $cv.Count -or ($cv | Where-Object { $ac -notcontains $_ }) -or ($ac | Where-Object { $cv -notcontains $_ })) { $g += 'Cove' }
  if ($op -ne 2 -and (-not (Test-Path -LiteralPath "$dir\AMV_$ref.pdf") -or -not (Test-Path -LiteralPath "$dir\MV_$ref.pdf"))) { $g += 'MV' }   # expo: sin manifestación
  $g
}

# Corre los flujos de CASA para un pedimento. Cada grupo es independiente: si uno falla, sigue con el siguiente.
# "Detener" del usuario: nunca a la mitad de un paso de CASA. La app prende $global:CasaAlto.ya y aquí se revisa
# solo en puntos seguros (entre grupos, con las ventanas de CASA ya cerradas). Sin la app ($global:CasaAlto vacío) no hace nada.
function Test-CasaAlto { if ($global:CasaAlto -and $global:CasaAlto.ya) { throw [System.OperationCanceledException]::new('Detenido por el usuario') } }
function Invoke-CasaAuto {
  param([Parameter(Mandatory)][string]$Pedimento, [string]$Dir, [string[]]$Grupos, [scriptblock]$Log = { param($m) Write-Host $m }, [scriptblock]$Avance = { param($i, $n, $g) })
  $ref = Get-CasaRef $Pedimento
  if (-not $Dir) { $Dir = Get-CasaCarpeta $Pedimento }; if (-not $Dir) { throw "No hay carpeta con $Pedimento" }
  # impo/expo: del archivo de validación M; si no está, del Catálogo de CASA (OCR)
  $op = Get-CasaOp $Pedimento $Dir
  if (-not $op) { Assert-CasaLista; $op = (Open-CCatalogo $Pedimento).Op; if (-not $op) { throw 'No pude saber si es impo o expo' } }
  & $Log $(if ($op -eq 2) { 'Exportación: copias T_, EXP_, AA_, S_ y sin manifestación' } else { 'Importación: copias T_, IMP_, AA_, S_ y manifestación' })
  if (-not $Grupos) { $Grupos = Get-CasaFaltantes $Dir $ref $op }
  if ($op -eq 2) { $Grupos = @($Grupos | Where-Object { $_ -ne 'MV' }) }
  if (-not $Grupos) { & $Log 'No falta nada de CASA'; return }
  Assert-CasaLista
  $res = [ordered]@{}
  $hay = @('Pagado', 'Simp', 'Cove', 'MV' | Where-Object { $Grupos -contains $_ }); $iG = 0
  foreach ($g in 'Pagado', 'Simp', 'Cove', 'MV') {
    if ($Grupos -notcontains $g) { continue }
    Test-CasaAlto   # punto seguro: el grupo anterior ya cerró sus ventanas
    & $Avance $iG $hay.Count $g; $iG++
    & $Log "== $g"; $script:mvPendiente = $false
    try {
      switch ($g) { 'Pagado' { Invoke-CasaPagado $Pedimento $ref $Dir $Log $op } 'Simp' { Invoke-CasaSimp $Pedimento $ref $Dir $Log }
                    'Cove' { Invoke-CasaCove $Pedimento $ref $Dir $Log } 'MV' { Invoke-CasaMV $Pedimento $ref $Dir $Log } }
      $res[$g] = if ($script:mvPendiente) { 'PENDIENTE (revisar a mano)' } else { 'OK' }
    } catch {
      $res[$g] = "ERROR: $($_.Exception.Message)"; & $Log "⚠ $g`: $($_.Exception.Message)"
      Close-CMenu; foreach ($c in 'TFm_opcimpcta', 'TFm_CopImp', 'TFm_ImpVarCopias', 'TFm_RegCOVE') { Close-CWin $c }
      $preg = Resolve-CPreguntas 2; if ($preg) { & $Log $preg }
      $pend = @(Get-CPopups); if ($pend.Count) { & $Log ("Quedó abierto en CASA: " + (($pend | ForEach-Object { [CasaWin]::Text($_) }) -join ', ') + ". Revísalo."); break }
    }
  }
  & $Avance $hay.Count $hay.Count ''
  $res
}

# ---------- un pedimento completo: Preparar + CASA automático + revisión ----------
# Lo usan "Varios pedimentos" en esta PC y el remoto. $Fila recibe (columna, valor): est, cli, op, fal, res y av (avance en %).
function Invoke-CasaPedimento {
  param([Parameter(Mandatory)][string]$Pedimento, [switch]$Casa, [scriptblock]$Log = { param($m) Write-Host $m }, [scriptblock]$Fila = { param($c, $v) })
  $sal = @{ Parar = $false; Est = '' }
  $pedCP = $Pedimento
  try {
    & $Fila 'est' 'Buscando carpeta'; & $Fila 'av' 3
    $c = @(Get-CasaCarpetas $pedCP)
    if (-not $c.Count) { & $Fila 'est' 'Sin carpeta'; & $Fila 'av' 100; & $Log '⚠ No hay carpeta con este pedimento'; $sal.Est = 'Sin carpeta'; return $sal }
    if ($c.Count -gt 1) { & $Fila 'est' "Varias carpetas ($($c.Count))"; & $Fila 'res' 'Hazlo en la pestaña Expediente para elegir la carpeta'; & $Fila 'av' 100; & $Log "⚠ Hay $($c.Count) carpetas: hazlo en la pestaña Expediente"; $sal.Est = 'Varias'; return $sal }
    $dir = $c[0]; & $Fila 'cli' (Get-CasaCliente $dir)
    Test-CasaAlto
    & $Fila 'est' 'Preparando'; & $Fila 'av' 8
    $pr = Invoke-CasaPreparar -Pedimento $pedCP -Dir $dir -Log $Log -Etiqueta $dir.Substring($CasaRoot.Length + 1)
    & $Fila 'op' $(switch ($pr.Op) { 1 { 'Impo' } 2 { 'Expo' } default { '?' } })
    # datos para la FAYC del lote (carpeta relativa a la raíz: en otra PC la raíz puede ser otra ruta)
    $feP = if ($pr.Fecha) { ([datetime]$pr.Fecha).ToString('yyyy-MM-dd') } else { '' }
    & $Fila 'datos' (([ordered]@{ rel = $dir.Substring($CasaRoot.Length + 1); op = [int]$pr.Op; fecha = $feP; cr = "$($pr.CR)"; rem = [int]$pr.Remesas }) | ConvertTo-Json -Compress)
    & $Fila 'av' $(if ($Casa) { 25 } else { 90 })
    $res = $null
    Test-CasaAlto
    if ($Casa) {
      & $Fila 'est' 'CASA automático'
      # avance de CASA: del 25 al 95 % según los grupos que falten (Pagado, Simplificada, COVE, Manifestación)
      $res = Invoke-CasaAuto -Pedimento $pedCP -Dir $dir -Log $Log -Avance { param($i, $n, $g) & $Fila 'av' ([int](25 + 70 * $i / [Math]::Max(1, $n))); if ($g) { & $Fila 'est' "CASA: $(switch ($g) { 'Simp' { 'Simplificada' } 'MV' { 'Manifestación' } default { $g } })" } }
    }
    & $Fila 'est' 'Revisando'; & $Fila 'av' 97
    $todo = @((Start-CasaExpediente -Pedimento $pedCP -Dir $dir -SoloRevisar).Faltan -split ', ' | Where-Object { $_ })
    $falt = ($todo | Where-Object { $_ -notin 'FAYC', 'ZIP' }) -join ', '
    & $Fila 'fal' $falt
    & $Fila 'res' $(if ($res) { ($res.Keys | ForEach-Object { "$_ $(if ($res[$_] -eq 'OK') { '✔' } else { '✖' })" }) -join '  ' } elseif ($Casa) { 'Nada que hacer en CASA' } else { 'Preparado' })
    $mal = $res -and ($res.Values | Where-Object { $_ -ne 'OK' })
    $sal.Est = if ($mal -or $falt) { 'Revisar' } elseif ($todo -notcontains 'FAYC' -and $todo -notcontains 'ZIP') { 'Completo' } else { 'Listo para FAYC' }
    & $Fila 'est' $sal.Est; & $Fila 'av' 100
  } catch {
    if ($_.Exception -is [System.OperationCanceledException] -or $_.Exception.Message -eq 'Detenido por el usuario') {   # Test-CasaAlto: paró en punto seguro
      $sal.Est = 'Detenido'; $sal.Parar = $true; & $Fila 'res' 'Lo detuvo el usuario (CASA quedó sin ventanas abiertas)'; & $Fila 'est' 'Detenido'; & $Fila 'av' 100; & $Log '⏹ Detenido en punto seguro'; return $sal }
    $sal.Est = 'Error'; & $Fila 'est' 'Error'; & $Fila 'res' $_.Exception.Message; & $Fila 'av' 100; & $Log "⚠ $($_.Exception.Message)"
    if ($_.Exception.Message -match 'CASA tiene una ventana abierta|CASA no está abierto|ventana principal de CASA') { $sal.Parar = $true }
  }
  $sal
}

# ---------- remoto: trabaja la cola (cola\pendientes) hasta vaciarla ----------
# Escribe el avance en cola\estado\<pedimento>.json para que lo vea la PC que lo mandó. $Ctl.stop = detener después del actual.
function Invoke-CasaColaRemoto {
  param($Ctl, [scriptblock]$Log = { param($m) Write-Host $m }, [scriptblock]$Ui = { param($m) })
  $dPen = Get-CasaColaDir 'pendientes'; $dTra = Get-CasaColaDir 'trabajando'; $dHec = Get-CasaColaDir 'hechos'; $dEst = Get-CasaColaDir 'estado'
  $hechos = 0; $parar = $false
  # en variables globales: dentro de Invoke-CasaPedimento "$Log" ya es otro (el de este remoto) y se llamaría a sí mismo
  $global:LogRem = $Log; $global:UiRem = $Ui
  while (-not $Ctl.stop) {
    $req = Get-ChildItem -LiteralPath $dPen -Filter *.json -File -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -First 1
    if (-not $req) { break }
    $r = Read-CasaJson $req.FullName
    try { Move-Item -LiteralPath $req.FullName -Destination "$dTra\$($req.Name)" -Force -ErrorAction Stop } catch { & $Log "⚠ No pude tomar $($req.Name) de la cola: $($_.Exception.Message)"; break }
    if (-not $r -or $r.ped -notmatch '^\d{7}$') { & $Log "⚠ Solicitud inválida en la cola: $($req.Name)"; Move-Item -LiteralPath "$dTra\$($req.Name)" -Destination $dHec -Force -ErrorAction SilentlyContinue; continue }
    $global:EstRem = [ordered]@{ id = $req.Name; ped = $r.ped; de = $r.de; remoto = $CasaEquipo; est = 'Empezando'; av = 0; cli = ''; op = ''; fal = ''; res = ''; datos = ''; msg = ''; hora = (Get-Date -Format s) }
    $global:EstRemArch = "$dEst\$($r.ped).json"
    Write-CasaJson $global:EstRemArch $global:EstRem
    & $Log "== Remoto: $($r.ped) (mandado por $($r.de))"
    $lgR = { param($m) $global:EstRem.msg = "$m"; & $global:LogRem "[$($global:EstRem.ped)] $m" }
    $fiR = { param($c, $v) $global:EstRem[$c] = $v; $global:EstRem.hora = (Get-Date -Format s); & $global:UiRem "@@|$($global:EstRem.ped)|$c|$v"; Write-CasaJson $global:EstRemArch $global:EstRem }
    $x = Invoke-CasaPedimento -Pedimento $r.ped -Casa:([bool]$r.casa) -Log $lgR -Fila $fiR
    Move-Item -LiteralPath "$dTra\$($req.Name)" -Destination $dHec -Force -ErrorAction SilentlyContinue
    $hechos++
    if ($x.Est -eq 'Detenido') { $parar = $true; & $Log '⏹ Remoto detenido por el usuario en esta PC'; break }
    if ($x.Parar) { $parar = $true; & $Log '⚠ Remoto en pausa: CASA necesita atención en esta PC'; break }
  }
  @{ Hechos = $hechos; Parar = $parar }
}
