﻿# Expedito — © 2026 Paulo Castañeda. Todos los derechos reservados.
# Expedito: arma expedientes de CASA (cualquier cliente, cualquier PC). Se abre con el acceso directo que crea Instalar.cmd
# o: powershell -STA -ExecutionPolicy Bypass -File "<carpeta de la app>\expediente-app.ps1"
# Todo lo lento (Preparar, CASA automático, FAYC + ZIP, Revisar equipo) corre en segundo plano: la ventana no se traba.
. "$PSScriptRoot\casa.ps1"
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public class AppWin { [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,StringBuilder l);
  [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,string l);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); }
"@
# Identidad propia en la barra de tareas: sin esto Windows agrupa la ventana con powershell.exe y muestra su ícono azul.
Add-Type 'using System; using System.Runtime.InteropServices; public class AppId { [DllImport("shell32.dll")] public static extern int SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string id); }'
[void][AppId]::SetCurrentProcessExplicitAppUserModelID($(if (-not (Test-Path -LiteralPath "$PSScriptRoot\publicar.ps1")) { 'Expedito.App' } else { 'Expedito.Pruebas' }))
# sin ventana de consola: si se abrió con powershell visible (accesos directos viejos), se oculta
$conW = [AppWin]::GetConsoleWindow(); if ($conW -ne [IntPtr]::Zero) { [void][AppWin]::ShowWindow($conW, 0) }

# ---------- modo manual (Vigilar): llena la ventana de guardar que abra CASA ----------
function Find-CasaDialogo {
  [CasaWin]::Tops() | Where-Object { @('Guardar impresión como','Exportar a:','Guardar como') -contains [CasaWin]::Text($_) } | Select-Object -First 1
}
function Set-CasaDialogo { param($dlg, [string]$Ruta)
  $kids = [CasaWin]::Kids($dlg)
  $edit = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' -and [CasaWin]::Cls([CasaWin]::GetParent($_)) -eq 'ComboBox' } | Select-Object -First 1
  if (-not $edit) { $edit = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Edit' } | Select-Object -First 1 }
  $ok = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Guardar' } | Select-Object -First 1
  if (-not $edit -or -not $ok) { return $false }
  # COVE / acuse sin nombre fijo: se usa el nombre que propone CASA
  if ((Split-Path $Ruta -Leaf) -match '^(COVE|Reporte_ACUSE_COVE) \(') {
    $sb = New-Object System.Text.StringBuilder 1024; [void][AppWin]::SendMessage([IntPtr]$edit, 0x0D, [IntPtr]1024, $sb)
    $leaf = Split-Path $sb.ToString() -Leaf; if ($leaf -notmatch '^(Reporte_ACUSE_)?COVE') { return $false }
    if ($leaf -notmatch '\.pdf$') { $leaf += '.pdf' }; $Ruta = Join-Path (Split-Path $Ruta) $leaf; $script:ultimo = $Ruta
  } else { $script:ultimo = $Ruta }
  if (Test-Path -LiteralPath $Ruta) {
    $can = $kids | Where-Object { [CasaWin]::Cls($_) -eq 'Button' -and [CasaWin]::Text($_) -match 'Cancelar' } | Select-Object -First 1
    if ($can) { [void][CasaWin]::SendMessage($can, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) }; return 'existe' }
  [void][CasaWin]::SendMessage($edit, 0x000C, [IntPtr]::Zero, $Ruta)
  Start-Sleep -Milliseconds 300
  [void][CasaWin]::SendMessage($ok, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero); return 'ok'
}

# ---------- diseño ----------
function Hex([string]$h) { [Drawing.ColorTranslator]::FromHtml($h) }
$Pal = @{ Fondo = Hex '#EEF2F7'; Tarjeta = [Drawing.Color]::White; Head = Hex '#1E3A8A'; HeadTxt = Hex '#C7D2FE'; Texto = Hex '#1F2937'; Gris = Hex '#6B7280'
        Azul = Hex '#2563EB'; Verde = Hex '#16A34A'; Naranja = Hex '#EA580C'; Rojo = Hex '#DC2626'; Morado = Hex '#7C3AED'; Apagado = Hex '#CBD5E1'; Linea = Hex '#E2E8F0' }
$F = @{ Base = New-Object Drawing.Font('Segoe UI', 9); Neg = New-Object Drawing.Font('Segoe UI Semibold', 9.5); Tit = New-Object Drawing.Font('Segoe UI Semibold', 10.5)
        Big = New-Object Drawing.Font('Segoe UI Semibold', 13); App = New-Object Drawing.Font('Segoe UI Semibold', 15); Log = New-Object Drawing.Font('Segoe UI', 9) }

$script:cfg = Get-CasaConfig
$form = New-Object Windows.Forms.Form -Property @{ Text = 'Expedito'; Size = '1180,760'; StartPosition = 'CenterScreen'; MinimumSize = '600,500'; BackColor = $Pal.Fondo; Font = $F.Base }
if (Test-Path -LiteralPath "$PSScriptRoot\app.ico") { $form.Icon = New-Object Drawing.Icon (New-Object IO.MemoryStream (, [IO.File]::ReadAllBytes("$PSScriptRoot\app.ico"))) }   # en memoria: no bloquea el archivo al publicar
function Add-Ctl($c, $parent = $form) { $parent.Controls.Add($c); $c }
function New-Btn([string]$t, $color, [switch]$Contorno) {
  $b = New-Object Windows.Forms.Button -Property @{ Text = $t; FlatStyle = 'Flat'; Height = 34; Font = $F.Neg; Cursor = 'Hand'; UseVisualStyleBackColor = $false }
  $b.Tag = @{ Color = $color; Contorno = [bool]$Contorno }
  $b.Add_EnabledChanged({ Set-BtnColor $this }); Set-BtnColor $b; $b
}
function Set-BtnColor($b) {
  $t = $b.Tag
  if ($t.Contorno) { $b.BackColor = [Drawing.Color]::White; $b.ForeColor = $(if ($b.Enabled) { $t.Color } else { $Pal.Apagado }); $b.FlatAppearance.BorderColor = $(if ($b.Enabled) { $t.Color } else { $Pal.Apagado }); $b.FlatAppearance.BorderSize = 1 }
  else { $b.BackColor = $(if ($b.Enabled) { $t.Color } else { $Pal.Apagado }); $b.ForeColor = [Drawing.Color]::White; $b.FlatAppearance.BorderSize = 0 }
}
function New-Card([string]$titulo) {
  $p = New-Object Windows.Forms.Panel -Property @{ BackColor = $Pal.Tarjeta }
  if ($titulo) { $l = New-Object Windows.Forms.Label -Property @{ Text = $titulo; Font = $F.Tit; ForeColor = $Pal.Head; Location = '14,10'; AutoSize = $true }; $p.Controls.Add($l); $p.Tag = $l }
  $p
}
function New-Lbl([string]$t, [string]$loc, $parent) { Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = $t; Location = $loc; AutoSize = $true; ForeColor = $Pal.Gris }) $parent | Out-Null }

# encabezado
$head = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 62; BackColor = $Pal.Head })
if (Test-Path -LiteralPath "$PSScriptRoot\app.png") { Add-Ctl (New-Object Windows.Forms.PictureBox -Property @{ Image = [Drawing.Image]::FromStream((New-Object IO.MemoryStream (, [IO.File]::ReadAllBytes("$PSScriptRoot\app.png")))); SizeMode = 'Zoom'; Location = '12,9'; Size = '44,44' }) $head | Out-Null }
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Expedito'; Font = $F.App; ForeColor = [Drawing.Color]::White; Location = '64,8'; AutoSize = $true }) $head | Out-Null
function Get-AppVersion { $v = "$PSScriptRoot\version.txt"; if (Test-Path -LiteralPath $v) { (Get-Content -LiteralPath $v -TotalCount 1 -Encoding UTF8).Trim() } else { '0.0.0' } }
$script:verIni = Get-AppVersion
$script:esPrueba = Test-Path -LiteralPath "$PSScriptRoot\publicar.ps1"   # la copia de PRUEBAS es la que publica
$lblSub = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; ForeColor = $Pal.HeadTxt; Location = '66,36'; AutoSize = $true }) $head
function Set-Subtitulo { $ci = (Get-Culture).TextInfo.ToTitleCase("$($CasaEmpresa.ciudad)".ToLower()); $lblSub.Text = "Patente $($CasaEmpresa.patente) · Aduana $($CasaEmpresa.aduana) $ci · v$($script:verIni)" }
Set-Subtitulo
if ($script:esPrueba) { Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'PRUEBAS'; ForeColor = [Drawing.Color]::White; BackColor = $Pal.Rojo; Font = $F.Neg; AutoSize = $true; Padding = '6,2,6,2'; Location = '260,12' }) $head | Out-Null; $form.Text = 'Expedito — PRUEBAS' }
$lblLicHead = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; ForeColor = [Drawing.Color]::White; BackColor = $Pal.Head; Font = $F.Neg; AutoSize = $true; Padding = '6,2,6,2'; Location = '360,12'; Visible = $false; UseMnemonic = $false }) $head
$chkTop = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = 'Siempre encima'; ForeColor = [Drawing.Color]::White; AutoSize = $true; Anchor = 'Top,Right' }) $head
$chkTop.Location = New-Object Drawing.Point ($form.ClientSize.Width - 130), 22
$chkTop.Add_CheckedChanged({ $form.TopMost = $chkTop.Checked })

# pestañas: todo en esta misma ventana (Expediente / Varios pedimentos / Glosa)
$tabs = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 42; BackColor = [Drawing.Color]::White })
$head.SendToBack()   # el encabezado queda arriba de las pestañas
$script:tabBtn = [ordered]@{}; $x = 12
foreach ($k in 'Expediente', 'Varios pedimentos', 'Glosa', 'Pendientes', 'Configuración') {
  $w = [Windows.Forms.TextRenderer]::MeasureText($k, $F.Tit).Width + 32
  $b = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = $k; Font = $F.Tit; AutoSize = $false; TextAlign = 'MiddleCenter'; Cursor = 'Hand'; Location = "$x,0"; Size = "$w,38"; ForeColor = $Pal.Gris }) $tabs
  $u = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Location = "$x,38"; Size = "$w,4"; BackColor = $Pal.Azul; Visible = $false }) $tabs
  $b.Tag = $k; $b.Add_Click({ Show-Pestana $this.Tag })
  $script:tabBtn[$k] = @{ L = $b; U = $u }; $x += $w + 4
}
# módulo de la licencia que necesita cada pestaña (Configuración siempre se ve)
$script:tabMod = @{ 'Expediente' = 'expediente'; 'Varios pedimentos' = 'lote'; 'Glosa' = 'glosa'; 'Pendientes' = 'pendientes' }
function Test-Modulo([string]$m) { -not $script:lic -or $script:lic.Modulos -contains $m }
function Test-Pestana([string]$k) { -not $script:tabMod[$k] -or (Test-Modulo $script:tabMod[$k]) }
# oculta las pestañas que no trae la licencia y recorre las demás a la izquierda
function Set-PestanasLic {
  $x = 12
  foreach ($k in $script:tabBtn.Keys) { $t = $script:tabBtn[$k]; $ver = Test-Pestana $k; $t.L.Visible = $ver
    if (-not $ver) { $t.U.Visible = $false; continue }; $t.L.Left = $x; $t.U.Left = $x; $x += $t.L.Width + 4 }
}

# barra de estado
$st = Add-Ctl (New-Object Windows.Forms.StatusStrip -Property @{ BackColor = [Drawing.Color]::White; SizingGrip = $true })
$stEstado = New-Object Windows.Forms.ToolStripStatusLabel -Property @{ Text = 'Listo'; Spring = $true; TextAlign = 'MiddleLeft' }
$stProg = New-Object Windows.Forms.ToolStripProgressBar -Property @{ Style = 'Marquee'; MarqueeAnimationSpeed = 30; Visible = $false; Width = 140 }
$stPc = New-Object Windows.Forms.ToolStripStatusLabel -Property @{ Text = "PC: $CasaEquipo  ·  © Paulo Castañeda"; ForeColor = $Pal.Gris }
$stStop = New-Object Windows.Forms.ToolStripButton -Property @{ Text = '⏹ Detener'; Visible = $false; ForeColor = [Drawing.Color]::White; BackColor = $Pal.Rojo; Font = $F.Neg; DisplayStyle = 'Text'; Margin = '6,2,6,2' }
$stStop.Add_Click({ Stop-Trabajo -Preguntar })
[void]$st.Items.AddRange(@($stEstado, $stProg, $stStop, $stPc))

# cuerpo con tarjetas (con scroll si no cabe)
$body = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Fill'; AutoScroll = $true; BackColor = $Pal.Fondo })
$body.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic').SetValue($body, $true, $null)
$body.BringToFront()

# tarjeta Expediente
$cExp = Add-Ctl (New-Card '') $body
New-Lbl 'Pedimento' '14,14' $cExp
$txtPed = Add-Ctl (New-Object Windows.Forms.TextBox -Property @{ Location = '90,9'; Width = 120; Font = $F.Big; MaxLength = 7 }) $cExp
$lblOp = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '222,14'; AutoSize = $true; Font = $F.Neg; ForeColor = [Drawing.Color]::White; Padding = '6,2,6,2'; Visible = $false }) $cExp
$lblCli = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Cliente: —'; Location = '330,14'; AutoSize = $true; Font = $F.Neg; ForeColor = $Pal.Texto }) $cExp
New-Lbl 'Carpeta' '14,52' $cExp
$cmbDir = Add-Ctl (New-Object Windows.Forms.ComboBox -Property @{ Location = '90,48'; Width = 450; DropDownStyle = 'DropDownList' }) $cExp
$btnPrep = Add-Ctl (New-Btn '1. Preparar' $Pal.Azul) $cExp
$btnAuto = Add-Ctl (New-Btn '2. CASA automático' $Pal.Verde) $cExp
$btnVig  = Add-Ctl (New-Btn 'Vigilar (manual)' $Pal.Gris -Contorno) $cExp
$btnSkip = Add-Ctl (New-Btn 'Saltar siguiente' $Pal.Gris -Contorno) $cExp
$btnEq   = Add-Ctl (New-Btn 'Revisar equipo' $Pal.Head -Contorno) $cExp
foreach ($b in $btnPrep, $btnAuto, $btnVig, $btnSkip, $btnEq) { $b.Top = 84 }
$btnAuto.Enabled = $false; $btnVig.Enabled = $false; $btnSkip.Enabled = $false
$form.AcceptButton = $btnPrep

# tarjeta Pendientes
$cPend = Add-Ctl (New-Card 'Pendientes de CASA') $body
$lst = Add-Ctl (New-Object Windows.Forms.ListBox -Property @{ Location = '14,36'; BorderStyle = 'None'; DrawMode = 'OwnerDrawFixed'; ItemHeight = 22; IntegralHeight = $false }) $cPend
$lst.Add_DrawItem({ param($s, $e)
  $e.DrawBackground(); if ($e.Index -lt 0) { return }
  $t = "$($lst.Items[$e.Index])"; $ok = $t -like '✔*'
  $col = if ($ok) { $Pal.Verde } else { $Pal.Naranja }
  $e.Graphics.SmoothingMode = 'AntiAlias'
  $e.Graphics.FillEllipse((New-Object Drawing.SolidBrush $col), $e.Bounds.X + 2, $e.Bounds.Y + 7, 8, 8)
  $e.Graphics.DrawString($t, $F.Base, (New-Object Drawing.SolidBrush $Pal.Texto), [float]($e.Bounds.X + 16), [float]($e.Bounds.Y + 3))
})

# tarjeta Registro (con colores)
$cLog = Add-Ctl (New-Card 'Registro') $body
$log = Add-Ctl (New-Object Windows.Forms.RichTextBox -Property @{ Location = '14,36'; BorderStyle = 'None'; ReadOnly = $true; BackColor = [Drawing.Color]::White; Font = $F.Log; DetectUrls = $false; ScrollBars = 'Vertical' }) $cLog
function Log($m) {
  $m = "$m"; $col = $Pal.Texto
  $t = $m -replace '^\[\d{7}\] ', ''
  if ($t -match '^⚠|ERROR|✖|no pude|No encontr') { $col = $Pal.Rojo } elseif ($t -match '^(guardado|copiado|Guardado|✔|contesté|FAYC OK|ZIP OK|Terminó CASA: ya|Equipo listo)') { $col = $Pal.Verde } elseif ($t -match '^==|^---') { $col = $Pal.Azul }
  if ($log.TextLength -gt 150000) { try { $log.ReadOnly = $false; $log.Select(0, 50000); $log.SelectedText = ''; $log.ReadOnly = $true } catch {} }
  $log.SelectionStart = $log.TextLength; $log.SelectionLength = 0
  $log.SelectionColor = $Pal.Gris; $log.AppendText("$(Get-Date -f HH:mm:ss)  ")
  $log.SelectionColor = $col; $log.AppendText("$m`n"); $log.ScrollToCaret()
}

# tarjeta FAYC
$grp = Add-Ctl (New-Card 'FAYC — revisa antes de generar') $body
$y0 = 40
New-Lbl 'Recinto fiscal' "14,$($y0+3)" $grp
$cmbRec = Add-Ctl (New-Object Windows.Forms.ComboBox -Property @{ Location = "140,$y0"; Width = 200; DropDownStyle = 'DropDown' }) $grp
New-Lbl 'Fecha de pago' "14,$($y0+35)" $grp
$dtPago = Add-Ctl (New-Object Windows.Forms.DateTimePicker -Property @{ Location = "140,$($y0+32)"; Width = 200; Format = 'Long' }) $grp
New-Lbl 'Gastos a terceros' "14,$($y0+67)" $grp
$cmbGas = Add-Ctl (New-Object Windows.Forms.ComboBox -Property @{ Location = "140,$($y0+64)"; Width = 200; DropDownStyle = 'DropDown' }) $grp
New-Lbl 'Elaboró' "14,$($y0+99)" $grp
$cmbEla = Add-Ctl (New-Object Windows.Forms.ComboBox -Property @{ Location = "140,$($y0+96)"; Width = 200; DropDownStyle = 'DropDownList' }) $grp
New-Lbl 'Remesas' "14,$($y0+131)" $grp
$numRem = Add-Ctl (New-Object Windows.Forms.NumericUpDown -Property @{ Location = "140,$($y0+128)"; Width = 60; Maximum = 99 }) $grp
$chkRojo = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = 'Salió ROJO'; Location = "220,$($y0+129)"; AutoSize = $true; ForeColor = $Pal.Rojo; Font = $F.Neg }) $grp
$lblSi = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Marca lo que va en SI (lo demás queda en NO):'; Location = "14,$($y0+166)"; AutoSize = $true; ForeColor = $Pal.Gris }) $grp
$script:siTop = $y0 + 190
$script:chkSi = [ordered]@{}
foreach ($k in $CasaFaycSiNo.Keys) { $script:chkSi[$k] = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = $k; AutoSize = $true; ForeColor = $Pal.Texto }) $grp }
$btnFin = Add-Ctl (New-Btn '3. FAYC + ZIP' $Pal.Naranja) $grp
$btnFin.Height = 40; $btnFin.Font = $F.Tit; $btnFin.Enabled = $false

# ---------- acomodo: >= 900 px dos columnas (FAYC a la derecha); más angosta una columna con FAYC abajo ----------
function Set-Acomodo {
  $body.SuspendLayout(); $body.AutoScrollPosition = New-Object Drawing.Point 0, 0
  $W = $body.ClientSize.Width; $H = $body.ClientSize.Height; $m = 12; $fw = 370
  $ancha = $W -ge (560 + $fw + 3 * $m)
  $lw = if ($ancha) { $W - $fw - 3 * $m } else { $body.Width - 2 * $m - [Windows.Forms.SystemInformation]::VerticalScrollBarWidth - 4 }
  $lw = [Math]::Max(500, $lw)
  # Expediente
  $cExp.SetBounds($m, $m, $lw, 132)
  $lblCli.Left = [Math]::Max(330, $lblOp.Right + 12); $lblCli.MaximumSize = New-Object Drawing.Size ([Math]::Max(80, $lw - $lblCli.Left - 14)), 0
  $cmbDir.Width = $lw - 90 - 14
  $bx = 14; $u = ($lw - 28 - 4 * 6) / 5.7; $i = 0
  foreach ($b in $btnPrep, $btnAuto, $btnVig, $btnSkip, $btnEq) { $b.Left = $bx; $b.Width = [int]($u * @(1, 1.4, 1.1, 1.1, 1.1)[$i]); $bx += $b.Width + 6; $i++ }
  # FAYC: casillas SI/NO en tantas columnas como quepan
  $gw = if ($ancha) { $fw } else { $lw }
  foreach ($c in $cmbRec, $dtPago, $cmbGas, $cmbEla) { $c.Width = [Math]::Min(320, $gw - 140 - 14) }
  $cols = [Math]::Max(2, [Math]::Min(4, [int][Math]::Floor(($gw - 28) / 150))); $cw = [int](($gw - 28) / $cols); $i = 0
  foreach ($c in $script:chkSi.Values) { $c.Location = New-Object Drawing.Point (14 + ($i % $cols) * $cw), ($script:siTop + [Math]::Floor($i / $cols) * 26); $i++ }
  $finTop = $script:siTop + [Math]::Ceiling($script:chkSi.Count / $cols) * 26 + 12
  $btnFin.SetBounds(14, $finTop, $gw - 28, 40)
  $faycAlto = $finTop + 40 + 14
  if ($ancha) {
    $cPend.SetBounds($m, $cExp.Bottom + $m, $lw, 150)
    $cLog.SetBounds($m, $cPend.Bottom + $m, $lw, [Math]::Max(160, $H - $cPend.Bottom - 2 * $m))
    $grp.SetBounds($m + $lw + $m, $m, $fw, [Math]::Max($faycAlto, $H - 2 * $m))
    $body.AutoScrollMinSize = New-Object Drawing.Size 0, 0
  } else {
    $cPend.SetBounds($m, $cExp.Bottom + $m, $lw, 120)
    $cLog.SetBounds($m, $cPend.Bottom + $m, $lw, [Math]::Max(150, $H - $cPend.Bottom - $faycAlto - 3 * $m))
    $grp.SetBounds($m, $cLog.Bottom + $m, $lw, $faycAlto)
    $body.AutoScrollMinSize = New-Object Drawing.Size 0, ($grp.Bottom + $m)
  }
  $lst.SetBounds(14, 36, $cPend.Width - 28, $cPend.Height - 46)
  $log.SetBounds(14, 36, $cLog.Width - 28, $cLog.Height - 46)
  $body.ResumeLayout()
  $body.HorizontalScroll.Visible = $false; $body.HorizontalScroll.Maximum = 0
}
$form.Add_Resize({ Set-Acomodo }); $form.Add_Shown({ Set-Acomodo })

# ---------- datos ----------
function Fill-Recintos { $cur = $cmbRec.Text; $cmbRec.Items.Clear(); foreach ($r in $script:cfg.recintos) { [void]$cmbRec.Items.Add($r) }; $cmbRec.Text = $cur }
function Fill-Gastos { $cur = $cmbGas.Text; $cmbGas.Items.Clear(); foreach ($g in ($script:cfg.clientes.Values | ForEach-Object { $_.gastos } | Where-Object { $_ } | Select-Object -Unique | Sort-Object)) { [void]$cmbGas.Items.Add($g) }; $cmbGas.Text = $cur }
Fill-Recintos; Fill-Gastos
foreach ($n in (Get-CasaElaboroLista)) { [void]$cmbEla.Items.Add($n) }
$ela = (Get-CasaEquipoCfg).elaboro; if ($ela -and $cmbEla.Items.Contains($ela)) { $cmbEla.SelectedItem = $ela }
function Reset-Fayc { $chkRojo.Checked = $false; foreach ($c in $script:chkSi.Values) { $c.Checked = $false }; $cmbRec.Text = ''; $numRem.Value = 0 }

$script:pend = New-Object System.Collections.ArrayList   # rutas por guardar, en el orden en que CASA las pide
$script:dir = $null; $script:busy = $false; $script:cr = $null; $script:ped = $null; $script:op = 0
function Refresh-List {
  $lst.BeginUpdate(); $lst.Items.Clear()
  foreach ($r in $script:pend) { [void]$lst.Items.Add((Split-Path $r -Leaf)) }
  if (-not $script:pend.Count -and $script:dir) { [void]$lst.Items.Add('✔ No falta nada de CASA') }
  $lst.EndUpdate(); $cPend.Tag.Text = "Pendientes de CASA ($($script:pend.Count))"
}
function Set-Op([int]$op) {
  $script:op = $op
  switch ($op) { 1 { $lblOp.Text = 'IMPORTACIÓN'; $lblOp.BackColor = $Pal.Azul; $lblOp.Visible = $true } 2 { $lblOp.Text = 'EXPORTACIÓN'; $lblOp.BackColor = $Pal.Morado; $lblOp.Visible = $true } default { $lblOp.Visible = $false } }
  $lblCli.Left = if ($lblOp.Visible) { $lblOp.Right + 12 } else { 222 }
}
function Set-Cliente([string]$dir) {
  $cli = Get-CasaCliente $dir; $lblCli.Text = "Cliente: $(if ($cli) { $cli } else { '—' })"
  $g = if ($cli -and $script:cfg.clientes.ContainsKey($cli)) { $script:cfg.clientes[$cli].gastos } else { $null }
  $cmbGas.Text = if ($g) { $g } else { "$cli" }
  if (-not $g -and $cli) { Log "⚠ Primera vez con $cli`: revisa 'Gastos a terceros' (puse el nombre de la carpeta)." }
}

# ---------- trabajos en segundo plano ----------
$script:q = New-Object 'System.Collections.Concurrent.ConcurrentQueue[string]'
$script:bg = $null
function Set-Ocupado([bool]$si, [string]$que) {
  foreach ($b in $btnPrep, $btnAuto, $btnFin, $btnEq) { $b.Enabled = -not $si -and ($b -eq $btnPrep -or $b -eq $btnEq -or $script:dir) }
  $txtPed.Enabled = -not $si; $cmbDir.Enabled = -not $si
  $stProg.Visible = $si; $stStop.Visible = $si; $stStop.Enabled = $true; $stStop.Text = '⏹ Detener'; $stEstado.Text = if ($si) { "$que…" } else { 'Listo' }
}
# $codigo corre en otro hilo con casa-auto.ps1 cargado; usa $a (argumentos), Log y $out (resultados). $alTerminar corre en la ventana.
function Start-Trabajo([string]$que, [scriptblock]$codigo, [hashtable]$a, [scriptblock]$alTerminar) {
  if (-not $script:lic.Ok) { Log "⚠ Licencia: $($script:lic.Motivo)"; Show-Pestana 'Configuración'; return }
  if ($script:bg) { Log "⚠ Espera a que termine: $($script:bg.Que)"; return }
  $out = [hashtable]::Synchronized(@{})
  $rs = [runspacefactory]::CreateRunspace(); $rs.ApartmentState = 'STA'; $rs.Open()
  $ps = [powershell]::Create(); $ps.Runspace = $rs
  $script:alto.ya = $false
  $txt = 'param($root, $q, $out, $a, $alto)
$global:ColaApp = $q
$global:CasaAlto = $alto
. "$root\casa-auto.ps1"
function Log($m) { $global:ColaApp.Enqueue([string]$m) }
try {
' + $codigo.ToString() + '
} catch { $global:ColaApp.Enqueue("⚠ " + $_.Exception.Message); $out["error"] = $_.Exception.Message }'
  [void]$ps.AddScript($txt).AddArgument($PSScriptRoot).AddArgument($script:q).AddArgument($out).AddArgument($a).AddArgument($script:alto)
  $script:bg = @{ PS = $ps; RS = $rs; H = $ps.BeginInvoke(); Out = $out; Fin = $alTerminar; Que = $que }
  Set-Ocupado $true $que; $tBg.Start()
}
# "Detener": nunca a la mitad de un paso de CASA. Prende $script:alto.ya y el trabajo para en el siguiente punto seguro
# (Test-CasaAlto en casa-auto: entre grupos de CASA, antes de Preparar o de CASA), con las ventanas de CASA ya cerradas.
$script:alto = [hashtable]::Synchronized(@{ ya = $false })
function Stop-Trabajo([switch]$Preguntar) {
  $j = $script:bg; if (-not $j -or $j.Cancelado) { return }
  if ($Preguntar -and [Windows.Forms.MessageBox]::Show($form, "¿Detengo `"$($j.Que)`"?`n`nNo se corta a la mitad: Expedito termina el paso que CASA está haciendo, cierra sus ventanas y se detiene ahí. Lo que no alcanzó a empezar queda sin hacer.", 'Detener', 'YesNo', 'Question') -ne 'Yes') { return }
  $j.Cancelado = $true; $script:alto.ya = $true; $script:ctl.stop = $true; $script:ctlTab.stop = $true
  $stStop.Enabled = $false; $stStop.Text = '⏳ Deteniendo en punto seguro…'; Log "⏹ Deteniendo $($j.Que): espera a que CASA termine el paso actual."
}
$tBg = New-Object Windows.Forms.Timer -Property @{ Interval = 300 }
function Write-Cola($m) { if ($m.StartsWith('@@ESTADO|')) { $stEstado.Text = $m.Substring(9) } elseif ($m.StartsWith('@@|')) { & $script:onFila $m } elseif ($m.StartsWith('@@TF|')) { $p = $m.Split('|', 3); if ($p.Count -eq 3) { Complete-TableroPed $p[1] $p[2] '' } } elseif ($m.StartsWith('@@T|')) { $p = $m.Split('|', 4); if ($p.Count -eq 4) { Set-TableroFila $p[1] $p[2] $p[3] } } elseif ($m.StartsWith('@@F|')) { $p = $m.Split('|', 4); if ($p.Count -eq 4) { Set-FilaFayc $p[1] $p[2] $p[3] } } else { Log $m } }
$script:onFila = { }
$tBg.Add_Tick({
  $m = $null; while ($script:q.TryDequeue([ref]$m)) { Write-Cola $m }
  if ($script:bg -and $script:bg.H.IsCompleted) {
    $j = $script:bg; $script:bg = $null; $tBg.Stop()
    if (-not $j.Cancelado) { try { foreach ($e in $j.PS.Streams.Error) { Log "⚠ $e" } } catch {} }
    $j.PS.Dispose(); $j.RS.Close()
    $m = $null; while ($script:q.TryDequeue([ref]$m)) { Write-Cola $m }
    if ($j.Cancelado) {   # renglones del lote que no terminaron; y pendientes del tablero que quedaron sin resultado
      foreach ($row in @($grid.Rows)) { $e = "$($row.Cells['est'].Value)"; if ($e -and $e -notmatch '^(Completo|Listo para FAYC|Revisar|Error|Sin carpeta|Varias carpetas|No iniciado|Detenido|En cola|Quitado)') {
        $p = "$($row.Cells['ped'].Value)"; Set-Fila $p 'est' $(if ($e -eq 'En espera') { 'No iniciado (detenido)' } else { 'Detenido' }); Set-Fila $p 'av' '100' } }
      foreach ($p in @($script:tabPend.Keys)) { Complete-TableroPed $p 'Detenido' 'Lo detuvo el usuario' }
    }
    Set-Ocupado $false
    try { & $j.Fin $j.Out } catch { Log "⚠ $($_.Exception.Message)" }
    Set-Ocupado $false
  }
})

# Al cambiar el pedimento se vuelve a buscar la carpeta.
$txtPed.Add_TextChanged({ $cmbDir.Items.Clear(); $script:dir = $null; $lblCli.Text = 'Cliente: —'; Set-Op 0; $btnAuto.Enabled = $false; $btnFin.Enabled = $false; $btnVig.Enabled = $false; $btnSkip.Enabled = $false })
$cmbDir.Add_SelectedIndexChanged({ if ($cmbDir.SelectedItem) { $script:dir = Join-Path $CasaRoot $cmbDir.SelectedItem; Set-Cliente $script:dir } })

# ---------- 1. Preparar ----------
$btnPrep.Add_Click({
  $ped = $txtPed.Text.Trim(); if ($ped -notmatch '^\d{7}$') { Log '⚠ Pedimento inválido (7 dígitos, p. ej. 6108012)'; return }
  if ($cmbDir.Items.Count -eq 0) {
    $c = @(Get-CasaCarpetas $ped)
    if (-not $c.Count) { Log "⚠ No hay carpeta con $ped en ningún cliente de $CasaRoot"; return }
    foreach ($d in $c) { [void]$cmbDir.Items.Add($d.Substring($CasaRoot.Length + 1)) }
    if ($c.Count -gt 1) { Log "⚠ Hay $($c.Count) carpetas con $ped (en distintos clientes). Elige la correcta en 'Carpeta' y vuelve a dar 1. Preparar."; $cmbDir.DroppedDown = $true; return }
    $cmbDir.SelectedIndex = 0
  }
  if (-not $script:dir) { Log 'Elige la carpeta y vuelve a dar 1. Preparar'; return }
  if ($script:ped -ne $ped) { Reset-Fayc; $script:ped = $ped }
  Start-Trabajo 'Preparando expediente' {
    $r = Invoke-CasaPreparar -Pedimento $a.ped -Dir $a.dir -Log { param($m) $global:ColaApp.Enqueue([string]$m) } -Etiqueta $a.rel
    $out.fecha = $r.Fecha; $out.cr = $r.CR; $out.op = $r.Op; $out.remesas = $r.Remesas; $out.ok = $r.Ok
  } @{ ped = $ped; dir = $script:dir; rel = "$($cmbDir.SelectedItem)" } {
    param($o)
    if (-not $o.ok) { return }
    $ref = Get-CasaRef $script:ped
    if ($o.fecha) { $dtPago.Value = $o.fecha }
    $script:cr = $o.cr
    if ($o.cr) { $r = $script:cfg.cr[$o.cr]; if ($r) { $cmbRec.Text = $r; Log "CR $($o.cr) → $r" } else { Log "⚠ CR $($o.cr) sin recinto guardado: elígelo en la lista o escríbelo" } } elseif (-not $cmbRec.Text) { Log '⚠ Elige o escribe el recinto fiscal' }
    Set-Op ([int]$o.op)
    Log $(switch ($script:op) { 2 { 'Operación: EXPORTACIÓN (2.ª copia EXP_, sin manifestación)' } 1 { 'Operación: IMPORTACIÓN' } default { '⚠ No sé si es impo o expo (falta el archivo M); CASA automático lo revisará en el Catálogo' } })
    $numRem.Value = [int]$o.remesas
    # PDFs que faltan, en el orden normal de trabajo en CASA
    $script:pend.Clear()
    $orden = @(Get-CasaPrefijos $script:op | ForEach-Object { "$_$ref.pdf" }) + "SIMP_$ref.pdf"
    $n = (Get-ChildItem -LiteralPath $script:dir -File).Name
    if (-not ($n -match '^COVE[0-9A-Z]{9}\.pdf$')) { $orden += 'COVE (todos los de las facturas)' }
    if (-not ($n -match '^Reporte_ACUSE_COVE')) { $orden += 'Reporte_ACUSE_COVE (uno por factura)' }
    if ($script:op -ne 2) { $orden += "AMV_$ref.pdf", "MV_$ref.pdf" }
    $pag = $orden[0..3]; $faltaPag = @($pag | Where-Object { -not (Test-Path -LiteralPath "$($script:dir)\$_") }).Count -gt 0
    foreach ($x in $orden) { if (($faltaPag -and $pag -contains $x) -or -not (Test-Path -LiteralPath "$($script:dir)\$x")) { [void]$script:pend.Add("$($script:dir)\$x") } }
    Refresh-List
    Log $(if ($script:pend.Count) { "Faltan $($script:pend.Count) PDF. Siguiente: 2. CASA automático." } else { '✔ Ya están todos los PDF de CASA. Revisa el panel FAYC y da 3. FAYC + ZIP.' })
    $btnVig.Enabled = $true; $btnSkip.Enabled = $true
  }
})

# ---------- 2. CASA automático ----------
$btnAuto.Add_Click({
  if ($timer.Enabled) { $timer.Stop(); $btnVig.Text = 'Vigilar (manual)' }
  $ped = $txtPed.Text.Trim(); if ($ped -ne $script:ped -or -not $script:dir) { Log 'Primero 1. Preparar'; return }
  Log 'CASA automático: no uses CASA hasta que termine (puedes seguir trabajando en la otra pantalla).'
  Start-Trabajo 'CASA automático trabajando' {
    $res = Invoke-CasaAuto -Pedimento $a.ped -Dir $a.dir -Log { param($m) $global:ColaApp.Enqueue([string]$m) }
    if ($res) { foreach ($k in $res.Keys) { $out[$k] = $res[$k] } }
  } @{ ped = $ped; dir = $script:dir } {
    param($o)
    foreach ($k in 'Pagado', 'Simp', 'Cove', 'MV') { if ($o[$k]) { Log "Resultado $k`: $($o[$k])" } }
    # si al preparar no se sabía la operación, CASA ya la dijo (guardó EXP_): la expo no lleva IMP_ ni manifestación
    if ($script:op -ne 2 -and (Get-CasaOp $script:ped $script:dir) -eq 2) {
      Set-Op 2; Log 'Operación: EXPORTACIÓN (sin IMP_ ni manifestación)'
      foreach ($r in @($script:pend)) { if ((Split-Path $r -Leaf) -match '^(IMP_|A?MV_)') { [void]$script:pend.Remove($r) } } }
    foreach ($r in @($script:pend)) {
      $leaf = Split-Path $r -Leaf
      if ((Test-Path -LiteralPath $r) -or ($o['Cove'] -eq 'OK' -and $leaf -match '^(Reporte_ACUSE_)?COVE') -or ($o['MV'] -eq 'OK' -and $leaf -match '^A?MV_')) { [void]$script:pend.Remove($r) } }
    Refresh-List
    Log $(if ($script:pend.Count) { "⚠ Terminó CASA. Siguen pendientes $($script:pend.Count) (revisa el registro; puedes usar Vigilar (manual) o Saltar)." } else { 'Terminó CASA: ya están todos los PDF. Revisa el panel FAYC y da 3. FAYC + ZIP.' })
  }
})

# ---------- modo manual ----------
$timer = New-Object Windows.Forms.Timer -Property @{ Interval = 1000 }
$timer.Add_Tick({
  if ($script:busy -or $script:pend.Count -eq 0) { return }
  $dlg = Find-CasaDialogo; if (-not $dlg) { return }
  $script:busy = $true
  try {
    Start-Sleep -Milliseconds 1500
    $r = $script:pend[0]
    $res = Set-CasaDialogo $dlg $r
    if ($res -eq 'existe') { Log "Ya existía $(Split-Path $r -Leaf): cancelé esa ventana"; $script:pend.RemoveAt(0); Refresh-List }
    elseif ($res -eq 'ok') {
      $f = $script:ultimo
      for ($i = 0; $i -lt 30 -and -not (Test-Path -LiteralPath $f); $i++) { Start-Sleep -Milliseconds 500; [Windows.Forms.Application]::DoEvents() }
      if (Test-Path -LiteralPath $f) { Log "Guardado: $(Split-Path $f -Leaf)"
        if ((Split-Path $r -Leaf) -like 'Reporte_ACUSE_COVE (*') { Log 'Si hay más facturas, imprime el siguiente acuse; cuando acabes da Saltar.' } else { $script:pend.RemoveAt(0); Refresh-List } }
      else { Log "⚠ No se creó $(Split-Path $f -Leaf); revisa la ventana de CASA" }
    } else { $timer.Stop(); $btnVig.Text = 'Vigilar (manual)'; Log '⚠ No pude llenar la ventana de guardar; vigilancia detenida, hazlo a mano' }
  } finally { $script:busy = $false }
})
$btnVig.Add_Click({ if (-not $script:lic.Ok) { Show-Pestana 'Configuración'; return }; if ($timer.Enabled) { $timer.Stop(); $btnVig.Text = 'Vigilar (manual)'; $stEstado.Text = 'Listo'; Log 'Vigilancia detenida' } else { $timer.Start(); $btnVig.Text = 'Detener'; $stEstado.Text = 'Vigilando CASA (modo manual)…'; Log 'Vigilando: ahora da los clics en CASA' } })
$btnSkip.Add_Click({ if ($script:pend.Count) { Log "Saltado: $(Split-Path $script:pend[0] -Leaf)"; $script:pend.RemoveAt(0); Refresh-List } })

# ---------- Revisar equipo ----------
function Show-Equipo {
  Start-Trabajo 'Revisando el equipo' { $out.r = @(Test-CasaEquipo) } @{} {
    param($o)
    Log '--- Revisión del equipo'
    foreach ($x in $o.r) { Log ("{0} {1}: {2}" -f $(switch ($x.Estado) { 'OK' { '✔' } 'FALTA' { '⚠ ✖' } default { '⚠' } }), $x.Que, $x.Detalle) }
    $f = @($o.r | Where-Object Estado -eq 'FALTA')
    if ($f.Count) { [void][Windows.Forms.MessageBox]::Show($form, "A esta PC le falta:`n`n" + (($f | ForEach-Object { "• $($_.Que): $($_.Detalle)" }) -join "`n"), 'Revisar equipo', 'OK', 'Warning') }
    else { Log 'Equipo listo para usar la app.' }
  }
}
$btnEq.Add_Click({ Show-Equipo })
if (-not $CasaRoot -or -not $CasaPlantilla) { $form.Add_Shown({ Show-Equipo }) }

# ---------- 3. FAYC + ZIP ----------
$btnFin.Add_Click({
  $timer.Stop(); $btnVig.Text = 'Vigilar (manual)'
  $ped = $txtPed.Text.Trim(); if ($ped -ne $script:ped -or -not $script:dir) { Log 'Primero 1. Preparar'; return }
  $rec = $cmbRec.Text.Trim(); $gas = $cmbGas.Text.Trim()
  if (-not $rec) { Log '⚠ Falta el recinto fiscal'; return }
  if (-not $gas) { Log "⚠ Falta 'Gastos a terceros'"; return }
  $si = @($script:chkSi.Keys | Where-Object { $script:chkSi[$_].Checked })
  $rojo = if ($chkRojo.Checked) { 'SI' } else { 'NO' }
  $elab = "$($cmbEla.SelectedItem)"; if (-not $elab) { Log '⚠ Elige quién elaboró'; return }
  $msg = "Pedimento $ped`nElaboró: $elab`nRecinto: $rec`nFecha de pago: $($dtPago.Value.ToString('d MMM yyyy'))`nGastos a terceros: $gas`nRemesas: $($numRem.Value)`nROJO: $rojo`nEn SI: $(if ($si) { $si -join ', ' } else { 'ninguno' })`n`n¿Genero la FAYC y el ZIP?"
  if ([Windows.Forms.MessageBox]::Show($form, $msg, 'Confirmar FAYC', 'YesNo', 'Question') -ne 'Yes') { Log 'FAYC cancelada'; return }
  $a = @{ ped = $ped; dir = $script:dir; fecha = $dtPago.Value.Date; rec = $rec; rem = [int]$numRem.Value; rojo = $rojo; gas = $gas; si = $si; elab = $elab }
  Start-Trabajo 'Generando FAYC y ZIP' {
    Log (New-CasaFayc -Pedimento $a.ped -FechaPago $a.fecha -Recinto $a.rec -Remesas $a.rem -Rojo $a.rojo -GastosTerceros $a.gas -Si $a.si -Dir $a.dir -Elaboro $a.elab)
    Log (New-CasaZip -Pedimento $a.ped -Dir $a.dir)
    $f = (Start-CasaExpediente -Pedimento $a.ped -Dir $a.dir -SoloRevisar).Faltan
    Log $(if ($f) { "⚠ Falta todavía: $f" } else { '✔ Expediente completo' })
    $out.ok = $true; $out.rec = $a.rec; $out.gas = $a.gas; $out.elab = $a.elab
  } $a {
    param($o)
    if (-not $o.ok) { return }
    $rec = $o.rec; $gas = $o.gas; $elab = $o.elab
    # recordar recinto, CR, nombre de facturación del cliente y quién elaboró en esta PC
    if ($script:cfg.recintos -notcontains $rec) { $script:cfg.recintos = @($script:cfg.recintos) + $rec }
    if ($script:cr -and -not $script:cfg.cr[$script:cr]) { $script:cfg.cr[$script:cr] = $rec }
    $cli = Get-CasaCliente $script:dir; if ($cli) { $script:cfg.clientes[$cli] = @{ gastos = $gas } }
    if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }; $script:cfg.equipos[$CasaEquipo]['elaboro'] = $elab
    Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig; Fill-Recintos; Fill-Gastos
  }
})


# ---------- Varios pedimentos (lote): Preparar + CASA automático uno tras otro ----------
$script:ctl = [hashtable]::Synchronized(@{ stop = $false })
$script:filas = @{}   # pedimento -> renglón del grid
$lf = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Fill'; BackColor = $Pal.Fondo; Visible = $false; Padding = '12,12,12,12' })
$lTop = Add-Ctl (New-Card 'Pega o escribe los pedimentos (uno por renglón, o separados por espacio o coma)') $lf
$lTop.Dock = 'Top'; $lTop.Height = 214
$lEsp = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 12; BackColor = $Pal.Fondo }) $lf
$lTop.SendToBack()   # tarjeta arriba, luego el espacio, luego la tabla
$txtLote = Add-Ctl (New-Object Windows.Forms.TextBox -Property @{ Multiline = $true; AcceptsReturn = $true; ScrollBars = 'Vertical'; Font = $F.Neg; Location = '14,36'; Size = '360,164' }) $lTop
$chkLoteCasa = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = 'Hacer también CASA automático'; Checked = $true; AutoSize = $true; Location = '392,38'; ForeColor = $Pal.Texto }) $lTop
New-Lbl 'Trabajar en:' '392,70' $lTop
$rbLocal = Add-Ctl (New-Object Windows.Forms.RadioButton -Property @{ Text = 'Esta PC'; Location = '474,67'; AutoSize = $true; Checked = $true; Font = $F.Neg; ForeColor = $Pal.Texto }) $lTop
$rbRem = Add-Ctl (New-Object Windows.Forms.RadioButton -Property @{ Text = 'El remoto'; Location = '560,67'; AutoSize = $true; Font = $F.Neg; ForeColor = $Pal.Texto }) $lTop
$lblRem = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '660,70'; AutoSize = $true; ForeColor = $Pal.Gris }) $lTop
$btnLoteIr = Add-Ctl (New-Btn 'Trabajar lote' $Pal.Verde) $lTop; $btnLoteIr.SetBounds(392, 96, 190, 36)
$btnLoteStop = Add-Ctl (New-Btn 'Detener después del actual' $Pal.Rojo -Contorno) $lTop; $btnLoteStop.SetBounds(590, 96, 230, 36); $btnLoteStop.Enabled = $false
$btnLoteFayc = Add-Ctl (New-Btn 'FAYC del lote' $Pal.Naranja) $lTop; $btnLoteFayc.SetBounds(828, 96, 170, 36)
$btnLoteFayc.Add_Click({ if ($script:bg) { [void][Windows.Forms.MessageBox]::Show($form, "Espera a que termine: $($script:bg.Que)", 'FAYC del lote'); return }; Show-FaycLote })
$lblLote = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Al terminar, doble clic en un renglón para revisar su FAYC en la pestaña Expediente.'; AutoSize = $true; Location = '392,142'; ForeColor = $Pal.Gris }) $lTop
$chkSoy = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = 'Esta PC es el remoto: trabaja los pedimentos que manden las demás'; AutoSize = $true; Location = '392,174'; ForeColor = $Pal.Morado; Font = $F.Neg }) $lTop
$grid = Add-Ctl (New-Object Windows.Forms.DataGridView -Property @{ Dock = 'Fill'; ReadOnly = $true; AllowUserToAddRows = $false; AllowUserToDeleteRows = $false; RowHeadersVisible = $false
  SelectionMode = 'FullRowSelect'; MultiSelect = $false; BackgroundColor = [Drawing.Color]::White; BorderStyle = 'None'; AutoSizeColumnsMode = 'Fill'; EnableHeadersVisualStyles = $false
  ColumnHeadersHeight = 32; ColumnHeadersHeightSizeMode = 'DisableResizing'; GridColor = $Pal.Linea; CellBorderStyle = 'SingleHorizontal' }) $lf
$grid.BringToFront()
$grid.ColumnHeadersDefaultCellStyle.BackColor = $Pal.Head; $grid.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White; $grid.ColumnHeadersDefaultCellStyle.Font = $F.Neg
$grid.DefaultCellStyle.SelectionBackColor = Hex '#DBEAFE'; $grid.DefaultCellStyle.SelectionForeColor = $Pal.Texto; $grid.RowTemplate.Height = 28
foreach ($col in @(@('ped', 'Pedimento', 70), @('cli', 'Cliente', 110), @('op', 'Op.', 45), @('est', 'Estado', 120), @('av', 'Avance', 95), @('fal', 'Falta', 150), @('res', 'Resultado', 190), @('datos', 'datos', 1))) {
  $i = $grid.Columns.Add($col[0], $col[1]); $grid.Columns[$i].FillWeight = $col[2]; $grid.Columns[$i].SortMode = 'NotSortable' }
$grid.Columns['ped'].DefaultCellStyle.Font = $F.Neg; $grid.Columns['datos'].Visible = $false
function Get-ColorEst([string]$val) { switch -Wildcard ($val) { 'Listo*' { $Pal.Verde } 'Completo*' { $Pal.Verde } 'Revisar*' { $Pal.Naranja } 'Error*' { $Pal.Rojo } 'Sin carpeta*' { $Pal.Rojo } 'Varias*' { $Pal.Naranja } 'En espera*' { $Pal.Gris } 'En cola*' { $Pal.Gris } 'Quitado*' { $Pal.Gris } 'No iniciado*' { $Pal.Gris } default { $Pal.Azul } } }
function Set-Fila([string]$ped, [string]$col, [string]$val) {
  $r = $script:filas[$ped]
  if ($null -eq $r) { $r = $grid.Rows.Add($ped, '', '', '', '0', '', '', ''); $script:filas[$ped] = $r }
  $grid.Rows[$r].Cells[$col].Value = $val
  if ($col -eq 'est') { $grid.Rows[$r].Cells['est'].Style.ForeColor = Get-ColorEst $val; $grid.Rows[$r].Cells['est'].Style.Font = $F.Neg; $grid.InvalidateCell($grid.Columns['av'].Index, $r) }
  if ($script:tabIds -and $script:tabIds.Contains($ped)) { Send-TableroFila $ped $col $val }   # vino del tablero: el avance también va allá
}
# avance: barra con el porcentaje
$grid.Add_CellPainting({ param($s, $e)
  if ($e.RowIndex -lt 0 -or $e.ColumnIndex -ne $grid.Columns['av'].Index) { return }
  $e.PaintBackground($e.CellBounds, $true)
  $v = 0; [void][int]::TryParse("$($e.Value)", [ref]$v); $v = [Math]::Max(0, [Math]::Min(100, $v))
  $b = $e.CellBounds; $bar = New-Object Drawing.Rectangle ($b.X + 6), ($b.Y + 8), ([Math]::Max(10, $b.Width - 50)), ($b.Height - 16)
  $g = $e.Graphics; $fondo = New-Object Drawing.SolidBrush $Pal.Linea; $g.FillRectangle($fondo, $bar); $fondo.Dispose()
  $est = "$($grid.Rows[$e.RowIndex].Cells['est'].Value)"
  $col = if ($v -ge 100) { Get-ColorEst $est } elseif ($est -like 'En cola*' -or $est -like 'En espera*') { $Pal.Apagado } else { $Pal.Azul }
  if ($v -gt 0) { $lleno = New-Object Drawing.SolidBrush $col; $g.FillRectangle($lleno, $bar.X, $bar.Y, [int]($bar.Width * $v / 100), $bar.Height); $lleno.Dispose() }
  [Windows.Forms.TextRenderer]::DrawText($g, "$v %", $F.Neg, (New-Object Drawing.Point ($bar.Right + 6), ($b.Y + 6)), $Pal.Texto)
  $e.Handled = $true })
# mensajes del trabajo "@@|pedimento|columna|valor" actualizan la tabla
$script:onFila = { param($m) $p = $m.Split('|', 4); if ($p.Count -eq 4) { if ($script:bg -and $script:bg.Que -like 'Remoto*') { $script:remActual = $p[1] }; Set-Fila $p[1] $p[2] $p[3] } }

$btnLoteIr.Add_Click({
  $peds = @([regex]::Matches($txtLote.Text, '\b\d{7}\b') | ForEach-Object { $_.Value } | Select-Object -Unique)
  if (-not $peds.Count) { [void][Windows.Forms.MessageBox]::Show($form, 'No encontré pedimentos (7 dígitos).', 'Varios pedimentos'); return }
  if ($rbRem.Checked) {
    $r = Get-CasaRemoto
    $aviso = if (-not $r -or -not $r.activo) { 'Ninguna PC está como remoto ahora.' } elseif ($r.Hace -gt 180) { "El remoto $($r.pc) no da señal desde hace $([int]($r.Hace / 60)) min." } else { $null }
    if ($aviso -and [Windows.Forms.MessageBox]::Show($form, "$aviso`n`n¿Los dejo en la cola para cuando el remoto esté trabajando?", 'Mandar al remoto', 'YesNo', 'Question') -ne 'Yes') { return }
    foreach ($x in @(Send-CasaCola $peds $chkLoteCasa.Checked)) { $script:remSeg[$x.Ped] = $x.Id; foreach ($c in 'res', 'fal') { Set-Fila $x.Ped $c '' }; Set-Fila $x.Ped 'av' '0'; Set-Fila $x.Ped 'est' 'En cola' }
    Log "== Mandé al remoto $($peds.Count) pedimento(s): $($peds -join ', ')"; $txtLote.Clear(); Update-Remotos; return
  }
  if ($script:bg) { [void][Windows.Forms.MessageBox]::Show($form, "Espera a que termine: $($script:bg.Que)", 'Varios pedimentos'); return }
  $grid.Rows.Clear(); $script:filas = @{}; $script:remSeg.Clear()
  foreach ($p in $peds) { Set-Fila $p 'est' 'En espera' }
  $script:ctl.stop = $false; $btnLoteIr.Enabled = $false; $btnLoteStop.Enabled = $true; $script:loteCorre = $true
  Log "== Lote de $($peds.Count) pedimentos: $($peds -join ', ')"
  Start-Trabajo "Lote de $($peds.Count) pedimentos" {
    $n = 0
    foreach ($pp in $a.peds) {
      $n++
      if ($a.ctl.stop) { $global:ColaApp.Enqueue("@@|$pp|est|No iniciado (detenido)"); continue }
      $global:ColaApp.Enqueue("@@ESTADO|Lote: $n de $($a.peds.Count) ($pp)")
      $lg = { param($m) $global:ColaApp.Enqueue("[$pp] $m") }.GetNewClosure()
      $fi = { param($c, $v) $global:ColaApp.Enqueue("@@|$pp|$c|$v") }.GetNewClosure()
      $x = Invoke-CasaPedimento -Pedimento $pp -Casa:$a.casa -Log $lg -Fila $fi
      if ($x.Parar) { $a.ctl.stop = $true; $global:ColaApp.Enqueue('⚠ Lote detenido: CASA necesita atención') }
    }
    $out.ok = $true
  } @{ peds = $peds; casa = $chkLoteCasa.Checked; ctl = $script:ctl } {
    param($o)
    $script:loteCorre = $false
    $btnLoteIr.Enabled = $true; $btnLoteStop.Enabled = $false
    $ok = @($grid.Rows | Where-Object { "$($_.Cells['est'].Value)" -like 'Listo*' }).Count; $comp = @($grid.Rows | Where-Object { "$($_.Cells['est'].Value)" -eq 'Completo' }).Count
    Log "== Lote terminado: $ok listos para FAYC, $comp completos, de $($grid.Rows.Count). Doble clic en cada renglón para revisar su FAYC."
    $lblLote.Text = "Terminado: $ok listos para FAYC y $comp completos de $($grid.Rows.Count). Doble clic en un renglón para revisar su FAYC."
  }
  if (-not $script:bg) { $btnLoteIr.Enabled = $true; $btnLoteStop.Enabled = $false; $script:loteCorre = $false }
})
$btnLoteStop.Add_Click({
  if (-not $rbRem.Checked) { $script:ctl.stop = $true; $btnLoteStop.Enabled = $false; Log '⚠ El lote se detendrá al terminar el pedimento actual'; return }
  $mios = @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'pendientes') -Filter "*_$CasaEquipo.json" -File -ErrorAction SilentlyContinue)
  if (-not $mios.Count) { [void][Windows.Forms.MessageBox]::Show($form, 'No tienes pedimentos esperando en la cola (los que el remoto ya empezó no se pueden quitar).', 'Quitar de la cola'); return }
  $lista = ($mios | ForEach-Object { ($_.BaseName -split '_')[1] }) -join ', '
  if ([Windows.Forms.MessageBox]::Show($form, "¿Quito de la cola $($mios.Count) pedimento(s) que el remoto todavía no empieza?`n`n$lista", 'Quitar de la cola', 'YesNo', 'Question') -ne 'Yes') { return }
  foreach ($f in $mios) { $p = ($f.BaseName -split '_')[1]; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue; $script:remSeg.Remove($p); Set-Fila $p 'av' '0'; Set-Fila $p 'est' 'Quitado de la cola' }
  Log "Quité de la cola: $lista"
})

# ---------- remoto (opcional) ----------
# En la PC remoto: marca "Esta PC es el remoto" y deja CASA abierto. Las demás eligen "Trabajar en: El remoto".
$script:remSeg = @{}            # pedimento -> id de la solicitud que mandó esta PC
$script:ctlRem = [hashtable]::Synchronized(@{ stop = $false })
$script:remPausa = Get-Date; $script:remActual = ''; $script:remTick = 0; $script:iniRem = $false; $script:loteCorre = $false
function Save-EquipoDato([string]$k, $v) { if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }; $script:cfg.equipos[$CasaEquipo][$k] = $v; Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig }
function Write-Latido([bool]$activo = $true) {
  $n = @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'pendientes') -Filter *.json -File -ErrorAction SilentlyContinue).Count
  $e = if (-not $activo) { 'apagado' } elseif ($script:remPausa -gt (Get-Date)) { 'en pausa (CASA necesita atención)' } elseif ($script:bg) { if ($script:bg.Que -like 'Remoto*') { "trabajando $($script:remActual)" } else { 'ocupado' } } else { 'libre' }
  Write-CasaJson "$CasaCola\remoto.json" ([ordered]@{ pc = $CasaEquipo; activo = $activo; est = $e; cola = $n; utc = (Get-Date).ToUniversalTime().ToString('o') })
}
function Update-RemotoLbl {
  if ($chkSoy.Checked) { $lblRem.Text = 'Esta PC es el remoto'; $lblRem.ForeColor = $Pal.Morado; return }
  $r = Get-CasaRemoto
  if (-not $r -or -not $r.activo) { $lblRem.Text = 'Ninguna PC está como remoto'; $lblRem.ForeColor = $Pal.Rojo }
  elseif ($r.Hace -gt 180) { $lblRem.Text = "Remoto $($r.pc): sin señal desde hace $([int]($r.Hace / 60)) min"; $lblRem.ForeColor = $Pal.Rojo }
  else { $lblRem.Text = "Remoto $($r.pc): $($r.est)$(if ($r.cola) { " · $($r.cola) en cola" })"; $lblRem.ForeColor = $Pal.Verde }
}
# avance de lo que mandó esta PC (lo escribe el remoto en cola\estado\<pedimento>.json)
function Update-Remotos {
  if (-not $script:remSeg.Count) { return }
  $pend = @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'pendientes') -Filter *.json -File -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object Name)
  foreach ($p in @($script:remSeg.Keys)) {
    $id = $script:remSeg[$p]; $e = Read-CasaJson "$CasaCola\estado\$p.json"
    if ($e -and $e.id -eq $id) { foreach ($c in 'cli', 'op', 'fal', 'res', 'av', 'datos') { if ($null -ne $e.$c) { Set-Fila $p $c "$($e.$c)" } }; Set-Fila $p 'est' "$($e.est)"; continue }
    $k = [array]::IndexOf($pend, $id)
    if ($k -ge 0) { Set-Fila $p 'est' "En cola ($($k + 1) de $($pend.Count))" }
    elseif (Test-Path -LiteralPath "$CasaCola\trabajando\$id") { Set-Fila $p 'est' 'Empezando en el remoto' }
  }
}
# al elegir "El remoto": volver a mostrar lo que esta PC mandó (de los últimos 2 días)
function Show-MisRemotos {
  foreach ($f in @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'pendientes') -Filter "*_$CasaEquipo.json" -File -ErrorAction SilentlyContinue)) { $p = ($f.BaseName -split '_')[1]; if (-not $script:remSeg.ContainsKey($p)) { $script:remSeg[$p] = $f.Name; Set-Fila $p 'est' 'En cola' } }
  foreach ($f in @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'estado') -Filter *.json -File -ErrorAction SilentlyContinue | Where-Object LastWriteTime -gt (Get-Date).AddDays(-2) | Sort-Object LastWriteTime)) {
    $e = Read-CasaJson $f.FullName; if ($e -and $e.de -eq $CasaEquipo -and -not $script:remSeg.ContainsKey("$($e.ped)")) { $script:remSeg["$($e.ped)"] = $e.id } }
  Update-Remotos
}
function Set-ModoLote {
  $r = $rbRem.Checked
  $btnLoteIr.Text = if ($r) { 'Mandar al remoto' } else { 'Trabajar lote' }
  $btnLoteStop.Text = if ($r) { 'Quitar los que siguen en cola' } else { 'Detener después del actual' }
  $btnLoteStop.Enabled = $r -or $script:loteCorre; $btnLoteIr.Enabled = $r -or -not $script:loteCorre
  $lblLote.Text = if ($r) { 'Se trabajan en el remoto; aquí ves el avance. Al terminar, doble clic en un renglón para su FAYC.' } else { 'Al terminar, doble clic en un renglón para revisar su FAYC en la pestaña Expediente.' }
  if ($r) { Show-MisRemotos }
  Update-RemotoLbl
}
$rbRem.Add_CheckedChanged({ Set-ModoLote; if (-not $script:iniRem) { Save-EquipoDato 'lote' $(if ($rbRem.Checked) { 'remoto' } else { 'local' }) } })
function Start-Remoto {
  $script:ctlRem.stop = $false
  Start-Trabajo 'Remoto: trabajando la cola' {
    $lgA = { param($m) $global:ColaApp.Enqueue([string]$m) }
    $r = Invoke-CasaColaRemoto -Ctl $a.ctl -Log $lgA -Ui $lgA
    $out.hechos = $r.Hechos; $out.parar = $r.Parar
  } @{ ctl = $script:ctlRem } {
    param($o)
    if ($o.parar) { $script:remPausa = (Get-Date).AddMinutes(5); Log '⚠ Remoto en pausa 5 minutos: revisa CASA en esta PC.' }
    Log "== Remoto: terminé $([int]$o.hechos) pedimento(s) de la cola"; $script:remActual = ''
    if ($chkSoy.Checked) { Write-Latido }
  }
}
$chkSoy.Add_CheckedChanged({
  if ($chkSoy.Checked) {
    $r = Get-CasaRemoto
    if (-not $script:iniRem -and $r -and $r.activo -and $r.pc -ne $CasaEquipo -and $r.Hace -lt 180) {
      if ([Windows.Forms.MessageBox]::Show($form, "La PC $($r.pc) ya está como remoto. ¿Que esta PC lo sea en su lugar?`n`n(Solo debe haber un remoto.)", 'Remoto', 'YesNo', 'Question') -ne 'Yes') { $chkSoy.Checked = $false; return } }
    # lo que quedó a medias (se cerró la app del remoto) vuelve a la cola
    foreach ($f in @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'trabajando') -Filter *.json -File -ErrorAction SilentlyContinue)) { Move-Item -LiteralPath $f.FullName -Destination (Get-CasaColaDir 'pendientes') -Force -ErrorAction SilentlyContinue }
    $rbLocal.Checked = $true; $rbRem.Enabled = $false; $script:remPausa = Get-Date
    Write-Latido; Log '== Esta PC es el remoto: trabajará los pedimentos que manden las demás. Deja CASA abierto y sin usar.'
  } else {
    $script:ctlRem.stop = $true; $rbRem.Enabled = $true
    $r = Get-CasaRemoto; if ($r -and $r.pc -eq $CasaEquipo) { Write-Latido $false }
    if (-not $script:iniRem) { Log 'Esta PC dejó de ser el remoto (si estaba trabajando, termina el pedimento actual).' }
  }
  Update-RemotoLbl
  if (-not $script:iniRem) { Save-EquipoDato 'remoto' $chkSoy.Checked }
})
$tRem = New-Object Windows.Forms.Timer -Property @{ Interval = 4000 }
$tRem.Add_Tick({
  $script:remTick++
  try {
    if ($chkSoy.Checked) {
      if ($script:remTick % 8 -eq 1) { Write-Latido }
      if (-not $script:bg -and (Get-Date) -ge $script:remPausa -and @(Get-ChildItem -LiteralPath (Get-CasaColaDir 'pendientes') -Filter *.json -File -ErrorAction SilentlyContinue).Count) { Start-Remoto; Write-Latido }
    } elseif (($rbRem.Checked -or $script:remSeg.Count) -and $script:remTick % 2 -eq 0) { Update-RemotoLbl; Update-Remotos }
  } catch {}
})
$form.Add_FormClosing({ if ($chkSoy.Checked) { try { Write-Latido $false } catch {} } })
# doble clic: cargar el pedimento en la ventana principal para revisar su FAYC
$grid.Add_CellDoubleClick({ param($s, $e)
  if ($e.RowIndex -lt 0 -or $script:bg) { return }
  $p = "$($grid.Rows[$e.RowIndex].Cells['ped'].Value)"
  $txtPed.Text = $p; Show-Pestana 'Expediente'; $btnPrep.PerformClick()
})


# ---------- FAYC del lote: revisar en una tabla y generar todas las FAYC + ZIP seguidas ----------
# ROJO siempre se pregunta: viene vacío y no se genera ningún renglón marcado sin SI/NO.
$lFay = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Bottom'; Height = 360; BackColor = $Pal.Fondo; Padding = '0,12,0,0'; Visible = $false }) $lf
$grid.BringToFront()
$cFay = Add-Ctl (New-Card 'FAYC del lote — revisa cada renglón (ROJO es obligatorio)') $lFay; $cFay.Dock = 'Fill'
$fTop = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 76; BackColor = $Pal.Tarjeta }) $cFay
$fBot = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Bottom'; Height = 50; BackColor = $Pal.Tarjeta }) $cFay
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Conceptos en SI (lo demás va en NO):'; Location = '14,2'; AutoSize = $true; ForeColor = $Pal.Gris }) $fTop | Out-Null
$script:fSi = [ordered]@{}; $i = 0
foreach ($k in $CasaFaycSiNo.Keys) { $script:fSi[$k] = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = $k; AutoSize = $true; ForeColor = $Pal.Texto; Location = "$(14 + ($i % 6) * 112),$(22 + [Math]::Floor($i / 6) * 24)" }) $fTop; $i++ }
$btnFaySi = Add-Ctl (New-Btn 'Aplicar SI a los seleccionados' $Pal.Azul -Contorno) $fTop; $btnFaySi.SetBounds(700, 36, 280, 32)
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Elaboró'; Location = '700,8'; AutoSize = $true; ForeColor = $Pal.Gris }) $fTop | Out-Null
$cmbFayEla = Add-Ctl (New-Object Windows.Forms.ComboBox -Property @{ Location = '760,4'; Width = 220; DropDownStyle = 'DropDownList' }) $fTop
foreach ($n in $cmbEla.Items) { [void]$cmbFayEla.Items.Add($n) }
$fGrid = Add-Ctl (New-Object Windows.Forms.DataGridView -Property @{ Dock = 'Fill'; AllowUserToAddRows = $false; AllowUserToDeleteRows = $false; RowHeadersVisible = $false
  SelectionMode = 'FullRowSelect'; MultiSelect = $true; BackgroundColor = [Drawing.Color]::White; BorderStyle = 'None'; AutoSizeColumnsMode = 'Fill'; EnableHeadersVisualStyles = $false
  ColumnHeadersHeight = 30; ColumnHeadersHeightSizeMode = 'DisableResizing'; GridColor = $Pal.Linea; CellBorderStyle = 'SingleHorizontal'; EditMode = 'EditOnEnter' }) $cFay
$fGrid.BringToFront()
# espacio para el título de la tarjeta (arriba de todo) y el título encima
$fEsp = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 36; BackColor = $Pal.Tarjeta }) $cFay; $fEsp.SendToBack(); $cFay.Tag.Visible = $false
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = $cFay.Tag.Text; Font = $F.Tit; ForeColor = $Pal.Head; Location = '14,10'; AutoSize = $true }) $fEsp | Out-Null
# alto del panel: ~60 % de la pestaña, para que también se vea la tabla del lote
$lf.Add_Resize({ $lFay.Height = [Math]::Max(280, [int](([Math]::Max(0, $lf.ClientSize.Height - 240)) * 0.62)) })
$fGrid.ColumnHeadersDefaultCellStyle.BackColor = $Pal.Head; $fGrid.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White; $fGrid.ColumnHeadersDefaultCellStyle.Font = $F.Neg
$fGrid.DefaultCellStyle.SelectionBackColor = Hex '#DBEAFE'; $fGrid.DefaultCellStyle.SelectionForeColor = $Pal.Texto; $fGrid.RowTemplate.Height = 26
function Add-FCol($c) { $c.SortMode = 'NotSortable'; [void]$fGrid.Columns.Add($c); $c }
$c = Add-FCol (New-Object Windows.Forms.DataGridViewCheckBoxColumn -Property @{ Name = 'gen'; HeaderText = 'Generar'; FillWeight = 34 })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'ped'; HeaderText = 'Pedimento'; FillWeight = 60; ReadOnly = $true }); $c.DefaultCellStyle.Font = $F.Neg
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'cli'; HeaderText = 'Cliente'; FillWeight = 90; ReadOnly = $true })
$cRec = Add-FCol (New-Object Windows.Forms.DataGridViewComboBoxColumn -Property @{ Name = 'rec'; HeaderText = 'Recinto'; FillWeight = 80; FlatStyle = 'Flat' })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'fec'; HeaderText = 'Fecha de pago'; FillWeight = 74 })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'rem'; HeaderText = 'Remesas'; FillWeight = 40 })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'gas'; HeaderText = 'Gastos a terceros'; FillWeight = 80 })
$cRojo = Add-FCol (New-Object Windows.Forms.DataGridViewComboBoxColumn -Property @{ Name = 'rojo'; HeaderText = 'ROJO'; FillWeight = 40; FlatStyle = 'Flat' }); [void]$cRojo.Items.AddRange(@('', 'NO', 'SI'))
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'si'; HeaderText = 'En SI'; FillWeight = 90; ReadOnly = $true })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'fest'; HeaderText = 'Estado'; FillWeight = 90; ReadOnly = $true })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'dir'; Visible = $false })
$c = Add-FCol (New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = 'cr'; Visible = $false })
$fGrid.Add_DataError({ param($s, $e) $e.ThrowException = $false })   # valor de recinto que no está en la lista: no truena
$fGrid.Add_CurrentCellDirtyStateChanged({ if ($fGrid.IsCurrentCellDirty) { [void]$fGrid.CommitEdit('CurrentCellChange') } })
$fGrid.Add_CellValueChanged({ param($s, $e) if ($e.RowIndex -ge 0 -and $fGrid.Columns[$e.ColumnIndex].Name -eq 'rojo') { $cl = $fGrid.Rows[$e.RowIndex].Cells['rojo']; $cl.Style.ForeColor = $(if ($cl.Value -eq 'SI') { $Pal.Rojo } else { $Pal.Texto }); $cl.Style.Font = $F.Neg } })
# al elegir un solo renglón, las casillas muestran sus SI
$fGrid.Add_SelectionChanged({ if ($fGrid.SelectedRows.Count -eq 1) { $v = @("$($fGrid.SelectedRows[0].Cells['si'].Value)" -split ', ' | Where-Object { $_ }); foreach ($k in $script:fSi.Keys) { $script:fSi[$k].Checked = $v -contains $k } } })
$btnFaySi.Add_Click({
  if (-not $fGrid.SelectedRows.Count) { [void][Windows.Forms.MessageBox]::Show($form, 'Selecciona los renglones (Ctrl o Shift + clic).', 'FAYC del lote'); return }
  $si = @($script:fSi.Keys | Where-Object { $script:fSi[$_].Checked }) -join ', '
  foreach ($r in $fGrid.SelectedRows) { $r.Cells['si'].Value = $si }
})
$btnFayIr = Add-Ctl (New-Btn 'Generar FAYC + ZIP de los marcados' $Pal.Naranja) $fBot; $btnFayIr.SetBounds(14, 8, 300, 36)
$btnFayCerrar = Add-Ctl (New-Btn 'Ocultar' $Pal.Gris -Contorno) $fBot; $btnFayCerrar.SetBounds(322, 8, 110, 36)
$lblFay = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '446,17'; AutoSize = $true; Font = $F.Neg; ForeColor = $Pal.Gris }) $fBot
$btnFayCerrar.Add_Click({ $lFay.Visible = $false })
function Set-FilaFayc([string]$ped, [string]$col, [string]$val) {
  foreach ($r in $fGrid.Rows) { if ($r.Cells['ped'].Value -eq $ped) { $r.Cells[$col].Value = $val
    if ($col -eq 'fest') { $r.Cells['fest'].Style.ForeColor = $(if ($val -like 'Completo*') { $Pal.Verde } elseif ($val -match '^(Error|Revisar)') { $Pal.Rojo } else { $Pal.Azul }); $r.Cells['fest'].Style.Font = $F.Neg }
    if ($col -eq 'fest' -and $val -like 'Completo*') { $r.Cells['gen'].Value = $false; Set-Fila $ped 'est' 'Completo' }
    return } }
}
# llena la tabla con los pedimentos "Listo para FAYC" del lote (datos de cuando se prepararon)
function Show-FaycLote {
  $cRec.Items.Clear(); foreach ($x in $script:cfg.recintos) { [void]$cRec.Items.Add("$x") }
  $fGrid.Rows.Clear(); $n = 0
  foreach ($row in $grid.Rows) {
    if ("$($row.Cells['est'].Value)" -notlike 'Listo para FAYC*') { continue }
    $ped = "$($row.Cells['ped'].Value)"; $d = $null; try { if ("$($row.Cells['datos'].Value)") { $d = "$($row.Cells['datos'].Value)" | ConvertFrom-Json } } catch {}
    $dir = if ($d -and $d.rel) { Join-Path $CasaRoot $d.rel } else { @(Get-CasaCarpetas $ped) | Select-Object -First 1 }
    if (-not $dir -or -not (Test-Path -LiteralPath $dir)) { continue }
    $cli = Get-CasaCliente $dir
    $rec = if ($d -and $d.cr -and $script:cfg.cr[$d.cr]) { "$($script:cfg.cr[$d.cr])" } else { '' }
    if ($rec -and -not $cRec.Items.Contains($rec)) { [void]$cRec.Items.Add($rec) }
    $fec = if ($d -and $d.fecha) { ([datetime]::ParseExact($d.fecha, 'yyyy-MM-dd', $null)).ToString('dd/MM/yyyy') } else { '' }
    $gas = if ($cli -and $script:cfg.clientes.ContainsKey($cli)) { "$($script:cfg.clientes[$cli].gastos)" } else { "$cli" }
    $i = $fGrid.Rows.Add($true, $ped, $cli, $rec, $fec, $(if ($d) { "$($d.rem)" } else { '' }), $gas, '', '', $(if (@(Get-ChildItem -LiteralPath $dir -Filter 'FAYC-0122*.pdf' -File).Count) { 'Ya tiene FAYC' } else { 'Por generar' }), $dir, $(if ($d) { "$($d.cr)" } else { '' }))
    if (-not $rec) { $fGrid.Rows[$i].Cells['rec'].Style.BackColor = Hex '#FEF2F2' }
    $n++
  }
  $cmbFayEla.SelectedItem = $cmbEla.SelectedItem
  $lblFay.Text = if ($n) { "$n pedimento(s). Pon ROJO (SI/NO) en cada uno, revisa el recinto (rojo = falta) y los SI." } else { 'No hay pedimentos "Listo para FAYC" en el lote.' }
  $lFay.Visible = $true
}
$btnFayIr.Add_Click({
  if ($fGrid.IsCurrentCellDirty) { [void]$fGrid.CommitEdit('CurrentCellChange') }; [void]$fGrid.EndEdit()
  $elab = "$($cmbFayEla.SelectedItem)"; if (-not $elab) { [void][Windows.Forms.MessageBox]::Show($form, 'Elige quién elaboró.', 'FAYC del lote'); return }
  $filas = @(); $mal = @()
  foreach ($r in $fGrid.Rows) {
    if (-not $r.Cells['gen'].Value) { continue }
    $p = "$($r.Cells['ped'].Value)"; $fe = [datetime]::MinValue
    $ok = [datetime]::TryParseExact("$($r.Cells['fec'].Value)".Trim(), 'dd/MM/yyyy', $null, 'None', [ref]$fe)
    $rem = 0; $okR = [int]::TryParse("$($r.Cells['rem'].Value)".Trim(), [ref]$rem)
    $falta = @(); if ("$($r.Cells['rojo'].Value)" -notin 'SI', 'NO') { $falta += 'ROJO' }; if (-not "$($r.Cells['rec'].Value)".Trim()) { $falta += 'recinto' }
    if (-not $ok) { $falta += 'fecha' }; if (-not $okR) { $falta += 'remesas' }; if (-not "$($r.Cells['gas'].Value)".Trim()) { $falta += 'gastos a terceros' }
    if ($falta) { $mal += "$p`: falta $($falta -join ', ')"; continue }
    $filas += @{ ped = $p; dir = "$($r.Cells['dir'].Value)"; fecha = $fe.Date; rec = "$($r.Cells['rec'].Value)".Trim(); rem = $rem; rojo = "$($r.Cells['rojo'].Value)"; gas = "$($r.Cells['gas'].Value)".Trim()
                 si = @("$($r.Cells['si'].Value)" -split ', ' | Where-Object { $_ }); cli = "$($r.Cells['cli'].Value)"; cr = "$($r.Cells['cr'].Value)" }
  }
  if ($mal) { [void][Windows.Forms.MessageBox]::Show($form, "Revisa estos renglones:`n`n$($mal -join "`n")", 'FAYC del lote', 'OK', 'Warning'); return }
  if (-not $filas.Count) { [void][Windows.Forms.MessageBox]::Show($form, 'No hay renglones marcados en "Generar".', 'FAYC del lote'); return }
  $res = ($filas | ForEach-Object { "$($_.ped) · $($_.rec) · pago $($_.fecha.ToString('dd/MM/yyyy')) · rem $($_.rem) · ROJO $($_.rojo) · SI: $(if ($_.si) { $_.si -join ', ' } else { 'ninguno' })" }) -join "`n"
  if ([Windows.Forms.MessageBox]::Show($form, "Elaboró: $elab`n`n$res`n`n¿Genero estas $($filas.Count) FAYC y sus ZIP?", 'Confirmar FAYC del lote', 'YesNo', 'Question') -ne 'Yes') { return }
  foreach ($x in $filas) { Set-FilaFayc $x.ped 'fest' 'En espera' }; $script:fayFilas = $filas
  $btnFayIr.Enabled = $false
  Start-Trabajo "FAYC + ZIP de $($filas.Count) pedimentos" {
    foreach ($x in $a.filas) {
      $global:ColaApp.Enqueue("@@F|$($x.ped)|fest|Generando…")
      try {
        $global:ColaApp.Enqueue("[$($x.ped)] " + (New-CasaFayc -Pedimento $x.ped -FechaPago $x.fecha -Recinto $x.rec -Remesas $x.rem -Rojo $x.rojo -GastosTerceros $x.gas -Si $x.si -Dir $x.dir -Elaboro $a.elab))
        $global:ColaApp.Enqueue("[$($x.ped)] " + (New-CasaZip -Pedimento $x.ped -Dir $x.dir))
        $f = (Start-CasaExpediente -Pedimento $x.ped -Dir $x.dir -SoloRevisar).Faltan
        $global:ColaApp.Enqueue("@@F|$($x.ped)|fest|$(if ($f) { "Revisar: falta $f" } else { 'Completo ✔' })")
      } catch { $global:ColaApp.Enqueue("@@F|$($x.ped)|fest|Error: $($_.Exception.Message)"); $global:ColaApp.Enqueue("[$($x.ped)] ⚠ $($_.Exception.Message)") }
    }
    $out.ok = $true
  } @{ filas = $filas; elab = $elab } {
    param($o)
    $btnFayIr.Enabled = $true
    # recordar recintos, CR -> recinto, gastos por cliente y quién elaboró (como la FAYC de un pedimento)
    foreach ($x in $script:fayFilas) {
      if ($script:cfg.recintos -notcontains $x.rec) { $script:cfg.recintos = @($script:cfg.recintos) + $x.rec }
      if ($x.cr -and -not $script:cfg.cr[$x.cr]) { $script:cfg.cr[$x.cr] = $x.rec }
      if ($x.cli) { $script:cfg.clientes[$x.cli] = @{ gastos = $x.gas } }
    }
    if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }; $script:cfg.equipos[$CasaEquipo]['elaboro'] = "$($cmbFayEla.SelectedItem)"
    Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig; Fill-Recintos; Fill-Gastos
    $okN = @($fGrid.Rows | Where-Object { "$($_.Cells['fest'].Value)" -like 'Completo*' }).Count
    $lblFay.Text = "Terminado: $okN completo(s). Revisa los que digan Revisar o Error."; Log "== FAYC del lote terminada: $okN completo(s)"
  }
  if (-not $script:bg) { $btnFayIr.Enabled = $true }
})
# ---------- Glosa de pedimentos (ventana aparte; NO forma parte del expediente: no escribe en la carpeta) ----------
$gf = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Fill'; BackColor = $Pal.Fondo; Visible = $false; Padding = '12,12,12,12'; AllowDrop = $true })
$gTop = Add-Ctl (New-Card 'Glosa antes de pagar') $gf
$gTop.Dock = 'Top'; $gTop.Height = 214
$gEsp = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Top'; Height = 12; BackColor = $Pal.Fondo }) $gf
$gTop.SendToBack()
$gRbA = Add-Ctl (New-Object Windows.Forms.RadioButton -Property @{ Text = 'Aéreo: pedimento contra factura y guía'; Location = '200,9'; AutoSize = $true; Checked = $true; Font = $F.Neg; ForeColor = $Pal.Texto }) $gTop
$gRbV = Add-Ctl (New-Object Windows.Forms.RadioButton -Property @{ Text = 'Virtual: importación contra exportación'; Location = '500,9'; AutoSize = $true; Font = $F.Neg; ForeColor = $Pal.Texto }) $gTop
New-Lbl 'Pedimento' '14,44' $gTop
$gPed = Add-Ctl (New-Object Windows.Forms.TextBox -Property @{ Location = '110,40'; Width = 110; Font = $F.Neg; MaxLength = 7 }) $gTop
$gBus = Add-Ctl (New-Btn 'Tomar de su carpeta' $Pal.Azul -Contorno) $gTop; $gBus.SetBounds(230, 37, 170, 30)
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'o arrastra los PDF aquí'; Location = '410,44'; AutoSize = $true; ForeColor = $Pal.Gris }) $gTop | Out-Null
$script:gTxt = @{}
$y = 78
$script:gLbl = @{}
foreach ($k in 'Pedimento (proforma)', 'Factura', 'Guía') {
  $script:gLbl[$k] = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = $k; Location = "14,$($y + 4)"; AutoSize = $true; ForeColor = $Pal.Gris }) $gTop
  $t = Add-Ctl (New-Object Windows.Forms.TextBox -Property @{ Location = "150,$y"; Width = 600; ReadOnly = $true; BackColor = [Drawing.Color]::White }) $gTop
  $b = Add-Ctl (New-Btn 'Elegir…' $Pal.Gris -Contorno) $gTop; $b.SetBounds(758, $y - 2, 90, 28); $b.Tag.Campo = $k
  $b.Add_Click({ $d = New-Object Windows.Forms.OpenFileDialog -Property @{ Title = "Elige el PDF: $($this.Tag.Campo)"; Filter = 'PDF (*.pdf)|*.pdf' }
    $cur = $script:gTxt[$this.Tag.Campo].Text; if ($cur) { $d.InitialDirectory = Split-Path $cur }
    if ($d.ShowDialog($form) -eq 'OK') { $script:gTxt[$this.Tag.Campo].Text = $d.FileName } })
  $script:gTxt[$k] = $t; $script:gLbl["b$k"] = $b; $y += 34
}
# modo: en Virtual el renglón 1 es un pedimento (impo o expo) y el 2 su contraparte (opcional: se busca sola)
function Set-ModoGlosa {
  $v = $gRbV.Checked
  $script:gLbl['Pedimento (proforma)'].Text = if ($v) { 'Pedimento (impo o expo)' } else { 'Pedimento (proforma)' }
  $script:gLbl['Factura'].Text = if ($v) { 'Contraparte (opcional)' } else { 'Factura' }
  foreach ($x in $script:gLbl['Guía'], $script:gTxt['Guía'], $script:gLbl['bGuía']) { $x.Visible = -not $v }
  $gGrid.Columns['ped'].HeaderText = if ($v) { 'Importación' } else { 'Pedimento' }
  $gGrid.Columns['doc'].HeaderText = if ($v) { 'Exportación' } else { 'Documento / cálculo' }
  $gGrid.Rows.Clear(); $gRes.Text = ''; $gGuardar.Enabled = $false
}
$gIr = Add-Ctl (New-Btn 'Glosar' $Pal.Morado) $gTop; $gIr.SetBounds(150, 178, 160, 30)
$gLimp = Add-Ctl (New-Btn 'Limpiar' $Pal.Gris -Contorno) $gTop; $gLimp.SetBounds(318, 178, 100, 30)
$gGuardar = Add-Ctl (New-Btn 'Guardar como PDF…' $Pal.Head -Contorno) $gTop; $gGuardar.SetBounds(426, 178, 160, 30); $gGuardar.Enabled = $false
$gRes = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '600,184'; AutoSize = $true; Font = $F.Tit }) $gTop
$gGrid = Add-Ctl (New-Object Windows.Forms.DataGridView -Property @{ Dock = 'Fill'; ReadOnly = $true; AllowUserToAddRows = $false; AllowUserToDeleteRows = $false; RowHeadersVisible = $false
  SelectionMode = 'FullRowSelect'; MultiSelect = $false; BackgroundColor = [Drawing.Color]::White; BorderStyle = 'None'; AutoSizeColumnsMode = 'Fill'; EnableHeadersVisualStyles = $false
  ColumnHeadersHeight = 32; ColumnHeadersHeightSizeMode = 'DisableResizing'; GridColor = $Pal.Linea; CellBorderStyle = 'SingleHorizontal'; AutoSizeRowsMode = 'AllCells' }) $gf
$gGrid.BringToFront()
$gGrid.ColumnHeadersDefaultCellStyle.BackColor = $Pal.Head; $gGrid.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White; $gGrid.ColumnHeadersDefaultCellStyle.Font = $F.Neg
$gGrid.DefaultCellStyle.WrapMode = 'True'; $gGrid.DefaultCellStyle.SelectionBackColor = Hex '#DBEAFE'; $gGrid.DefaultCellStyle.SelectionForeColor = $Pal.Texto
foreach ($col in @(@('con', 'Concepto', 34), @('ped', 'Pedimento', 18), @('doc', 'Documento / cálculo', 36), @('res', 'Resultado', 12))) { $i = $gGrid.Columns.Add($col[0], $col[1]); $gGrid.Columns[$i].FillWeight = $col[2]; $gGrid.Columns[$i].SortMode = 'NotSortable' }
$script:gUltimo = $null
$gRbA.Add_CheckedChanged({ Set-ModoGlosa }); $gRbV.Add_CheckedChanged({ if ($gRbV.Checked) { Set-ModoGlosa } })

# arrastrar PDF: se acomodan por nombre (PRF_/IMP_ = pedimento, GR_/guía = guía, INV_/factura = factura)
$gArrEnt = { param($s, $e) if ($e.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) { $e.Effect = 'Copy' } }
$gArrSol = { param($s, $e)
  foreach ($fp in $e.Data.GetData([Windows.Forms.DataFormats]::FileDrop)) {
    if ($fp -notmatch '\.pdf$') { continue }; $n = Split-Path $fp -Leaf
    if ($gRbV.Checked) { if (-not $script:gTxt['Pedimento (proforma)'].Text) { $script:gTxt['Pedimento (proforma)'].Text = $fp } else { $script:gTxt['Factura'].Text = $fp }; continue }
    $k = if ($n -match '^(PRF|IMP|EXP|T|AA)_|PEDIMENTO|PROFORMA') { 'Pedimento (proforma)' } elseif ($n -match '^GR_|GUIA|GUÍA|AWB') { 'Guía' } elseif ($n -match '^INV_|FACT|INVOICE') { 'Factura' } else { $null }
    if (-not $k) { $k = @('Pedimento (proforma)', 'Factura', 'Guía') | Where-Object { -not $script:gTxt[$_].Text } | Select-Object -First 1 }
    if ($k) { $script:gTxt[$k].Text = $fp }
  } }
# se puede soltar en cualquier parte de la pestaña (fondo, tarjeta, cajas o tabla)
foreach ($c in @($gf, $gTop, $gGrid) + @($gTop.Controls)) { $c.AllowDrop = $true; $c.Add_DragEnter($gArrEnt); $c.Add_DragDrop($gArrSol) }
$gBus.Add_Click({
  $p = $gPed.Text.Trim(); if ($p -notmatch '^\d{7}$') { [void][Windows.Forms.MessageBox]::Show($form, 'Escribe el pedimento (7 dígitos).', 'Glosa'); return }
  $c = @(Get-CasaCarpetas $p); if (-not $c.Count) { [void][Windows.Forms.MessageBox]::Show($form, "No hay carpeta con $p.", 'Glosa'); return }
  $dir = $c[0]; if ($c.Count -gt 1) { $dir = $null; $d = New-Object Windows.Forms.FolderBrowserDialog -Property @{ Description = "Hay $($c.Count) carpetas con $p. Elige la correcta."; SelectedPath = $c[0] }; if ($d.ShowDialog($form) -eq 'OK') { $dir = $d.SelectedPath } else { return } }
  if ($gRbV.Checked) {
    $script:gTxt['Pedimento (proforma)'].Text = "$(& { . "$PSScriptRoot\glosa.ps1"; Find-PdfPedimento $dir $p })"; $script:gTxt['Factura'].Text = ''
    if (-not $script:gTxt['Pedimento (proforma)'].Text) { [void][Windows.Forms.MessageBox]::Show($form, "No encontré el PDF del pedimento $p en su carpeta.", 'Glosa') }
    return
  }
  $fs = @(Get-ChildItem -LiteralPath $dir -File -Filter *.pdf)
  $pp = $fs | Where-Object Name -match '(^|[-_ ])PRF_' | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if (-not $pp) { $pp = $fs | Where-Object { $_.Name -match '^(IMP|EXP|T|AA)_' } | Select-Object -First 1 }
  $script:gTxt['Pedimento (proforma)'].Text = "$($pp.FullName)"
  $script:gTxt['Guía'].Text = "$(($fs | Where-Object { $_.Name -like 'GR_*' -or $_.Name -match 'GUIA|AWB' } | Select-Object -First 1).FullName)"
  $script:gTxt['Factura'].Text = "$(($fs | Where-Object { $_.Name -like 'INV_*' } | Select-Object -First 1).FullName)"
})
$gLimp.Add_Click({ foreach ($t in $script:gTxt.Values) { $t.Text = '' }; $gPed.Text = ''; $gGrid.Rows.Clear(); $gRes.Text = ''; $gGuardar.Enabled = $false; $script:gUltimo = $null })
function Show-GlosaGrid($r) {
  $gGrid.SuspendLayout(); $gGrid.Rows.Clear()
  foreach ($g in ($r.Revs | Group-Object Seccion)) {
    $i = $gGrid.Rows.Add($g.Name, '', '', ''); $row = $gGrid.Rows[$i]; $row.DefaultCellStyle.BackColor = Hex '#EEF2F7'; $row.DefaultCellStyle.ForeColor = $Pal.Head; $row.DefaultCellStyle.Font = $F.Neg
    foreach ($x in $g.Group) {
      $res = if (-not $x.Ok) { '✖ Diferencia' } elseif ($x.Aviso) { '≈ Redondeo' } else { '✔ Igual' }
      $doc = if ($x.Nota) { "$($x.Documento)  ($($x.Nota))" } else { $x.Documento }
      $i = $gGrid.Rows.Add($x.Concepto, $x.Pedimento, $doc, $res); $row = $gGrid.Rows[$i]
      if (-not $x.Ok) { $row.DefaultCellStyle.BackColor = Hex '#FEF2F2'; $row.Cells['res'].Style.ForeColor = $Pal.Rojo; $row.Cells['res'].Style.Font = $F.Neg }
      elseif ($x.Aviso) { $row.DefaultCellStyle.BackColor = Hex '#FFFBEB'; $row.Cells['res'].Style.ForeColor = Hex '#B45309' }
      else { $row.Cells['res'].Style.ForeColor = $Pal.Verde }
    }
  }
  $gGrid.ResumeLayout()
  $gRes.Text = "✖ $($r.Diferencias) diferencia(s)   ≈ $($r.Redondeos) redondeo(s)   ✔ $($r.Revisiones - $r.Diferencias - $r.Redondeos) igual(es)"
  $gRes.ForeColor = if ($r.Diferencias) { $Pal.Rojo } else { $Pal.Verde }
}
$gIr.Add_Click({
  $pp = $script:gTxt['Pedimento (proforma)'].Text
  if (-not $pp) { [void][Windows.Forms.MessageBox]::Show($form, 'Falta el PDF del pedimento (proforma).', 'Glosa'); return }
  if ($script:bg) { [void][Windows.Forms.MessageBox]::Show($form, "Espera a que termine: $($script:bg.Que)", 'Glosa'); return }
  $gGrid.Rows.Clear(); $gRes.Text = 'Glosando…'; $gRes.ForeColor = $Pal.Azul; $gIr.Enabled = $false; $gGuardar.Enabled = $false
  Start-Trabajo $(if ($gRbV.Checked) { 'Glosando el par virtual' } else { 'Glosando el pedimento' }) {
    . "$root\glosa.ps1"
    $lg = { param($m) $global:ColaApp.Enqueue([string]$m) }
    $r = if ($a.virtual) { Invoke-CasaGlosaVirtual -PdfImpo $a.pp -PdfExpo $a.pf -Log $lg } else { Invoke-CasaGlosa -Pedimento $a.ped -PdfPedimento $a.pp -PdfFactura $a.pf -PdfGuia $a.pg -Log $lg }
    $out.r = $r
  } @{ ped = $gPed.Text.Trim(); pp = $pp; pf = $script:gTxt['Factura'].Text; pg = $script:gTxt['Guía'].Text; virtual = $gRbV.Checked } {
    param($o)
    $gIr.Enabled = $true
    if ($o.r) { $script:gUltimo = $o.r; Show-GlosaGrid $o.r; $gGuardar.Enabled = $true
      if ($o.r.Expo) { $gRes.Text = "Impo $(($o.r.Impo.Pedimento -split ' ')[-1]) contra expo $(($o.r.Expo.Pedimento -split ' ')[-1]):   " + $gRes.Text }
      elseif (-not $gPed.Text -and $o.r.Pedimento.Pedimento) { $gPed.Text = ($o.r.Pedimento.Pedimento -split ' ')[-1] } }
    else { $gRes.Text = "No se pudo glosar: $($o.error)"; $gRes.ForeColor = $Pal.Rojo }
  }
})
$gGuardar.Add_Click({
  if (-not $script:gUltimo) { return }
  $r = $script:gUltimo; $n = "GLOSA_$((($r.Pedimento.Pedimento -replace ' / ', '_' -split ' ')[-1]))_$(Get-Date -Format 'yyyyMMdd_HHmm').pdf"
  $d = New-Object Windows.Forms.SaveFileDialog -Property @{ Title = 'Guardar la hoja de glosa'; Filter = 'PDF (*.pdf)|*.pdf'; FileName = $n; InitialDirectory = [Environment]::GetFolderPath('MyDocuments') }
  if ($d.ShowDialog($form) -ne 'OK') { return }
  try { . "$PSScriptRoot\glosa.ps1"; $cols = if ($r.Columnas) { $r.Columnas } else { @('Pedimento', 'Documento / cálculo') }; $h = Export-HojaGlosa $r.Pedimento $r.Revs $r.Docs $d.FileName $cols; Start-Process -FilePath $h } catch { [void][Windows.Forms.MessageBox]::Show($form, "No pude guardar: $($_.Exception.Message)", 'Glosa') }
})

# ---------- Configuración: empresa, rutas de esta PC y mapa de CASA ----------
$cf = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Fill'; BackColor = $Pal.Fondo; Visible = $false; AutoScroll = $true })
function New-CfgTxt([string]$loc, [int]$w, [string]$anchor = 'Top,Left') { New-Object Windows.Forms.TextBox -Property @{ Location = $loc; Width = $w; Anchor = $anchor } }
function Set-Cue($tb, [string]$t) { [void][AppWin]::SendMessage($tb.Handle, 0x1501, [IntPtr]1, $t) }   # texto gris cuando está vacío

# --- licencia ---
$cLic = Add-Ctl (New-Card 'Licencia') $cf; $cLic.Width = 1100; $cLic.Height = 168
$lblLic = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '14,38'; Size = '700,44'; Font = $F.Neg; Anchor = 'Top,Left,Right'; UseMnemonic = $false }) $cLic   # sin esto "A&C" se ve "AC"
$btnLicCar = Add-Ctl (New-Btn 'Cargar licencia…' $Pal.Verde) $cLic; $btnLicCar.SetBounds(1100 - 14 - 190, 36, 190, 34); $btnLicCar.Anchor = 'Top,Right'
New-Lbl 'PCs que usan la licencia:' '14,90' $cLic
$lstLic = Add-Ctl (New-Object Windows.Forms.ListBox -Property @{ Location = '14,110'; Size = '700,48'; BorderStyle = 'FixedSingle'; Anchor = 'Top,Left,Right' }) $cLic
$btnLicLib = Add-Ctl (New-Btn 'Liberar PC' $Pal.Rojo -Contorno) $cLic; $btnLicLib.SetBounds(1100 - 14 - 190, 112, 190, 34); $btnLicLib.Anchor = 'Top,Right'
function Update-Licencia {
  $script:lic = Get-CasaLicencia -Registrar
  $l = $script:lic
  $lblLic.Text = if ($l.Ok) { "✔ $($l.Motivo)" + $(if (-not $l.Exenta -and $l.Dias -le 15) { "`n⚠ Faltan $($l.Dias) día(s) para que venza: pide la renovación." } else { '' }) } else { "✖ SIN LICENCIA: $($l.Motivo)`nMientras tanto la app está bloqueada (solo funciona esta pestaña)." }
  $lblLic.ForeColor = if (-not $l.Ok) { $Pal.Rojo } elseif (-not $l.Exenta -and $l.Dias -le 15) { $Pal.Naranja } else { $Pal.Verde }
  $lstLic.Items.Clear(); foreach ($x in (Get-CasaLicPcs)) { [void]$lstLic.Items.Add("$($x.Pc)  ·  $($x.Usuario)  ·  desde $($x.Alta.ToString('d MMM yyyy'))  ·  último uso $($x.Visto.ToString('d MMM yyyy'))") }
  $lblLicHead.Visible = -not $l.Exenta
  if (-not $l.Exenta) { $lblLicHead.Text = if ($l.Ok) { "Licencia: $($l.Empresa) · $($l.Usadas)/$($l.Pcs) PCs · vence $($l.Vence.ToString('d MMM yyyy'))" } else { 'SIN LICENCIA' }
    $lblLicHead.BackColor = if (-not $l.Ok) { $Pal.Rojo } elseif ($l.Dias -le 15) { $Pal.Naranja } else { $Pal.Head } }
  Set-PestanasLic
}
$btnLicCar.Add_Click({
  $o = New-Object Windows.Forms.OpenFileDialog -Property @{ Title = 'Elige la licencia (.lic)'; Filter = 'Licencia (*.lic)|*.lic' }; if ($o.ShowDialog($form) -ne 'OK') { return }
  $p = Get-CasaLicencia -Archivo $o.FileName
  if (-not $p.Ok -and $p.Motivo -notmatch 'Ya se usan') { [void][Windows.Forms.MessageBox]::Show($form, "No cargué esa licencia:`n`n$($p.Motivo)", 'Licencia', 'OK', 'Warning'); return }
  if (Test-Path -LiteralPath $CasaLicArch) { Copy-Item -LiteralPath $CasaLicArch -Destination "$CasaLicArch.anterior" -Force }
  Copy-Item -LiteralPath $o.FileName -Destination $CasaLicArch -Force
  Update-Licencia; Log $(if ($script:lic.Ok) { "✔ Licencia cargada: $($script:lic.Motivo)" } else { "⚠ Licencia cargada, pero: $($script:lic.Motivo)" })
})
$btnLicLib.Add_Click({
  if ($lstLic.SelectedIndex -lt 0) { [void][Windows.Forms.MessageBox]::Show($form, 'Elige la PC que ya no se usa.', 'Liberar PC'); return }
  $pc = ("$($lstLic.SelectedItem)" -split '  ·  ')[0]
  if ([Windows.Forms.MessageBox]::Show($form, "¿Libero la PC $pc? Deja de contar para la licencia (si la vuelven a abrir, cuenta otra vez).", 'Liberar PC', 'YesNo', 'Question') -ne 'Yes') { return }
  Remove-Item -LiteralPath "$CasaLicDirPcs\$pc.json" -Force -ErrorAction SilentlyContinue; Update-Licencia; Log "PC $pc liberada de la licencia"
})

# --- empresa (la comparten todas las PCs) ---
$cEmp = Add-Ctl (New-Card 'Empresa (la comparten todas las PCs)') $cf; $cEmp.Width = 1100; $cEmp.Height = 150
$script:empTxt = [ordered]@{}
foreach ($d in @(@('nombre', 'Nombre', 14, 40, 110, 280), @('patente', 'Patente', 420, 40, 490, 70), @('aduana', 'Aduana', 580, 40, 640, 60),
                 @('ciudad', 'Ciudad (FAYC)', 14, 76, 110, 280), @('prefijo', 'Prefijo de referencia', 420, 76, 560, 90), @('carpeta', 'Carpeta de expedientes', 670, 76, 820, 220),
                 @('tablero', 'Tablero', 720, 40, 775, 130))) {
  New-Lbl $d[1] "$($d[2]),$($d[3] + 4)" $cEmp
  $script:empTxt[$d[0]] = Add-Ctl (New-CfgTxt "$($d[4]),$($d[3])" $d[5]) $cEmp
}
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Patente y aduana se usan en los archivos de TRANSMIT (M1664…, carpeta TRANSMIT\1664-520) y en la FAYC. Referencia = prefijo + 4 últimos dígitos del pedimento (AYC26-8031). Carpeta de expedientes = carpeta en OneDrive con todos los clientes.'
  Location = '14,110'; Size = '900,34'; ForeColor = $Pal.Gris; Anchor = 'Top,Left,Right' }) $cEmp | Out-Null
$btnEmp = Add-Ctl (New-Btn 'Guardar empresa' $Pal.Azul) $cEmp; $btnEmp.SetBounds(1100 - 14 - 170, 36, 170, 34); $btnEmp.Anchor = 'Top,Right'

# --- recintos y gastos de la FAYC (los da de alta cada agencia; se comparten entre PCs) ---
$cFay = Add-Ctl (New-Card 'Recintos y gastos de la FAYC (los comparten todas las PCs)') $cf; $cFay.Width = 1100; $cFay.Height = 330
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Escribe directo en las tablas (el último renglón vacío es para agregar). Clave CR = la que trae el archivo de validación (p. ej. 243): con ella la app elige sola el recinto. Facturar a = lo que va en "Gastos a terceros" de la FAYC de ese cliente.'
  Location = '14,34'; Size = '1070,32'; ForeColor = $Pal.Gris; Anchor = 'Top,Left,Right' }) $cFay | Out-Null
function New-CfgGrid([string]$loc, [string]$size, $cols) {
  $g = New-Object Windows.Forms.DataGridView -Property @{ Location = $loc; Size = $size; AllowUserToAddRows = $true; AllowUserToDeleteRows = $true; RowHeadersVisible = $false; SelectionMode = 'CellSelect'
    BackgroundColor = [Drawing.Color]::White; BorderStyle = 'FixedSingle'; AutoSizeColumnsMode = 'Fill'; EnableHeadersVisualStyles = $false; ColumnHeadersHeight = 28; ColumnHeadersHeightSizeMode = 'DisableResizing'; GridColor = $Pal.Linea }
  $g.ColumnHeadersDefaultCellStyle.BackColor = $Pal.Head; $g.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White; $g.ColumnHeadersDefaultCellStyle.Font = $F.Neg
  foreach ($c in $cols) { [void]$g.Columns.Add((New-Object Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = $c[0]; HeaderText = $c[1]; FillWeight = $c[2] })) }
  $g
}
New-Lbl 'Recintos fiscales' '14,72' $cFay
$gRec = Add-Ctl (New-CfgGrid '14,92' '420,180' @(@('rec', 'Recinto fiscal', 60), @('crs', 'Claves CR (p. ej. 243, 158)', 40))) $cFay
New-Lbl 'Gastos a terceros por cliente' '452,72' $cFay
$gGas = Add-Ctl (New-CfgGrid '452,92' '634,180' @(@('cli', 'Cliente (nombre de su carpeta)', 55), @('gas', 'Gastos a terceros: facturar a', 45))) $cFay; $gGas.Anchor = 'Top,Left,Right'
$btnRecQ = Add-Ctl (New-Btn 'Quitar recinto' $Pal.Rojo -Contorno) $cFay; $btnRecQ.SetBounds(14, 280, 150, 34)
$btnGasQ = Add-Ctl (New-Btn 'Quitar cliente' $Pal.Rojo -Contorno) $cFay; $btnGasQ.SetBounds(452, 280, 150, 34)
$btnGasCar = Add-Ctl (New-Btn 'Agregar clientes de las carpetas' $Pal.Head -Contorno) $cFay; $btnGasCar.SetBounds(610, 280, 250, 34)
$btnFay = Add-Ctl (New-Btn 'Guardar' $Pal.Azul) $cFay; $btnFay.SetBounds(1100 - 14 - 170, 280, 170, 34); $btnFay.Anchor = 'Top,Right'
function Fill-Fay {
  $gRec.Rows.Clear(); $gGas.Rows.Clear()
  foreach ($r in @($script:cfg.recintos | Sort-Object)) { $crs = @($script:cfg.cr.Keys | Where-Object { $script:cfg.cr[$_] -eq $r } | Sort-Object) -join ', '; [void]$gRec.Rows.Add($r, $crs) }
  foreach ($k in @($script:cfg.cr.Keys | Where-Object { $script:cfg.recintos -notcontains $script:cfg.cr[$_] })) { [void]$gRec.Rows.Add($script:cfg.cr[$k], $k) }   # CR de un recinto que no estaba en la lista
  foreach ($k in @($script:cfg.clientes.Keys | Sort-Object)) { [void]$gGas.Rows.Add($k, "$($script:cfg.clientes[$k].gastos)") }
}
function Remove-FilaSel($g) { $r = $g.CurrentRow; if ($r -and -not $r.IsNewRow) { $g.Rows.Remove($r) } }
$btnRecQ.Add_Click({ Remove-FilaSel $gRec }); $btnGasQ.Add_Click({ Remove-FilaSel $gGas })
$btnGasCar.Add_Click({
  if (-not $CasaRoot -or -not (Test-Path -LiteralPath $CasaRoot)) { [void][Windows.Forms.MessageBox]::Show($form, 'No encuentro la carpeta de expedientes (revísala en Rutas de esta PC).', 'Clientes'); return }
  $ya = @($gGas.Rows | Where-Object { -not $_.IsNewRow } | ForEach-Object { "$($_.Cells['cli'].Value)".Trim().ToUpper() })
  $n = 0; foreach ($d in @(Get-ChildItem -LiteralPath $CasaRoot -Directory -ErrorAction SilentlyContinue | Sort-Object Name)) { if ($ya -notcontains $d.Name.ToUpper()) { [void]$gGas.Rows.Add($d.Name, $d.Name); $n++ } }
  Log $(if ($n) { "Agregué $n cliente(s) de las carpetas: revisa a quién se factura y da Guardar" } else { 'Todos los clientes de las carpetas ya están en la lista' })
})
$btnFay.Add_Click({
  $gRec.EndEdit(); $gGas.EndEdit()
  $rec = @(); $cr = @{}; $cli = @{}; $mal = @()
  foreach ($r in @($gRec.Rows | Where-Object { -not $_.IsNewRow })) {
    $n = "$($r.Cells['rec'].Value)".Trim().ToUpper(); $cs = @("$($r.Cells['crs'].Value)" -split '[,; ]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if (-not $n) { if ($cs) { $mal += "Claves CR $($cs -join ', ') sin recinto" }; continue }
    if ($rec -notcontains $n) { $rec += $n }
    foreach ($k in $cs) { if ($k -notmatch '^\d{1,4}$') { $mal += "CR '$k' de $n (solo números)" } elseif ($cr.ContainsKey($k) -and $cr[$k] -ne $n) { $mal += "CR $k está en $($cr[$k]) y en $n" } else { $cr[$k] = $n } }
  }
  foreach ($r in @($gGas.Rows | Where-Object { -not $_.IsNewRow })) {
    $n = "$($r.Cells['cli'].Value)".Trim(); $g = "$($r.Cells['gas'].Value)".Trim()
    if (-not $n) { continue }; if (-not $g) { $mal += "Falta a quién facturar los gastos de $n" } else { $cli[$n.ToUpper()] = $g }
  }
  if ($mal) { [void][Windows.Forms.MessageBox]::Show($form, "Revisa esto antes de guardar:`n`n$($mal -join "`n")", 'Recintos y gastos', 'OK', 'Warning'); return }
  $antes = Get-CasaConfig
  $borrar = @{ recintos = @($antes.recintos | Where-Object { $rec -notcontains $_ }); cr = @($antes.cr.Keys | Where-Object { -not $cr.ContainsKey($_) }); clientes = @($antes.clientes.Keys | Where-Object { -not $cli.ContainsKey($_.ToUpper()) -and -not $cli.ContainsKey($_) }) }
  $quita = @($borrar.recintos) + @($borrar.clientes)
  if ($quita -and [Windows.Forms.MessageBox]::Show($form, "Se quitan (para todas las PCs):`n`n$($quita -join "`n")`n`n¿Guardo?", 'Recintos y gastos', 'YesNo', 'Question') -ne 'Yes') { return }
  $script:cfg.recintos = $rec; $script:cfg.cr = $cr; $script:cfg.clientes = @{}; foreach ($k in $cli.Keys) { $script:cfg.clientes[$k] = @{ gastos = $cli[$k] } }
  Save-CasaConfig $script:cfg -Borrar $borrar; $script:cfg = Get-CasaConfig; Fill-Fay; Fill-Recintos; Fill-Gastos
  Log "✔ Recintos y gastos guardados: $($rec.Count) recinto(s), $($cr.Count) clave(s) CR, $($cli.Count) cliente(s)"
})

# --- rutas de esta PC (vacío = automático) ---
$cRut = Add-Ctl (New-Card "Rutas de esta PC ($CasaEquipo) — vacío = automático") $cf; $cRut.Width = 1100; $cRut.Height = 250
$script:rutas = [ordered]@{ raiz = @('Carpeta de expedientes', 'dir'); casa = @('Carpeta de CASA (CSAAIWIN)', 'dir'); vucem = @('Almacén VUCEM', 'dir'); transmit = @('TRANSMIT (validación/pago)', 'dir'); plantilla = @('Plantilla FAYC (.xlsx)', 'xlsx') }
$script:rutTxt = @{}; $y = 40
foreach ($k in $script:rutas.Keys) {
  New-Lbl $script:rutas[$k][0] "14,$($y + 4)" $cRut
  $t = Add-Ctl (New-CfgTxt "200,$y" (1100 - 200 - 14 - 48) 'Top,Left,Right') $cRut
  $b = Add-Ctl (New-Btn '…' $Pal.Gris -Contorno) $cRut; $b.SetBounds(1100 - 14 - 40, $y - 1, 40, 26); $b.Anchor = 'Top,Right'; $b.Tag.Campo = $k
  $b.Add_Click({
    $k = $this.Tag.Campo; $t = $script:rutTxt[$k]
    if ($script:rutas[$k][1] -eq 'xlsx') { $d = New-Object Windows.Forms.OpenFileDialog -Property @{ Title = 'Plantilla FAYC'; Filter = 'Excel (*.xlsx)|*.xlsx' }; if ($d.ShowDialog($form) -eq 'OK') { $t.Text = $d.FileName } }
    else { $d = New-Object Windows.Forms.FolderBrowserDialog -Property @{ Description = $script:rutas[$k][0]; SelectedPath = $(if ($t.Text) { $t.Text } else { '' }) }; if ($d.ShowDialog($form) -eq 'OK') { $t.Text = $d.SelectedPath } } })
  $script:rutTxt[$k] = $t; $y += 32
}
$btnRut = Add-Ctl (New-Btn 'Guardar rutas' $Pal.Azul) $cRut; $btnRut.SetBounds(200, $y + 4, 170, 34)
$btnRutEq = Add-Ctl (New-Btn 'Revisar equipo' $Pal.Head -Contorno) $cRut; $btnRutEq.SetBounds(378, $y + 4, 150, 34)
$btnRutEq.Add_Click({ Show-Equipo })

# --- mapa de CASA ---
$cMap = Add-Ctl (New-Card 'Mapa de CASA (para usar la app con otro CASA u otra empresa)') $cf; $cMap.Width = 1100; $cMap.Height = 520
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Da "Mapear con F8". Para cada paso abre en CASA lo que dice la columna "Qué hacer en CASA", pon el mouse ENCIMA del botón o del elemento del menú abierto y presiona F8: la app graba el ID o la posición y pasa al siguiente. No hace falta dar clic (en Cierre e Imprimir NO le des clic). Al final da "Guardar mapa".'
  Location = '14,36'; Size = '1070,36'; ForeColor = $Pal.Texto; Anchor = 'Top,Left,Right' }) $cMap | Out-Null
$btnMapIr = Add-Ctl (New-Btn 'Mapear con F8' $Pal.Verde) $cMap; $btnMapIr.SetBounds(14, 78, 160, 34)
$btnMapStop = Add-Ctl (New-Btn 'Detener' $Pal.Rojo -Contorno) $cMap; $btnMapStop.SetBounds(182, 78, 100, 34); $btnMapStop.Enabled = $false
$btnMapProb = Add-Ctl (New-Btn 'Probar mapa' $Pal.Head -Contorno) $cMap; $btnMapProb.SetBounds(290, 78, 130, 34)
$btnMapFab = Add-Ctl (New-Btn 'Valores de fábrica' $Pal.Gris -Contorno) $cMap; $btnMapFab.SetBounds(428, 78, 160, 34)
$btnMapSave = Add-Ctl (New-Btn 'Guardar mapa' $Pal.Azul) $cMap; $btnMapSave.SetBounds(596, 78, 150, 34)
$chkMapPc = Add-Ctl (New-Object Windows.Forms.CheckBox -Property @{ Text = "Solo para esta PC ($CasaEquipo)"; Checked = $true; AutoSize = $true; Location = '756,86'; Font = $F.Neg; ForeColor = $Pal.Texto }) $cMap
# qué mapa usa esta PC, y volver al general
$lblMapOrig = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; AutoSize = $true; Location = '560,13'; ForeColor = $Pal.Gris }) $cMap
$lnkMapGen = Add-Ctl (New-Object Windows.Forms.LinkLabel -Property @{ Text = 'Usar el mapa general en esta PC'; AutoSize = $true; Location = '820,13'; Visible = $false }) $cMap
function Update-MapaOrigen { $o = Get-CasaMapaOrigen; $lblMapOrig.Text = "Esta PC usa: $(switch ($o) { 'esta PC' { "su propio mapa ($CasaEquipo)" } 'general' { 'el mapa general de la empresa' } default { 'los valores de fábrica' } })"; $lnkMapGen.Visible = $o -eq 'esta PC'; $lnkMapGen.Left = $lblMapOrig.Right + 12 }
$lnkMapGen.Add_LinkClicked({
  if ([Windows.Forms.MessageBox]::Show($form, "¿Quito el mapa propio de $CasaEquipo? Esta PC volverá a usar el mapa general.", 'Mapa de CASA', 'YesNo', 'Question') -ne 'Yes') { return }
  if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }; $script:cfg.equipos[$CasaEquipo]['mapa'] = @{}
  Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig; $Global:CasaMapa = Get-CasaMapa; Show-Mapa $CasaMapa; Update-MapaOrigen; Log "Mapa propio de $CasaEquipo quitado: usa el general"
})
$lblMap = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; Location = '14,122'; Size = '1070,22'; Font = $F.Neg; ForeColor = $Pal.Azul; Anchor = 'Top,Left,Right' }) $cMap
$mGrid = Add-Ctl (New-Object Windows.Forms.DataGridView -Property @{ Location = '14,150'; Size = '1072,356'; Anchor = 'Top,Left,Right,Bottom'; AllowUserToAddRows = $false; AllowUserToDeleteRows = $false; RowHeadersVisible = $false
  SelectionMode = 'FullRowSelect'; MultiSelect = $false; BackgroundColor = [Drawing.Color]::White; BorderStyle = 'None'; AutoSizeColumnsMode = 'Fill'; EnableHeadersVisualStyles = $false
  ColumnHeadersHeight = 30; ColumnHeadersHeightSizeMode = 'DisableResizing'; GridColor = $Pal.Linea; CellBorderStyle = 'SingleHorizontal'; AutoSizeRowsMode = 'AllCells' }) $cMap
$mGrid.ColumnHeadersDefaultCellStyle.BackColor = $Pal.Head; $mGrid.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White; $mGrid.ColumnHeadersDefaultCellStyle.Font = $F.Neg
$mGrid.DefaultCellStyle.WrapMode = 'True'; $mGrid.DefaultCellStyle.SelectionBackColor = Hex '#DBEAFE'; $mGrid.DefaultCellStyle.SelectionForeColor = $Pal.Texto
foreach ($col in @(@('k', 'Clave', 1), @('paso', 'Paso', 22), @('que', 'Qué hacer en CASA', 50), @('val', 'Valor', 12), @('est', 'Estado', 16))) { $i = $mGrid.Columns.Add($col[0], $col[1]); $mGrid.Columns[$i].FillWeight = $col[2]; $mGrid.Columns[$i].SortMode = 'NotSortable'; $mGrid.Columns[$i].ReadOnly = $col[0] -ne 'val' }
$mGrid.Columns['k'].Visible = $false; $mGrid.Columns['val'].DefaultCellStyle.Font = $F.Neg

# Pasos del mapa. t: menuP = elemento del menú principal, menuV = elemento del menú del botón Vucem, win = botón/renglón (posición dentro de "w"), auto/manual = no se graba con F8.
# w devuelve el control que usa CASA automático para ese clic (así la posición grabada es la misma que se usará).
function Find-CVent([string]$cls) { $h = Get-CPopups | Where-Object { [CasaWin]::Cls($_) -eq $cls } | Select-Object -First 1; if ($h) { return [IntPtr]$h }; Get-CChild $cls }
function Get-CRegCoveGrid { $w = Find-CVent 'TFm_RegCOVE'; if ($w -eq [IntPtr]::Zero) { return [IntPtr]::Zero }; [IntPtr]([CasaWin]::Kids($w) | Where-Object { [CasaWin]::Cls($_) -eq 'TDBGrid' } | ForEach-Object { $r = New-Object CA+R; [void][CA]::GetWindowRect($_, [ref]$r); [pscustomobject]@{ H = $_; A = $r.B - $r.T } } | Sort-Object A -Descending | Select-Object -First 1).H }
function Get-CRegCoveTb { $w = Find-CVent 'TFm_RegCOVE'; if ($w -eq [IntPtr]::Zero) { return [IntPtr]::Zero }; Find-CCtl $w 'TToolBar' }
function Get-CAcuseTb { $w = Find-CVent 'TFm_BMManValVU'; if ($w -eq [IntPtr]::Zero) { return [IntPtr]::Zero }; $t = Find-CToolbar $w 'Acuse VU'; if ($t) { $t.H } else { [IntPtr]::Zero } }
function Get-COpcPanel { foreach ($c in 'TFm_CopImp', 'TFm_opcimpcta') { $w = Find-CVent $c; if ($w -ne [IntPtr]::Zero) { return (Get-COptPanel $w) } }; [IntPtr]::Zero }
$script:pasosMapa = @(
  @{ k = 'catalogo'; n = 'Menú: Catálogo'; q = 'Abre el menú Pedimentos y pon el mouse sobre "Catálogo"'; t = 'menuP' }
  @{ k = 'impresion'; n = 'Menú: Impresión'; q = 'Menú Pedimentos: mouse sobre "Impresión"'; t = 'menuP' }
  @{ k = 'simplificada'; n = 'Menú: Impresión Simplificada'; q = 'Menú Pedimentos: mouse sobre "Impresión Simplificada"'; t = 'menuP' }
  @{ k = 'cierre'; n = 'Menú: Cierre (se bloquea)'; q = 'Menú Pedimentos: mouse sobre "Cierre" — NO le des clic. Sirve para que la app nunca lo mande.'; t = 'menuP' }
  @{ k = 'vucemRespCovePos'; n = 'Vucem: Respuesta COVE (posición)'; q = 'En el Catálogo selecciona un pedimento, abre el botón Vucem y pon el mouse sobre "Respuesta COVE" (se graba su lugar en el menú, 0 = el primero)'; t = 'menuV' }
  @{ k = 'vucemManifPos'; n = 'Vucem: Registrar Manifiesto (posición)'; q = 'Con una IMPORTACIÓN seleccionada: botón Vucem, mouse sobre "Registrar Manifiesto de valor Electrónico"'; t = 'menuV' }
  @{ k = 'coveRenglon'; n = 'Registro COVE: 1.er renglón'; q = 'Abre Vucem → Respuesta COVE; mouse sobre el PRIMER renglón de la tabla "Fol. Fact."'; t = 'win'; v = 'la tabla Fol. Fact. de Registro COVE'; w = { Get-CRegCoveGrid } }
  @{ k = 'coveAlto'; n = 'Registro COVE: alto del renglón'; q = '(píxeles entre renglones; normalmente 18; se escribe a mano si hace falta)'; t = 'manual' }
  @{ k = 'coveTodos'; n = 'Registro COVE: botón Todos'; q = 'En Registro COVE: mouse sobre el botón "Todos" (debajo de Imprimir)'; t = 'win'; v = 'el panel de botones de Registro COVE'; w = { $tb = Get-CRegCoveTb; if ($tb -eq [IntPtr]::Zero) { $tb } else { [IntPtr][CasaWin]::GetParent($tb) } } }
  @{ k = 'coveImpFlecha'; n = 'Registro COVE: flechita de Imprimir'; q = 'En Registro COVE: mouse sobre la flechita a la derecha de "Imprimir"'; t = 'win'; v = 'la barra de Imprimir de Registro COVE'; w = { Get-CRegCoveTb } }
  @{ k = 'copias'; n = 'Impresión: botón Copias'; q = 'Abre Pedimentos → Impresión y pon un pedimento en Selección; mouse sobre el botón "Copias" (panel izquierdo)'; t = 'win'; v = 'el panel izquierdo de Impresión'; w = { $x = Get-CChild 'TFm_SelPedIm'; if ($x -eq [IntPtr]::Zero) { $x } else { Get-CSidePanel $x } } }
  @{ k = 'copiasConfig'; n = 'Copias: configurar impresora'; q = 'Da clic en Copias; en "Elija las Copias" mouse sobre el botón de configurar la impresora'; t = 'win'; v = 'los botones de "Elija las Copias"'; w = { $x = Find-CVent 'TFm_ImpVarCopias'; if ($x -eq [IntPtr]::Zero) { $x } else { Find-CCtl $x 'TPanel' } } }
  @{ k = 'copiasImprimir'; n = 'Copias: Imprimir'; q = 'En "Elija las Copias": mouse sobre "Imprimir" — NO le des clic'; t = 'win'; v = 'los botones de "Elija las Copias"'; w = { $x = Find-CVent 'TFm_ImpVarCopias'; if ($x -eq [IntPtr]::Zero) { $x } else { Find-CCtl $x 'TPanel' } } }
  @{ k = 'simpOpciones'; n = 'Simplificada: botón Opciones'; q = 'Abre Impresión Simplificada con un pedimento en Selección; mouse sobre "Opciones" (panel izquierdo)'; t = 'win'; v = 'el panel izquierdo de Impresión Simplificada'; w = { $x = Get-CChild 'TFm_SelPedIm'; if ($x -eq [IntPtr]::Zero) { $x } else { Get-CSidePanel $x } } }
  @{ k = 'exportar'; n = 'Opciones de impresión: Exportar'; q = 'Da clic en Opciones; en "Opciones de Impresión" mouse sobre el botón "Exportar"'; t = 'win'; v = 'la barra de Opciones de Impresión'; w = { Get-COpcPanel } }
  @{ k = 'acuseVU'; n = 'Manifestación: Acuse VU'; q = 'Abre Vucem → Registrar Manifiesto (importación enviada); mouse sobre "Acuse VU"'; t = 'win'; v = 'la barra de Acuse VU de la Manifestación'; w = { Get-CAcuseTb } }
  @{ k = 'acuseVUFlecha'; n = 'Manifestación: flechita de Acuse VU'; q = 'En la Manifestación: mouse sobre la flechita a la derecha de "Acuse VU"'; t = 'win'; v = 'la barra de Acuse VU de la Manifestación'; w = { Get-CAcuseTb } }
)
function Get-FilaMapa([string]$k) { foreach ($r in $mGrid.Rows) { if ($r.Cells['k'].Value -eq $k) { return $r } }; $null }
function Set-EstMapa($row, [string]$t, $color) { $row.Cells['est'].Value = $t; $row.Cells['est'].Style.ForeColor = $color; $row.Cells['est'].Style.Font = $F.Neg }
function Show-Mapa($m) {
  $mGrid.Rows.Clear()
  foreach ($p in $script:pasosMapa) { $i = $mGrid.Rows.Add($p.k, $p.n, $p.q, "$($m[$p.k])", ''); if ($p.t -in 'auto', 'manual') { $mGrid.Rows[$i].Cells['que'].Style.ForeColor = $Pal.Gris } }
}
# los módulos de CASA automático (casa-auto.ps1) se cargan aquí solo cuando se usan
function Import-CasaAutoUI {
  if (Get-Command Get-CMain -ErrorAction SilentlyContinue) { return }
  New-Module -Name CasaAutoUI -ScriptBlock { param($r) . "$r\casa-auto.ps1"; Export-ModuleMember -Function * } -ArgumentList $PSScriptRoot | Import-Module -Global -DisableNameChecking
}
$tMapa = New-Object Windows.Forms.Timer -Property @{ Interval = 200 }
function Stop-Mapeo([string]$msg) { [CMapa]::Parar(); $tMapa.Stop(); $btnMapIr.Enabled = $true; $btnMapStop.Enabled = $false; if ($msg) { $lblMap.Text = $msg } }
function Select-PasoMapa([int]$desde) {
  for ($i = $desde; $i -lt $mGrid.Rows.Count; $i++) { if ($script:pasosMapa[$i].t -notin 'auto', 'manual') { $mGrid.CurrentCell = $mGrid.Rows[$i].Cells['paso']; $lblMap.ForeColor = $Pal.Azul; $lblMap.Text = "Paso $($i + 1): $($script:pasosMapa[$i].q)  →  F8"; return $true } }
  $false
}
function Resolve-Captura([string]$r) {
  $row = $mGrid.CurrentRow; if (-not $row) { return }; $paso = $script:pasosMapa[$row.Index]
  $p = $r -split '\|'
  $mal = { param($m) $lblMap.ForeColor = $Pal.Rojo; $lblMap.Text = "✖ $m  (vuelve a apuntar y presiona F8)" }
  if ($p[0] -eq 'error') { Stop-Mapeo "✖ $($p[1])"; return }
  if ([uint32]$p[-1] -ne (Get-CPid)) { & $mal 'Eso no es CASA'; return }
  if ($paso.t -in 'menuP', 'menuV') {
    if ($p[0] -ne 'menu') { & $mal 'Abre el menú y pon el mouse sobre el elemento'; return }
    $id = [uint32]$p[2]; if ($id -eq [uint32]::MaxValue) { & $mal 'Ese elemento abre un submenú; apunta al elemento final'; return }
    $esP = [CMapa]::EsPrincipal((Get-CMain), [IntPtr][long]$p[1])
    if ($paso.t -eq 'menuP' -and -not $esP) { & $mal 'Ese no es el menú principal (Pedimentos)'; return }
    if ($paso.t -eq 'menuV' -and $esP) { & $mal 'Ese es el menú principal; este paso es del botón Vucem del Catálogo'; return }
    # se graba la POSICIÓN: menú principal "menú/elemento" (p. ej. 4/0); menú Vucem solo el elemento. Los números cambian entre PCs.
    $val = if ($paso.t -eq 'menuV') { "$([int]$p[3])" } else { $top = [CMapa]::TopDe((Get-CMain), [IntPtr][long]$p[1]); if ($top -lt 0) { & $mal 'Apunta a un elemento del menú que se abre desde la barra (Pedimentos)'; return }; "$top/$([int]$p[3])" }
    if ($paso.t -eq 'menuP' -and $paso.k -ne 'cierre' -and "$((Get-FilaMapa 'cierre').Cells['val'].Value)" -eq $val) { & $mal 'Ese es el lugar de Cierre'; return }
  } else {
    if ($p[0] -ne 'win') { & $mal 'Cierra el menú y apunta al botón'; return }
    $esp = try { [IntPtr](& $paso.w) } catch { [IntPtr]::Zero }
    if ($esp -eq [IntPtr]::Zero) { & $mal "No encontré abierta en CASA: $($paso.v). Ábrela primero"; return }
    if ([long]$p[1] -ne $esp.ToInt64()) { & $mal "Ese punto está en otro control ($($p[4])); apunta dentro de $($paso.v)"; return }
    $val = "$($p[2]),$($p[3])"
  }
  $row.Cells['val'].Value = $val; Set-EstMapa $row '✔ grabado' $Pal.Verde
  if (-not (Select-PasoMapa ($row.Index + 1))) { Stop-Mapeo '✔ Terminó el mapeo. Revisa los valores y da "Guardar mapa".'; $lblMap.ForeColor = $Pal.Verde }
}
$tMapa.Add_Tick({ $r = $null; while ([CMapa]::Q.TryDequeue([ref]$r)) { try { Resolve-Captura $r } catch { $lblMap.ForeColor = $Pal.Rojo; $lblMap.Text = "✖ $($_.Exception.Message)" } } })
$btnMapIr.Add_Click({
  if ($script:bg) { [void][Windows.Forms.MessageBox]::Show($form, "Espera a que termine: $($script:bg.Que)", 'Mapear CASA'); return }
  $lblMap.ForeColor = $Pal.Azul; $lblMap.Text = 'Cargando…'; [Windows.Forms.Application]::DoEvents()
  try { Import-CasaAutoUI } catch { $lblMap.Text = "✖ $($_.Exception.Message)"; return }
  if (-not (Get-CPid) -or (Get-CMain) -eq [IntPtr]::Zero) { $lblMap.ForeColor = $Pal.Rojo; $lblMap.Text = '✖ Abre CASA y entra (la ventana principal debe estar visible)'; return }
  $i = if ($mGrid.CurrentRow) { $mGrid.CurrentRow.Index } else { 0 }
  if ($script:pasosMapa[$i].t -in 'auto', 'manual') { $i = 0 }
  [CMapa]::Iniciar(); $tMapa.Start(); $btnMapIr.Enabled = $false; $btnMapStop.Enabled = $true
  [void](Select-PasoMapa $i)
})
$btnMapStop.Add_Click({ Stop-Mapeo 'Mapeo detenido.' })
$btnMapFab.Add_Click({ Show-Mapa $CasaMapaFab; $lblMap.ForeColor = $Pal.Gris; $lblMap.Text = 'Valores de fábrica (A&C, patente 1664). Da "Guardar mapa" para usarlos.' })
$btnMapProb.Add_Click({
  try { Import-CasaAutoUI } catch { $lblMap.Text = "✖ $($_.Exception.Message)"; return }
  if ((Get-CMain) -eq [IntPtr]::Zero) { $lblMap.ForeColor = $Pal.Rojo; $lblMap.Text = '✖ Abre CASA para probar el mapa'; return }
  $malos = 0; $vistos = @{}
  foreach ($k in 'catalogo', 'impresion', 'simplificada', 'cierre') {
    $row = Get-FilaMapa $k; $v = "$($row.Cells['val'].Value)" -split '/'
    $id = if ($v.Count -eq 2) { [CMapa]::IdEn((Get-CMain), [int]$v[0], [int]$v[1]) } else { -1 }
    if ($id -gt 0) { Set-EstMapa $row "✔ en esta PC es el comando $id" $Pal.Verde; $vistos[$k] = $id } else { Set-EstMapa $row '✖ no existe en este menú' $Pal.Rojo; $malos++ }
  }
  if (@($vistos.Values | Select-Object -Unique).Count -ne $vistos.Count) { $malos++; $lblMap.ForeColor = $Pal.Rojo; $lblMap.Text = '✖ Hay dos pasos del menú en el mismo lugar'; return }
  foreach ($row in $mGrid.Rows) { if ($row.Cells['k'].Value -notin 'catalogo', 'impresion', 'simplificada', 'cierre' -and -not "$($row.Cells['est'].Value)") { Set-EstMapa $row 'se revisa al grabar con F8' $Pal.Gris } }
  $lblMap.ForeColor = $(if ($malos) { $Pal.Rojo } else { $Pal.Verde }); $lblMap.Text = $(if ($malos) { "✖ $malos comando(s) del menú no existen en este CASA: vuelve a mapearlos" } else { '✔ Los comandos del menú existen en este CASA. Los botones se comprueban al grabarlos con F8 (o con un expediente de prueba).' })
})
$btnMapSave.Add_Click({
  $m = @{}; $err = @()
  foreach ($row in $mGrid.Rows) {
    $k = $row.Cells['k'].Value; $v = "$($row.Cells['val'].Value)".Trim()
    if ("$($CasaMapaFab[$k])" -match '/') { if ($v -notmatch '^\d{1,2}/\d{1,3}$') { $err += $row.Cells['paso'].Value }; $m[$k] = $v }
    elseif ("$($CasaMapaFab[$k])" -match ',') { if ($v -notmatch '^\d{1,4},\d{1,4}$') { $err += $row.Cells['paso'].Value }; $m[$k] = $v }
    else { if ($v -notmatch '^\d{1,6}$') { $err += $row.Cells['paso'].Value }; $m[$k] = [int]$v } }
  if ($err) { [void][Windows.Forms.MessageBox]::Show($form, "Valores inválidos en:`n`n" + ($err -join "`n") + "`n`nMenú principal: menú/elemento (p. ej. 4/0). Vucem y alto: un número. Botones: x,y (p. ej. 26,410).", 'Guardar mapa', 'OK', 'Warning'); return }
  $ids = @('catalogo', 'impresion', 'simplificada') | ForEach-Object { $m[$_] }
  if ($ids -contains $m['cierre']) { [void][Windows.Forms.MessageBox]::Show($form, 'Cierre no puede estar en el mismo lugar que Catálogo, Impresión o Simplificada.', 'Guardar mapa', 'OK', 'Warning'); return }
  $soloPc = $chkMapPc.Checked
  $q = if ($soloPc) { "¿Guardo este mapa SOLO para esta PC ($CasaEquipo)? Las demás PCs siguen con el suyo." } else { '¿Guardo este mapa como el GENERAL? Lo usarán todas las PCs que no tengan mapa propio.' }
  if ([Windows.Forms.MessageBox]::Show($form, $q, 'Guardar mapa', 'YesNo', 'Question') -ne 'Yes') { return }
  if ($soloPc) { if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }; $script:cfg.equipos[$CasaEquipo]['mapa'] = $m } else { $script:cfg.mapa = $m }
  Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig; $Global:CasaMapa = Get-CasaMapa; Update-MapaOrigen
  $lblMap.ForeColor = $Pal.Verde; $lblMap.Text = $(if ($soloPc) { "✔ Mapa guardado solo para $CasaEquipo. CASA automático lo usa desde el siguiente pedimento." } else { '✔ Mapa general guardado. CASA automático lo usa desde el siguiente pedimento.' }); Log $(if ($soloPc) { "✔ Mapa de CASA guardado para $CasaEquipo" } else { '✔ Mapa general de CASA guardado' })
})

# --- acerca de ---
$cAcer = Add-Ctl (New-Card 'Acerca de') $cf; $cAcer.Width = 1100; $cAcer.Height = 130
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = "Expedito  v$($script:verIni)"; Location = '14,40'; AutoSize = $true; Font = $F.Big; ForeColor = $Pal.Texto }) $cAcer | Out-Null
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Hecha por Paulo Castañeda · © 2026. Todos los derechos reservados. Uso bajo licencia.'; Location = '14,72'; AutoSize = $true; Font = $F.Neg; ForeColor = $Pal.Head }) $cAcer | Out-Null
Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = "Llave de licencias: huella $($CasaLicPub.huella)  ·  Lee los PDF con PdfPig (licencia Apache 2.0) y el texto de pantalla con el OCR de Windows."; Location = '14,98'; AutoSize = $true; ForeColor = $Pal.Gris }) $cAcer | Out-Null

function Fill-Cfg {
  foreach ($k in $script:empTxt.Keys) { $script:empTxt[$k].Text = $CasaEmpresa[$k] }
  $e = Get-CasaEquipoCfg
  $auto = @{ raiz = $CasaRoot; casa = (Find-CasaWinDir); vucem = $CasaVucem; transmit = $CasaTransmit; plantilla = $CasaPlantilla }
  foreach ($k in $script:rutTxt.Keys) { $script:rutTxt[$k].Text = "$($e[$k])"; Set-Cue $script:rutTxt[$k] "Automático: $($auto[$k])" }
  if (-not $mGrid.Rows.Count) { Show-Mapa $CasaMapa }; Update-MapaOrigen
  if (-not $gRec.IsCurrentCellInEditMode -and -not $gGas.IsCurrentCellInEditMode) { $script:cfg = Get-CasaConfig; Fill-Fay }
}
function Update-Rutas { $Global:CasaRoot = Find-CasaRoot; $Global:CasaVucem = Find-CasaVucem; $Global:CasaTransmit = Find-CasaTransmit; $Global:CasaPlantilla = Find-CasaPlantilla }
$btnEmp.Add_Click({
  $n = [ordered]@{}; foreach ($k in $script:empTxt.Keys) { $n[$k] = $script:empTxt[$k].Text.Trim() }
  if ($n.patente -notmatch '^\d{4}$' -or $n.aduana -notmatch '^\d{3}$') { [void][Windows.Forms.MessageBox]::Show($form, 'Patente: 4 dígitos. Aduana: 3 dígitos.', 'Empresa', 'OK', 'Warning'); return }
  if ($n.prefijo -notmatch '^[A-Z0-9]+-$') { [void][Windows.Forms.MessageBox]::Show($form, 'El prefijo de referencia va en mayúsculas y termina en guion (p. ej. AYC26-).', 'Empresa', 'OK', 'Warning'); return }
  $n.tablero = $n.tablero.ToLower(); if ($n.tablero -notmatch '^[a-z0-9_-]*$') { [void][Windows.Forms.MessageBox]::Show($form, 'Tablero: solo minúsculas, números, guion o guion bajo (p. ej. demo). Vacío = el de la patente.', 'Empresa', 'OK', 'Warning'); return }
  if ([Windows.Forms.MessageBox]::Show($form, "¿Guardo los datos de la empresa? Los usarán todas las PCs.`n`n$($n.nombre) · patente $($n.patente) · aduana $($n.aduana)`nReferencia: $($n.prefijo)8031 · carpeta: $($n.carpeta)`nTablero de pendientes: $(if ($n.tablero) { $n.tablero } else { 'el de la patente' })", 'Empresa', 'YesNo', 'Question') -ne 'Yes') { return }
  $script:cfg.empresa = $n; Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig
  $Global:CasaEmpresa = Get-CasaEmpresa; $Global:CasaPat = $CasaEmpresa.patente; Update-Rutas; Set-Subtitulo; Fill-Cfg; Update-Licencia; Open-TableroUrl
  Log "✔ Empresa guardada: patente $($CasaEmpresa.patente), aduana $($CasaEmpresa.aduana), referencia $($CasaEmpresa.prefijo)…"
})
$btnRut.Add_Click({
  $mal = @(); foreach ($k in $script:rutTxt.Keys) { $v = $script:rutTxt[$k].Text.Trim(); if ($v -and -not (Test-Path -LiteralPath $v)) { $mal += "$($script:rutas[$k][0]): $v" } }
  if ($mal -and [Windows.Forms.MessageBox]::Show($form, "Estas rutas no existen en esta PC:`n`n$($mal -join "`n")`n`n¿Las guardo de todos modos?", 'Rutas', 'YesNo', 'Warning') -ne 'Yes') { return }
  if (-not $script:cfg.equipos[$CasaEquipo]) { $script:cfg.equipos[$CasaEquipo] = @{} }
  foreach ($k in $script:rutTxt.Keys) { $script:cfg.equipos[$CasaEquipo][$k] = $script:rutTxt[$k].Text.Trim() }
  Save-CasaConfig $script:cfg; $script:cfg = Get-CasaConfig; Update-Rutas; Fill-Cfg
  Log "✔ Rutas de $CasaEquipo guardadas. Expedientes: $CasaRoot · TRANSMIT: $CasaTransmit"
})
function Set-AcomodoCfg {
  $cf.SuspendLayout(); $cf.AutoScrollPosition = New-Object Drawing.Point 0, 0
  $w = [Math]::Max(760, $cf.ClientSize.Width - 24)
  $cLic.SetBounds(12, 12, $w, 168); $cEmp.SetBounds(12, $cLic.Bottom + 12, $w, 150); $cFay.SetBounds(12, $cEmp.Bottom + 12, $w, 330); $cRut.SetBounds(12, $cFay.Bottom + 12, $w, 250)
  $cMap.SetBounds(12, $cRut.Bottom + 12, $w, [Math]::Max(460, $cf.ClientSize.Height - $cRut.Bottom - 24))
  $cAcer.SetBounds(12, $cMap.Bottom + 12, $w, 130)
  $cf.ResumeLayout()
}
$cf.Add_Resize({ if ($cf.Visible) { Set-AcomodoCfg } })
$form.Add_FormClosing({ try { [CMapa]::Parar() } catch {} })

# ---------- pestaña Pendientes: el tablero (web) dentro de la app, con WebView2 ----------
# El tablero es tablero\index.html servido como https://expedito.local/ (datos en Firebase: empresas/<Get-CasaTablero>).
# "⚙️ Armar expediente" en un pendiente manda {tipo:'armar'}; aquí corre Invoke-CasaPedimento y el avance regresa
# al tablero como {tipo:'avance'} / {tipo:'fin'} (el tablero guarda el resultado en el pendiente).
$pf = Add-Ctl (New-Object Windows.Forms.Panel -Property @{ Dock = 'Fill'; BackColor = $Pal.Fondo; Visible = $false })
$lblPf = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = 'Cargando el tablero…'; Dock = 'Fill'; TextAlign = 'MiddleCenter'; ForeColor = $Pal.Gris; Font = $F.Tit }) $pf
$script:wv = $null; $script:tabPend = @{}   # pedimento -> @{ id (del pendiente); est; fal; res }
function Get-TableroUrl { $tb = Get-CasaTablero; $nom = if ($tb -eq 'demo') { 'Agencia Demo' } else { $CasaEmpresa.nombre }   # la demo no lleva el nombre de quien la enseña
  # v = versión y fecha del archivo: si cambia el tablero, WebView2 no usa el que tenía en caché
  $vt = "$($script:verIni)-$((Get-Item -LiteralPath "$PSScriptRoot\tablero\index.html" -ErrorAction SilentlyContinue).LastWriteTimeUtc.Ticks)"
  "https://expedito.local/index.html?v=$vt&empresa=$([uri]::EscapeDataString($tb))&nombre=$([uri]::EscapeDataString($nom))$(if (-not (Test-Modulo 'expediente')) { '&casa=0' })" }
function Open-TableroUrl { if ($script:wv -and $script:wv.CoreWebView2) { $script:wv.CoreWebView2.Navigate((Get-TableroUrl)) } }
function Send-Tablero($o) { if ($script:wv -and $script:wv.CoreWebView2) { try { $script:wv.CoreWebView2.PostWebMessageAsJson(($o | ConvertTo-Json -Compress)) } catch { Log "⚠ Tablero: $($_.Exception.Message)" } } }
function Start-Tablero {
  if ($script:wv) { return }
  $lib = "$PSScriptRoot\lib\webview2"
  try {
    if (-not (Test-Path -LiteralPath "$PSScriptRoot\tablero\index.html")) { throw "Falta $PSScriptRoot\tablero\index.html" }
    Add-Type -Path "$lib\Microsoft.Web.WebView2.Core.dll"; Add-Type -Path "$lib\Microsoft.Web.WebView2.WinForms.dll"
    [Microsoft.Web.WebView2.Core.CoreWebView2Environment]::SetLoaderDllFolderPath("$lib\runtimes\win-$(if ([Environment]::Is64BitProcess) { 'x64' } else { 'x86' })\native")
    $wv = New-Object Microsoft.Web.WebView2.WinForms.WebView2 -Property @{ Dock = 'Fill'; Visible = $false }
    # datos del navegador (sesión de Firebase) en esta PC, no en la carpeta de la app (que comparte OneDrive)
    $wv.CreationProperties = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties -Property @{ UserDataFolder = (Join-Path $env:LOCALAPPDATA 'Expedito\WebView2') }
    $wv.Add_CoreWebView2InitializationCompleted({ param($s, $e)
      if (-not $e.IsSuccess) { $lblPf.Text = "No pude abrir el tablero:`n$($e.InitializationException.Message)"; return }
      $s.CoreWebView2.SetVirtualHostNameToFolderMapping('expedito.local', "$PSScriptRoot\tablero", [Microsoft.Web.WebView2.Core.CoreWebView2HostResourceAccessKind]::Allow)
      $s.CoreWebView2.Settings.AreDevToolsEnabled = $script:esPrueba
      $s.CoreWebView2.add_NewWindowRequested({ param($x, $ev) $ev.Handled = $true; try { Start-Process $ev.Uri } catch {} })   # enlaces: navegador normal
      $s.CoreWebView2.Navigate((Get-TableroUrl)); $s.Visible = $true; $lblPf.Visible = $false
    })
    $wv.Add_WebMessageReceived({ param($s, $e) try { Receive-Tablero ($e.WebMessageAsJson | ConvertFrom-Json) } catch { Log "⚠ Tablero: $($_.Exception.Message)" } })
    Add-Ctl $wv $pf | Out-Null; $wv.BringToFront(); $script:wv = $wv
    [void]$wv.EnsureCoreWebView2Async($null)
  } catch { $lblPf.Text = "No pude abrir el tablero:`n$($_.Exception.Message)"; Log "⚠ Tablero: $($_.Exception.Message)" }
}
# {tipo:'armar', items:[{id, ped}]} = uno o varios pendientes. {tipo:'detener'} = parar después del actual.
# Con el módulo lote van a la pestaña Varios pedimentos (su tabla, y Esta PC / El remoto); sin él, uno solo en un trabajo aparte.
$script:ctlTab = [hashtable]::Synchronized(@{ stop = $false })
$script:tabFin = @{}   # pedimento -> último estado final que se le avisó al tablero
$script:tabIds = @{}   # pedimento -> id del pendiente (sigue después de terminar: la FAYC del lote puede dejarlo Completo)
function Invoke-Clic($b) { [void]$b.GetType().GetMethod('OnClick', [Reflection.BindingFlags]'Instance,NonPublic').Invoke($b, @([EventArgs]::Empty)) }   # aunque la pestaña no se vea
function Receive-Tablero($m) {
  if ($m.tipo -eq 'detenerYa') { if ($script:bg -and $script:bg.Que -notlike 'Remoto*') { Stop-Trabajo -Preguntar } elseif ($rbRem.Checked -and $script:remSeg.Count) { Invoke-Clic $btnLoteStop }; return }   # el remoto no se corta desde aquí: solo se quitan los que no empiezan
  if ($m.tipo -eq 'detener') {
    if ($script:loteCorre -or ($rbRem.Checked -and $script:remSeg.Count)) { Invoke-Clic $btnLoteStop } else { $script:ctlTab.stop = $true; Log '⚠ Tablero: el lote se detendrá al terminar el pedimento actual' }; return }
  if ($m.tipo -ne 'armar') { return }
  $items = @($m.items | Where-Object { "$($_.ped)" -match '^\d{7}$' }); if (-not $items.Count) { return }
  $no = if (-not $script:lic.Ok) { "Expedito está bloqueado: $($script:lic.Motivo)" }
        elseif (-not (Test-Modulo 'expediente')) { 'Tu licencia no incluye el módulo Expediente (CASA automático).' }
        elseif ($items.Count -gt 1 -and -not (Test-Modulo 'lote')) { 'Tu licencia no incluye Varios pedimentos (lote): manda los pendientes uno por uno.' }
        elseif ($script:bg -and -not ((Test-Modulo 'lote') -and $rbRem.Checked)) { "Expedito está ocupado ($($script:bg.Que)). Inténtalo cuando termine." }
  if ($no) { Send-Tablero @{ tipo = 'rechazo'; ids = @($items | ForEach-Object { "$($_.id)" }); motivo = $no }; return }
  if (Test-Modulo 'lote') {
    $peds = @(); foreach ($x in $items) { $p = "$($x.ped)"; if ($peds -notcontains $p) { $peds += $p; $script:tabIds[$p] = "$($x.id)"; $script:tabPend[$p] = @{ id = "$($x.id)"; est = ''; fal = ''; res = '' } } }
    Log "== Tablero → Varios pedimentos ($(if ($rbRem.Checked) { 'en el remoto' } else { 'en esta PC' })): $($peds -join ', ')"
    $txtLote.Text = $peds -join "`r`n"; Invoke-Clic $btnLoteIr
    if (-not ($script:loteCorre -or @($peds | Where-Object { $script:remSeg.Contains($_) }).Count)) {   # no arrancó (canceló el aviso del remoto, etc.)
      foreach ($p in $peds) { $script:tabPend.Remove($p) }
      Send-Tablero @{ tipo = 'rechazo'; ids = @($items | ForEach-Object { "$($_.id)" }); motivo = 'No se mandaron: revisa la pestaña Varios pedimentos en Expedito.' } }
    return
  }
  $peds = @(); foreach ($x in $items) { $p = "$($x.ped)"; if ($peds -notcontains $p) { $peds += $p; $script:tabPend[$p] = @{ id = "$($x.id)"; est = ''; fal = ''; res = '' } } }
  $script:ctlTab.stop = $false
  Log "== Tablero: $(if ($peds.Count -gt 1) { "lote de $($peds.Count) pedimentos: $($peds -join ', ')" } else { "armar expediente $($peds[0])$(if ($items[0].cliente) { " ($($items[0].cliente))" })" })"
  Start-Trabajo $(if ($peds.Count -gt 1) { "Lote del tablero ($($peds.Count))" } else { "Expediente $($peds[0]) (tablero)" }) {
    $n = 0
    foreach ($pp in $a.peds) {
      $n++
      if ($a.ctl.stop) { $global:ColaApp.Enqueue("@@TF|$pp|No iniciado (detenido)"); continue }
      if ($a.peds.Count -gt 1) { $global:ColaApp.Enqueue("@@ESTADO|Tablero: $n de $($a.peds.Count) ($pp)") }
      $lg = { param($m) $global:ColaApp.Enqueue("[$pp] $m") }.GetNewClosure()
      $fi = { param($c, $v) $global:ColaApp.Enqueue("@@T|$pp|$c|$v") }.GetNewClosure()
      $x = Invoke-CasaPedimento -Pedimento $pp -Casa -Log $lg -Fila $fi
      $global:ColaApp.Enqueue("@@TF|$pp|$($x.Est)")
      if ($x.Parar) { $a.ctl.stop = $true; $global:ColaApp.Enqueue('⚠ Lote del tablero detenido: CASA necesita atención') }
    }
  } @{ peds = $peds; ctl = $script:ctlTab } {
    param($o)
    foreach ($p in @($script:tabPend.Keys)) { Complete-TableroPed $p $(if ($o.error) { 'Error' } else { 'No iniciado' }) "$($o.error)" }
    if ($script:ctlTab.stop) { Log '== Tablero: lote detenido' }
  }
}
# renglón de Varios pedimentos (esta PC o el remoto) de un pendiente del tablero
function Send-TableroFila([string]$ped, [string]$c, [string]$v) {
  if (-not $script:tabPend.Contains($ped)) {   # ya había terminado: solo importa si la FAYC del lote lo deja Completo
    if ($c -eq 'est' -and $v -eq 'Completo' -and $script:tabFin[$ped] -ne 'Completo') { $script:tabPend[$ped] = @{ id = $script:tabIds[$ped]; est = ''; fal = ''; res = 'FAYC y ZIP listos' }; Complete-TableroPed $ped 'Completo' '' }; return }
  if ($c -eq 'est' -and $v -eq 'Quitado de la cola') { $v = 'No iniciado (quitado de la cola)' }
  Set-TableroFila $ped $c $v
  if ($c -eq 'est' -and $v -match '^(Completo|Listo para FAYC|Revisar|Error|Sin carpeta|Varias carpetas|No iniciado|Detenido)') { Complete-TableroPed $ped $v $(if ($v -eq 'Detenido') { 'Lo detuvo el usuario' } else { '' }) }
}
# un pedimento terminó ("@@TF|pedimento|estado"): resultado al tablero
function Complete-TableroPed([string]$ped, [string]$est, [string]$err) {
  $t = $script:tabPend[$ped]; if (-not $t) { return }; $script:tabPend.Remove($ped); $script:tabFin[$ped] = $est   # el remoto repite su estado en cada revisión: se avisa una vez
  Send-Tablero @{ tipo = 'fin'; id = $t.id; ped = $ped; estado = $est; falta = $t.fal; resultado = $(if ($err) { $err } else { $t.res }); pc = $CasaEquipo }
  Log "== Tablero: $ped → $est$(if ($t.fal) { " · falta $($t.fal)" })"
}
# avance del trabajo ("@@T|pedimento|columna|valor") → al tablero
function Set-TableroFila([string]$ped, [string]$c, [string]$v) {
  $t = $script:tabPend[$ped]; if (-not $t) { return }
  if ($c -in 'est', 'fal', 'res') { $t[$c] = $v }
  if ($c -in 'est', 'av', 'fal', 'res') { Send-Tablero @{ tipo = 'avance'; id = $t.id; campo = $c; valor = $(if ($c -eq 'av') { [int]$v } else { $v }) } }
  if ($c -eq 'est') { $stEstado.Text = "Expediente ${ped}: $v" }
}

# ---------- cambiar de pestaña ----------
function Show-Pestana([string]$k) {
  if ($k -ne 'Configuración' -and $script:lic -and -not $script:lic.Ok) {
    if ($form.Visible) { [void][Windows.Forms.MessageBox]::Show($form, "La app está bloqueada:`n`n$($script:lic.Motivo)", 'Licencia', 'OK', 'Warning') }; $k = 'Configuración' }
  if (-not (Test-Pestana $k)) { $k = @(@($script:tabBtn.Keys) | Where-Object { Test-Pestana $_ })[0] }   # la licencia no trae ese módulo: la primera que sí
  foreach ($n in $script:tabBtn.Keys) { $on = $n -eq $k; $script:tabBtn[$n].L.ForeColor = $(if ($on) { $Pal.Head } else { $Pal.Gris }); $script:tabBtn[$n].U.Visible = $on }
  $body.Visible = $k -eq 'Expediente'; $lf.Visible = $k -eq 'Varios pedimentos'; $gf.Visible = $k -eq 'Glosa'; $pf.Visible = $k -eq 'Pendientes'; $cf.Visible = $k -eq 'Configuración'
  $form.AcceptButton = switch ($k) { 'Expediente' { $btnPrep } 'Glosa' { $gBus } default { $null } }
  switch ($k) {
    'Expediente' { Set-Acomodo; [void]$txtPed.Focus() }
    'Varios pedimentos' { Update-RemotoLbl; [void]$txtLote.Focus() }
    'Glosa' { if ($script:dir -and -not $gPed.Text) { $gPed.Text = $txtPed.Text.Trim() } }
    'Pendientes' { Start-Tablero }
    'Configuración' { Set-AcomodoCfg; Fill-Cfg }
  }
}
$body.BringToFront(); $lf.BringToFront(); $gf.BringToFront(); $pf.BringToFront(); $cf.BringToFront()

# que la ventana siempre se vea aunque PowerShell arranque oculto
$form.Add_Shown({ [void][AppWin]::ShowWindow($form.Handle, 5); $form.WindowState = 'Normal'; $form.Activate(); $txtPed.Focus() })
$lblNueva = Add-Ctl (New-Object Windows.Forms.Label -Property @{ Text = ''; ForeColor = $Pal.Texto; BackColor = Hex '#FDE047'; Font = $F.Neg; AutoSize = $true; Padding = '8,4,8,4'; Cursor = 'Hand'; Visible = $false; Anchor = 'Top,Right' }) $head
function Set-NuevaPos { $lblNueva.Location = New-Object Drawing.Point ([Math]::Max(330, $chkTop.Left - $lblNueva.Width - 16)), 19 }
$tVer = New-Object Windows.Forms.Timer -Property @{ Interval = 60000 }
$tVer.Add_Tick({
  $script:licTick++; if ($script:licTick % 60 -eq 0) { try { Update-Licencia; if (-not $script:lic.Ok) { Show-Pestana 'Configuración' } } catch {} }
  if ($script:licTick % 360 -eq 2) { Start-RevisarActualizacion }   # 2 minutos después de abrir y luego cada 6 horas
  $v = Get-AppVersion
  if ($v -ne $script:verIni -and -not $lblNueva.Visible) { $lblNueva.Text = "Hay una versión nueva (v$v): clic para reiniciar"; $lblNueva.Visible = $true; Set-NuevaPos; Log "Hay una versión nueva de la app (v$v). Cierra y vuelve a abrir, o da clic en el aviso amarillo." }
})
$tVer.Start()
# ---------- actualizaciones por internet (solo instalaciones de otras agencias, con cliente.json) ----------
# Revisa en segundo plano (Get-CasaActualizacion en casa.ps1); si hay versión firmada más nueva, lo dice el aviso amarillo.
$script:upd = $null; $script:updJob = $null
$tUpd = New-Object Windows.Forms.Timer -Property @{ Interval = 2000 }
function Start-RevisarActualizacion {
  if (-not $CasaCliente -or $script:esPrueba -or $script:updJob -or $script:upd) { return }
  $rs = [runspacefactory]::CreateRunspace(); $rs.Open(); $ps = [powershell]::Create(); $ps.Runspace = $rs
  [void]$ps.AddScript('param($root, $v) . "$root\casa.ps1"; Get-CasaActualizacion $v').AddArgument($PSScriptRoot).AddArgument($script:verIni)
  $script:updJob = @{ PS = $ps; RS = $rs; H = $ps.BeginInvoke() }; $tUpd.Start()
}
$tUpd.Add_Tick({
  $j = $script:updJob; if (-not $j -or -not $j.H.IsCompleted) { return }
  $tUpd.Stop(); $script:updJob = $null
  try { $r = @($j.PS.EndInvoke($j.H)) | Select-Object -Last 1 } catch { $r = $null }; $j.PS.Dispose(); $j.RS.Close()
  if ($r -and $r.version) { $script:upd = $r; $lblNueva.Text = "Hay una actualización (v$($r.version)): clic para instalarla"; $lblNueva.Visible = $true; Set-NuevaPos
    Log "Hay una actualización de Expedito: v$($r.version)$(if ($r.nota) { " — $($r.nota)" })" }
})
$lblNueva.Add_Click({
  if ($script:bg) { [void][Windows.Forms.MessageBox]::Show($form, "Espera a que termine: $($script:bg.Que)", 'Versión nueva'); return }
  if ($script:upd) {   # instalación de otra agencia: se descarga de internet
    if ([Windows.Forms.MessageBox]::Show($form, "¿Descargo e instalo Expedito v$($script:upd.version)?$(if ($script:upd.nota) { "`n`n$($script:upd.nota)" })`n`nLa app se cierra y se vuelve a abrir sola (menos de un minuto). Tu licencia y tu configuración no cambian.", 'Actualización', 'YesNo', 'Question') -ne 'Yes') { return }
    $stEstado.Text = 'Descargando la actualización…'; [Windows.Forms.Application]::DoEvents()
    try { Install-CasaActualizacion $script:upd $PID } catch { [void][Windows.Forms.MessageBox]::Show($form, "No pude actualizar:`n`n$($_.Exception.Message)", 'Actualización', 'OK', 'Warning'); $stEstado.Text = 'Listo'; return }
    $stEstado.Text = 'Instalando la actualización…'; [Windows.Forms.Application]::DoEvents(); Start-Sleep -Seconds 1; $form.Close(); return
  }
  if ([Windows.Forms.MessageBox]::Show($form, '¿Cierro la app y la abro con la versión nueva?', 'Versión nueva', 'YesNo', 'Question') -ne 'Yes') { return }
  # Reabrir a través del Explorador (como doble clic). Lanzar powershell directo desde aquí fallaba con 0xc0000142
  # porque esta app se cierra mientras el nuevo proceso todavía arranca.
  $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Expedito.lnk'; if (-not (Test-Path -LiteralPath $lnk)) { $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) ('Expedientes ' + 'CASA.lnk') }
  $usaLnk = (Test-Path -LiteralPath $lnk) -and ((New-Object -ComObject WScript.Shell).CreateShortcut($lnk).Arguments -like "*$PSScriptRoot\*")
  $abrir = if ($usaLnk) { $lnk } elseif (Test-Path -LiteralPath "$PSScriptRoot\Probar.cmd") { "$PSScriptRoot\Probar.cmd" } elseif (Test-Path -LiteralPath "$PSScriptRoot\abrir.vbs") { "$PSScriptRoot\abrir.vbs" } else { $null }
  if (-not $abrir) { [void][Windows.Forms.MessageBox]::Show($form, 'Cierra la app y ábrela otra vez desde el Escritorio.', 'Versión nueva'); return }
  Start-Process -FilePath explorer.exe -ArgumentList "`"$abrir`""
  $stEstado.Text = 'Abriendo la versión nueva…'; [Windows.Forms.Application]::DoEvents(); Start-Sleep -Seconds 3
  $form.Close()
})
$tVis = New-Object Windows.Forms.Timer -Property @{ Interval = 500 }
$tVis.Add_Tick({ $tVis.Stop(); if (-not [CasaWin]::IsWindowVisible($form.Handle)) { [void][AppWin]::ShowWindow($form.Handle, 5); [void][AppWin]::SetForegroundWindow($form.Handle) } })
$tVis.Start()
Refresh-List
# acceso directo del Escritorio: se llama "Expedito" y abre con el lanzador sin consola. Los viejos ("Expedito"
# o los que abrían powershell) se corrigen solos, solo si son de esta misma carpeta de la app.
if (-not $script:esPrueba -and (Test-Path -LiteralPath "$PSScriptRoot\abrir.vbs")) { try {
  $desk = [Environment]::GetFolderPath('Desktop'); $nuevo = Join-Path $desk 'Expedito.lnk'; $viejo = Join-Path $desk ('Expedientes ' + 'CASA.lnk'); $wsh = New-Object -ComObject WScript.Shell   # viejo = nombre anterior de la app
  $argV = if (Test-Path -LiteralPath $viejo) { "$($wsh.CreateShortcut($viejo).Arguments)" } else { '' }
  $argN = if (Test-Path -LiteralPath $nuevo) { "$($wsh.CreateShortcut($nuevo).Arguments)" } else { '' }
  if ($argV -like "*$PSScriptRoot\*") {
    $sc = $wsh.CreateShortcut($nuevo); $sc.TargetPath = "$env:WINDIR\System32\wscript.exe"; $sc.Arguments = "`"$PSScriptRoot\abrir.vbs`""; $sc.WorkingDirectory = $PSScriptRoot
    $sc.IconLocation = "$PSScriptRoot\app.ico,0"; $sc.Description = 'Expedito'; $sc.Save()
    if (Test-Path -LiteralPath $nuevo) { Remove-Item -LiteralPath $viejo -Force; Log 'El acceso directo del Escritorio ahora se llama "Expedito"' }
  } elseif ($argN -like "*$PSScriptRoot\*") { $sc = $wsh.CreateShortcut($nuevo)
    if ($sc.TargetPath -like '*powershell.exe') { $sc.TargetPath = "$env:WINDIR\System32\wscript.exe"; $sc.Arguments = "`"$PSScriptRoot\abrir.vbs`""; $sc.Save() } }
} catch {} }
$script:lic = $null; Update-Licencia
Show-Pestana $(if ($script:lic.Ok) { 'Expediente' } else { 'Configuración' })
$script:licTick = 0
$script:iniRem = $true
$eqIni = Get-CasaEquipoCfg
if ($eqIni.remoto -eq $true) { $chkSoy.Checked = $true } elseif ($eqIni.lote -eq 'remoto') { $rbRem.Checked = $true }
$script:iniRem = $false
$tRem.Start()
[void]$form.ShowDialog()
